package com.refillminerpro;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RefillMinerMod implements ModInitializer {
    public static final String MOD_ID = "refillminerpro";
    public static final String MOD_NAME = "Refill Miner Pro";
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing {} (Minecraft 1.21.11 Fabric)...", MOD_NAME);

        // Register authorized companion server commands
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("refillminer")
                    .then(CommandManager.literal("info")
                            .executes(context -> {
                                context.getSource().sendMessage(Text.literal(
                                        "§6[" + MOD_NAME + "] §aFabric 1.21.11 Companion Active. Legitimate region mining supported."
                                ));
                                return 1;
                            })
                    )
                    .then(CommandManager.literal("status")
                            .executes(context -> {
                                context.getSource().sendMessage(Text.literal(
                                        "§6[" + MOD_NAME + "] §7Server companion ready and monitoring commands."
                                ).formatted(Formatting.AQUA));
                                return 1;
                            })
                    )
            );
        });

        LOGGER.info("{} initialized successfully.", MOD_NAME);
    }
}

