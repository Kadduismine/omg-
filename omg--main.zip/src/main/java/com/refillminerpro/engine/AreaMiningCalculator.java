package com.refillminerpro.engine;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Calculates oriented rectangular area-mining footprints (default 6x3) intersected with the active region.
 * Produces an optimized snake-like sweep order to minimize unnecessary rotations and travel.
 */
public class AreaMiningCalculator {

    /**
     * Computes the list of candidate block positions for an oriented footprint anchored around the anchorPos.
     * All returned positions are guaranteed to lie within the provided activeRegion.
     *
     * @param anchorPos     The primary target block around which the footprint is centered/oriented.
     * @param face          The face being looked at or mined against.
     * @param activeRegion  The user's defined selection bounds.
     * @param config        Mod configuration containing width and height.
     * @return Ordered list of blocks in an optimized sweep pattern.
     */
    public static List<BlockPos> calculateFootprint(BlockPos anchorPos, Direction face, BlockRegion activeRegion, ModConfig config) {
        List<BlockPos> result = new ArrayList<>();
        if (anchorPos == null || activeRegion == null || !activeRegion.contains(anchorPos)) {
            if (anchorPos != null && activeRegion != null && activeRegion.contains(anchorPos)) {
                result.add(anchorPos);
            }
            return result;
        }

        int width = config != null ? config.getAreaMiningWidth() : 6;
        int height = config != null ? config.getAreaMiningHeight() : 3;

        Direction miningDir = face != null ? face.getOpposite() : Direction.NORTH;

        // Determine horizontal axis (widthAxis) and vertical axis (heightAxis) based on mining face
        Direction widthDir;
        Direction heightDir;

        if (miningDir == Direction.UP || miningDir == Direction.DOWN) {
            // Horizontal plane (floor/ceiling)
            widthDir = Direction.EAST;
            heightDir = Direction.SOUTH;
        } else {
            // Vertical wall
            widthDir = miningDir.rotateYClockwise(); // Left-to-right relative to facing
            heightDir = Direction.UP;
        }

        int halfW = width / 2;
        int halfH = height / 2;

        boolean bottomUp = config != null && config.getTargetPriority() == com.refillminerpro.config.TargetPriority.BOTTOM_TO_TOP;

        if (bottomUp) {
            // Sweep bottom-to-top
            for (int h = 0; h < height; h++) {
                int hOffset = h - halfH;
                boolean leftToRight = (h % 2 == 0); // Snake pattern

                for (int w = 0; w < width; w++) {
                    int actualW = leftToRight ? w : (width - 1 - w);
                    int wOffset = actualW - halfW;

                    BlockPos candidate = anchorPos
                            .offset(widthDir, wOffset)
                            .offset(heightDir, hOffset);

                    if (activeRegion.contains(candidate)) {
                        result.add(candidate.toImmutable());
                    }
                }
            }
        } else {
            // Sweep top-to-bottom
            for (int h = height - 1; h >= 0; h--) {
                int hOffset = h - halfH;
                boolean leftToRight = (height - 1 - h) % 2 == 0; // Snake pattern

                for (int w = 0; w < width; w++) {
                    int actualW = leftToRight ? w : (width - 1 - w);
                    int wOffset = actualW - halfW;

                    BlockPos candidate = anchorPos
                            .offset(widthDir, wOffset)
                            .offset(heightDir, hOffset);

                    if (activeRegion.contains(candidate)) {
                        result.add(candidate.toImmutable());
                    }
                }
            }
        }

        // Ensure anchorPos itself is included if somehow clipped
        if (!result.contains(anchorPos) && activeRegion.contains(anchorPos)) {
            result.add(0, anchorPos.toImmutable());
        }

        return result;
    }
}

