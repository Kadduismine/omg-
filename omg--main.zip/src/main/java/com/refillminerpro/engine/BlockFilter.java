package com.refillminerpro.engine;

import com.refillminerpro.config.ModConfig;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Validates block eligibility against configurable rules, filters, hardness, and registry IDs.
 */
public class BlockFilter {
    private final ModConfig config;
    private final Set<String> normalizedWhitelist = new HashSet<>();
    private final Set<String> normalizedBlacklist = new HashSet<>();

    public BlockFilter(ModConfig config) {
        this.config = config;
        updateCache();
    }

    public synchronized void updateCache() {
        normalizedWhitelist.clear();
        normalizedBlacklist.clear();

        List<String> wl = config.getWhitelist();
        if (wl != null) {
            for (String id : wl) {
                if (id != null && !id.trim().isEmpty()) {
                    String norm = normalizeId(id.trim());
                    normalizedWhitelist.add(norm);
                    registerBlockItemMapping(norm, normalizedWhitelist);
                }
            }
        }

        List<String> bl = config.getBlacklist();
        if (bl != null) {
            for (String id : bl) {
                if (id != null && !id.trim().isEmpty()) {
                    String norm = normalizeId(id.trim());
                    normalizedBlacklist.add(norm);
                    registerBlockItemMapping(norm, normalizedBlacklist);
                }
            }
        }
    }

    private void registerBlockItemMapping(String idStr, Set<String> targetSet) {
        try {
            Identifier id = Identifier.tryParse(idStr);
            if (id != null && Registries.ITEM != null && Registries.ITEM.containsId(id)) {
                Item item = Registries.ITEM.get(id);
                if (item instanceof BlockItem bi && bi.getBlock() != null && Registries.BLOCK != null) {
                    Identifier blockId = Registries.BLOCK.getId(bi.getBlock());
                    if (blockId != null) {
                        targetSet.add(blockId.toString().toLowerCase());
                    }
                }
            }
            if (id != null && Registries.BLOCK != null && Registries.BLOCK.containsId(id)) {
                Block blk = Registries.BLOCK.get(id);
                if (blk != null && blk.asItem() != null && Registries.ITEM != null) {
                    Identifier itemId = Registries.ITEM.getId(blk.asItem());
                    if (itemId != null) {
                        targetSet.add(itemId.toString().toLowerCase());
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private String normalizeId(String id) {
        if (!id.contains(":")) {
            return "minecraft:" + id.toLowerCase();
        }
        return id.toLowerCase();
    }

    /**
     * Determines whether a block at the specified position is eligible to be queued and mined.
     */
    public boolean isEligible(BlockView world, BlockPos pos, BlockState state) {
        if (world == null || pos == null || state == null) {
            return false;
        }

        try {
            // 1. Air filter
            if (config.isFilterExcludeAir() && state.isAir()) {
                return false;
            }

            // 2. Fluid filter
            if (config.isFilterExcludeFluids()) {
                if (!state.getFluidState().isEmpty() || state.getBlock() instanceof FluidBlock) {
                    return false;
                }
            }

            // 3. Unbreakable check (bedrock, barrier, end portals have hardness < 0)
            if (config.isFilterExcludeUnbreakable()) {
                float hardness = state.getHardness(world, pos);
                if (hardness < 0.0f) {
                    return false;
                }
            }

            // 4. Containers and block entities
            if (config.isFilterExcludeBlockEntities()) {
                if (state.hasBlockEntity()) {
                    return false;
                }
            }

            // 5. Whitelist & Blacklist evaluation
            Block block = state.getBlock();
            if (Registries.BLOCK == null) {
                return true;
            }

            Identifier regId = Registries.BLOCK.getId(block);
            if (regId == null) {
                return false;
            }
            String idString = regId.toString().toLowerCase();

            if (!normalizedWhitelist.isEmpty() && !normalizedWhitelist.contains(idString)) {
                return false;
            }

            if (!normalizedBlacklist.isEmpty() && normalizedBlacklist.contains(idString)) {
                return false;
            }

            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public Set<String> getNormalizedWhitelist() {
        return new HashSet<>(normalizedWhitelist);
    }

    public Set<String> getNormalizedBlacklist() {
        return new HashSet<>(normalizedBlacklist);
    }
}
