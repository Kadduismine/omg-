package com.refillminerpro.engine;

import net.minecraft.util.math.BlockPos;

/**
 * Diagnostic tracking snapshot for debug overlays, reporting, and automated QA.
 */
public class MiningDebugInfo {
    public static volatile BlockPos currentTarget = null;
    public static volatile String currentTargetFace = "None";
    public static volatile MiningState miningState = MiningState.IDLE;
    public static volatile int miningProgressPercent = 0;
    public static volatile int vanillaBreakingProgress = -1;
    public static volatile boolean isEligible = false;
    public static volatile boolean lineOfSightValid = false;
    public static volatile BlockPos firstObstructingBlock = null;
    public static volatile double distanceToTarget = 0.0;
    public static volatile boolean withinReach = false;
    public static volatile boolean rotationReady = false;
    public static volatile String whySelectedReason = "None";
    public static volatile String whySkippedReason = "None";
    public static volatile boolean wasRejected = false;
    public static volatile boolean blockConfirmedRemoved = false;
    public static volatile int pendingTargetsCount = 0;
    public static volatile int completedTargetsCount = 0;
    public static volatile int failedTargetsCount = 0;
    public static volatile int serverRestrictedCount = 0;

    // Movement & camera tracking
    public static volatile String navState = "IDLE";
    public static volatile String pathStatus = "NONE";
    public static volatile String rejectionReason = "None";
    public static volatile int expectedDurationTicks = 0;
    public static volatile int currentMiningTicks = 0;
    public static volatile int queuedTargetsCount = 0;
    public static volatile float targetYaw = 0.0f;
    public static volatile float targetPitch = 0.0f;
    public static volatile float playerYaw = 0.0f;
    public static volatile float playerPitch = 0.0f;

    // Player-controlled crosshair and manual mining tracking
    public static volatile BlockPos crosshairPos = null;
    public static volatile String crosshairBlockName = "None";
    public static volatile boolean crosshairInsideBoundary = false;
    public static volatile boolean crosshairFilterEligible = false;
    public static volatile boolean isHoldingAttack = false;
    public static volatile boolean manualAssistanceActive = false;
}
