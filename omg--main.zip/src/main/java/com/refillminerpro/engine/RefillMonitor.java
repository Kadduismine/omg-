package com.refillminerpro.engine;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Continuous refill detection engine combining event-driven block updates
 * with lightweight empty-position verification.
 */
public class RefillMonitor {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/RefillMonitor");

    private final ModConfig config;
    private final BlockFilter filter;
    private final MiningEngine miningEngine;

    // Set of positions within the current region that are known to have been mined or are currently empty
    private final Set<BlockPos> monitoredEmptyPositions = Collections.newSetFromMap(new ConcurrentHashMap<>());
    // Initial snapshot of positions when "mineExistingBlocks" is false
    private final Set<BlockPos> ignoredExistingPositions = Collections.newSetFromMap(new ConcurrentHashMap<>());

    private BlockRegion activeRegion = null;
    private int ticksSinceLastCheck = 0;

    public RefillMonitor(ModConfig config, BlockFilter filter, MiningEngine miningEngine) {
        this.config = config;
        this.filter = filter;
        this.miningEngine = miningEngine;
    }

    public synchronized void startMonitoring(BlockRegion region, ClientWorld world) {
        this.activeRegion = region;
        this.monitoredEmptyPositions.clear();
        this.ignoredExistingPositions.clear();
        this.ticksSinceLastCheck = 0;

        if (region == null || world == null) {
            return;
        }

        LOGGER.info("Refill monitoring started for region: {}", region);

        if (!config.isMineExistingBlocks()) {
            recordExistingBlocks(region, world);
        }
    }

    public synchronized void stopMonitoring() {
        this.activeRegion = null;
        this.monitoredEmptyPositions.clear();
        this.ignoredExistingPositions.clear();
        this.ticksSinceLastCheck = 0;
        LOGGER.info("Refill monitoring stopped.");
    }

    public synchronized void addMonitoredEmptyPositions(Set<BlockPos> positions) {
        if (positions != null && !positions.isEmpty()) {
            this.monitoredEmptyPositions.addAll(positions);
        }
    }

    private void recordExistingBlocks(BlockRegion region, ClientWorld world) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (int y = region.getMinY(); y <= region.getMaxY(); y++) {
            for (int x = region.getMinX(); x <= region.getMaxX(); x++) {
                for (int z = region.getMinZ(); z <= region.getMaxZ(); z++) {
                    mutable.set(x, y, z);
                    if (isChunkLoaded(world, mutable)) {
                        BlockState state = world.getBlockState(mutable);
                        if (!state.isAir()) {
                            ignoredExistingPositions.add(mutable.toImmutable());
                        } else {
                            monitoredEmptyPositions.add(mutable.toImmutable());
                        }
                    }
                }
            }
        }
        LOGGER.info("Recorded {} existing blocks to ignore until mined/regenerated.", ignoredExistingPositions.size());
    }

    /**
     * Event-driven hook invoked immediately whenever a block state updates in the client world.
     */
    public void onBlockStateChanged(ClientWorld world, BlockPos pos, BlockState newState) {
        if (activeRegion == null || world == null || pos == null || !config.isAutoMineEnabled()) {
            return;
        }

        if (!activeRegion.contains(pos)) {
            return;
        }

        BlockPos immutablePos = pos.toImmutable();

        if (newState.isAir()) {
            // Block was mined or broken: monitor this position for future refills
            monitoredEmptyPositions.add(immutablePos);
            ignoredExistingPositions.remove(immutablePos);
            miningEngine.onTargetBroken(immutablePos);
        } else {
            // A non-air block appeared or updated at this position!
            if (filter.isEligible(world, immutablePos, newState)) {
                if (ignoredExistingPositions.contains(immutablePos)) {
                    return; // Still part of the initial unmined block set
                }

                // Newly appeared or refilled block!
                monitoredEmptyPositions.remove(immutablePos);
                boolean added = miningEngine.enqueueTarget(immutablePos, true);
                if (added) {
                    LOGGER.debug("Detected refill at [{}, {}, {}]: {}", immutablePos.getX(), immutablePos.getY(), immutablePos.getZ(), newState.getBlock());
                }
            } else {
                // Block appeared but is not eligible (e.g. lava/water)
                miningEngine.removeTarget(immutablePos);
            }
        }
    }

    /**
     * Periodic verification of monitored empty positions.
     * Checks empty slots when standing by in COMPLETE or WAITING states without freezing Minecraft.
     */
    public void tick(ClientWorld world) {
        if (activeRegion == null || world == null || !config.isAutoMineEnabled() || config.isPaused()) {
            return;
        }

        // Only perform periodic checks when miner is waiting or completed, to avoid clobbering active mining
        MiningStatus status = miningEngine.getStatus();
        if (status != MiningStatus.COMPLETE && status != MiningStatus.WAITING_FOR_REFILLS) {
            return;
        }

        ticksSinceLastCheck++;
        if (ticksSinceLastCheck < config.getScanIntervalTicks()) {
            return;
        }
        ticksSinceLastCheck = 0;

        // Check if area scanner has empty positions to sync
        if (miningEngine.getAreaScanner() != null && miningEngine.getAreaScanner().isComplete()) {
            Set<BlockPos> empty = miningEngine.getAreaScanner().getEmptyPositions();
            if (!empty.isEmpty()) {
                monitoredEmptyPositions.addAll(empty);
            }
        }

        // Targeted verification of known empty positions
        if (!monitoredEmptyPositions.isEmpty()) {
            Iterator<BlockPos> it = monitoredEmptyPositions.iterator();
            int checked = 0;
            int checkLimit = Math.min(200, config.getScanBatchSize());

            while (it.hasNext() && checked < checkLimit) {
                BlockPos pos = it.next();
                checked++;

                if (isChunkLoaded(world, pos)) {
                    BlockState state = world.getBlockState(pos);
                    if (!state.isAir()) {
                        it.remove();
                        if (filter.isEligible(world, pos, state) && !ignoredExistingPositions.contains(pos)) {
                            miningEngine.enqueueTarget(pos, true);
                            LOGGER.debug("Periodic check verified refill at [{}, {}, {}]", pos.getX(), pos.getY(), pos.getZ());
                        }
                    }
                }
            }
        }
    }

    private boolean isChunkLoaded(ClientWorld world, BlockPos pos) {
        int chunkX = ChunkSectionPos.getSectionCoord(pos.getX());
        int chunkZ = ChunkSectionPos.getSectionCoord(pos.getZ());
        return world.isChunkLoaded(chunkX, chunkZ);
    }

    public int getMonitoredEmptyPositionsCount() {
        return monitoredEmptyPositions.size();
    }
}
