package com.refillminerpro.engine;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Explicit, deterministic state machine for single-target mining lifecycle:
 * IDLE -> SELECTING_NEXT_TARGET -> VALIDATING_TARGET -> ALIGNING_WITH_TARGET
 *      -> STARTING_MINING -> MINING_IN_PROGRESS -> WAITING_FOR_BLOCK_UPDATE
 *      -> CONFIRMING_COMPLETION -> SELECTING_NEXT_TARGET ...
 * With robust error recovery (RECOVERING_FROM_FAILURE) and pause support (PAUSED).
 */
public enum MiningState {
    IDLE("Idle", Formatting.GRAY),
    SELECTING_NEXT_TARGET("Selecting Target", Formatting.BLUE),
    VALIDATING_TARGET("Validating Target", Formatting.YELLOW),
    ALIGNING_WITH_TARGET("Aligning Aim", Formatting.AQUA),
    STARTING_MINING("Starting Mining", Formatting.GOLD),
    MINING_IN_PROGRESS("Mining in Progress", Formatting.GREEN),
    WAITING_FOR_BLOCK_UPDATE("Waiting for Block Update", Formatting.LIGHT_PURPLE),
    CONFIRMING_COMPLETION("Confirming Completion", Formatting.DARK_GREEN),
    RECOVERING_FROM_FAILURE("Recovering from Failure", Formatting.RED),
    PAUSED("Paused", Formatting.YELLOW);

    private final String label;
    private final Formatting formatting;

    MiningState(String label, Formatting formatting) {
        this.label = label;
        this.formatting = formatting;
    }

    public String getLabel() {
        return label;
    }

    public Formatting getFormatting() {
        return formatting;
    }

    public Text getFormattedText() {
        return Text.literal(label).formatted(formatting);
    }
}

