package com.refillminerpro.engine;

import com.refillminerpro.region.BlockRegion;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Deterministic area scanner for Refill Miner Pro.
 * Scans every valid block position inside the selected region's inclusive boundaries,
 * evaluates eligibility using BlockFilter, and builds an ordered, deduplicated target list.
 * Supports chunked/batched scanning across ticks for large regions to prevent game freezes.
 */
public class AreaScanner {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/AreaScanner");

    private final BlockFilter filter;

    private BlockRegion region = null;
    private boolean scanning = false;
    private boolean complete = false;
    private boolean hasError = false;
    private String lastErrorMessage = "";
    private String lastReasonForZeroTargets = "";

    // Coordinate cursors (inclusive min to max)
    private int cursorX;
    private int cursorY;
    private int cursorZ;

    private long totalBlocks = 0;
    private long scannedBlocks = 0;
    private int lastLoggedPercent = 0;

    // Detected results & diagnostics
    private final List<BlockPos> detectedTargets = new ArrayList<>();
    private final Set<BlockPos> detectedSet = new HashSet<>();
    private final Set<BlockPos> emptyPositions = new HashSet<>();
    private int unloadedBlocksSkipped = 0;
    private int airBlocksCount = 0;
    private int filteredBlocksCount = 0;

    public AreaScanner(BlockFilter filter) {
        this.filter = filter;
    }

    /**
     * Initializes a fresh area scan for the given region.
     *
     * @param region The normalized 3D cuboid selection.
     * @param world  The client world.
     */
    public synchronized void startScan(BlockRegion region, ClientWorld world) {
        startScan(region, world, null);
    }

    /**
     * Initializes a fresh area scan for the given region with optional player forward bounds.
     *
     * @param region The normalized 3D cuboid selection.
     * @param world  The client world.
     * @param player Optional player entity for forward-cone/reach evaluation.
     */
    public synchronized void startScan(BlockRegion region, ClientWorld world, net.minecraft.client.network.ClientPlayerEntity player) {
        this.region = region;
        this.detectedTargets.clear();
        this.detectedSet.clear();
        this.emptyPositions.clear();
        this.scannedBlocks = 0;
        this.unloadedBlocksSkipped = 0;
        this.airBlocksCount = 0;
        this.filteredBlocksCount = 0;
        this.complete = false;
        this.hasError = false;
        this.lastErrorMessage = "";
        this.lastReasonForZeroTargets = "";
        this.lastLoggedPercent = 0;

        if (region == null || world == null) {
            this.scanning = false;
            this.complete = true;
            this.totalBlocks = 0;
            this.lastReasonForZeroTargets = (region == null) ? "No active region selected" : "Client world unavailable";
            return;
        }

        this.totalBlocks = region.getVolume();
        if (this.totalBlocks <= 0) {
            this.scanning = false;
            this.complete = true;
            this.lastReasonForZeroTargets = "Region volume is zero";
            return;
        }

        this.cursorX = region.getMinX();
        this.cursorY = region.getMinY();
        this.cursorZ = region.getMinZ();
        this.scanning = true;

        LOGGER.info("Starting deterministic area scan for region {}x{}x{} ({} total blocks)",
                region.getWidthX(), region.getHeightY(), region.getLengthZ(), totalBlocks);
    }

    /**
     * Executes one step of the scan up to batchLimit blocks.
     * If batchLimit <= 0 or region is small, completes the scan in one pass.
     *
     * @param world      The client world.
     * @param batchLimit Maximum blocks to inspect in this step.
     * @return true if the scan has finished, false if more blocks remain.
     */
    public synchronized boolean stepScan(ClientWorld world, int batchLimit) {
        if (!scanning || region == null || world == null) {
            scanning = false;
            complete = true;
            return true;
        }

        try {
            long startNanos = System.nanoTime();
            int processedInThisStep = 0;
            // Adaptive work budget: small areas (<= 3500 blocks) complete immediately in 1 tick.
            // Larger areas scan with a high-throughput per-tick budget (>= 3000 blocks/tick) bounded to 1.5ms
            // so Minecraft maintains 200+ FPS without hitching.
            int limit = (batchLimit > 0) ? Math.max(batchLimit, 3000) : Integer.MAX_VALUE;
            if (totalBlocks <= 3500) {
                limit = (int) totalBlocks;
            }

            BlockPos.Mutable mutable = new BlockPos.Mutable();

            int minX = region.getMinX();
            int maxX = region.getMaxX();
            int minY = region.getMinY();
            int maxY = region.getMaxY();
            int minZ = region.getMinZ();
            int maxZ = region.getMaxZ();

            int cachedChunkX = Integer.MIN_VALUE;
            int cachedChunkZ = Integer.MIN_VALUE;
            boolean cachedChunkLoaded = false;

            while (scanning) {
                int chunkX = cursorX >> 4;
                int chunkZ = cursorZ >> 4;
                if (chunkX != cachedChunkX || chunkZ != cachedChunkZ) {
                    cachedChunkX = chunkX;
                    cachedChunkZ = chunkZ;
                    cachedChunkLoaded = isChunkLoaded(world, chunkX, chunkZ);
                }

                if (!cachedChunkLoaded) {
                    unloadedBlocksSkipped++;
                } else {
                    mutable.set(cursorX, cursorY, cursorZ);
                    BlockState state = world.getBlockState(mutable);

                    if (state.isAir()) {
                        airBlocksCount++;
                    } else if (filter != null && filter.isEligible(world, mutable, state)) {
                        // Only allocate immutable BlockPos when block is confirmed eligible!
                        BlockPos immutable = mutable.toImmutable();
                        if (detectedSet.add(immutable)) {
                            detectedTargets.add(immutable);
                        }
                    } else {
                        filteredBlocksCount++;
                    }
                }

                scannedBlocks++;
                processedInThisStep++;

                // Throttled logging at 25%, 50%, 75%
                int currentPercent = (int) (getProgress() * 100.0f);
                if (currentPercent >= lastLoggedPercent + 25 && currentPercent < 100) {
                    lastLoggedPercent = (currentPercent / 25) * 25;
                    LOGGER.info("Area scan progress: {}% ({}/{} blocks, {} targets detected)",
                            currentPercent, scannedBlocks, totalBlocks, detectedTargets.size());
                }

                // Advance coordinates deterministically: X -> Z -> Y
                cursorX++;
                if (cursorX > maxX) {
                    cursorX = minX;
                    cursorZ++;
                    if (cursorZ > maxZ) {
                        cursorZ = minZ;
                        cursorY++;
                        if (cursorY > maxY || scannedBlocks >= totalBlocks) {
                            finishScan();
                            return true;
                        }
                    }
                }

                // Measured per-tick budget check
                if (processedInThisStep >= limit) {
                    long elapsedNanos = System.nanoTime() - startNanos;
                    if (elapsedNanos >= 1_500_000L || scannedBlocks >= totalBlocks) {
                        break;
                    }
                    limit += 1000;
                }
            }

            if (scannedBlocks >= totalBlocks) {
                finishScan();
                return true;
            }

            return complete;
        } catch (Throwable t) {
            LOGGER.error("Exception during area scan execution: ", t);
            hasError = true;
            lastErrorMessage = t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName();
            scanning = false;
            complete = true;
            return true;
        }
    }

    private void finishScan() {
        scanning = false;
        complete = true;

        if (detectedTargets.isEmpty()) {
            if (unloadedBlocksSkipped >= totalBlocks) {
                lastReasonForZeroTargets = "World chunks in selected region are not loaded";
            } else if (airBlocksCount >= (scannedBlocks - unloadedBlocksSkipped)) {
                lastReasonForZeroTargets = "Area is empty (all air blocks)";
            } else if (filteredBlocksCount > 0) {
                lastReasonForZeroTargets = String.format("All %d blocks excluded by target filters (whitelist/rules)", filteredBlocksCount);
            } else {
                lastReasonForZeroTargets = "No eligible blocks found in area";
            }
        } else {
            lastReasonForZeroTargets = "";
        }

        LOGGER.info("=== Area Scan Completed Summary ===");
        if (region != null) {
            LOGGER.info("Region: {}x{}x{} ({} total positions)", region.getWidthX(), region.getHeightY(), region.getLengthZ(), totalBlocks);
        }
        LOGGER.info("Positions scanned: {} | Unloaded skipped: {}", scannedBlocks, unloadedBlocksSkipped);
        LOGGER.info("Air/empty positions: {} | Filtered out: {}", airBlocksCount, filteredBlocksCount);
        LOGGER.info("Eligible targets found: {}", detectedTargets.size());
        if (!detectedTargets.isEmpty()) {
            LOGGER.info("Scan status: READY ({} unique targets queued)", detectedTargets.size());
        } else {
            LOGGER.info("Scan status: COMPLETE ({})", lastReasonForZeroTargets);
        }
    }

    /**
     * Checks if the chunk containing the coordinates is currently loaded.
     */
    public boolean isChunkLoaded(ClientWorld world, int chunkX, int chunkZ) {
        if (world == null) return false;
        try {
            return world.isChunkLoaded(chunkX, chunkZ);
        } catch (Throwable t) {
            return true; // Fallback safely
        }
    }

    public boolean isChunkLoaded(ClientWorld world, BlockPos pos) {
        if (world == null || pos == null) return false;
        return isChunkLoaded(world, pos.getX() >> 4, pos.getZ() >> 4);
    }

    public synchronized void reset() {
        this.scanning = false;
        this.complete = false;
        this.hasError = false;
        this.lastErrorMessage = "";
        this.lastReasonForZeroTargets = "";
        this.scannedBlocks = 0;
        this.totalBlocks = 0;
        this.lastLoggedPercent = 0;
        this.unloadedBlocksSkipped = 0;
        this.airBlocksCount = 0;
        this.filteredBlocksCount = 0;
        this.detectedTargets.clear();
        this.detectedSet.clear();
        this.emptyPositions.clear();
        this.region = null;
    }

    public boolean isScanning() {
        return scanning;
    }

    public boolean isComplete() {
        return complete;
    }

    public boolean hasError() {
        return hasError;
    }

    public String getLastErrorMessage() {
        return lastErrorMessage;
    }

    public String getLastReasonForZeroTargets() {
        return lastReasonForZeroTargets;
    }

    public float getProgress() {
        if (totalBlocks <= 0) return 1.0f;
        return Math.min(1.0f, (float) scannedBlocks / (float) totalBlocks);
    }

    public long getScannedBlocks() {
        return scannedBlocks;
    }

    public long getTotalBlocks() {
        return totalBlocks;
    }

    public int getAirBlocksCount() {
        return airBlocksCount;
    }

    public int getFilteredBlocksCount() {
        return filteredBlocksCount;
    }

    public synchronized List<BlockPos> getDetectedTargets() {
        return new ArrayList<>(detectedTargets);
    }

    public synchronized Set<BlockPos> getEmptyPositions() {
        return Collections.emptySet();
    }

    public int getUnloadedBlocksSkipped() {
        return unloadedBlocksSkipped;
    }

    public BlockRegion getRegion() {
        return region;
    }

    /**
     * Scans and returns multiple reachable candidates directly in front of the player
     * bounded by the player's interaction range and field of view.
     */
    public List<BlockPos> scanForwardCandidates(net.minecraft.client.network.ClientPlayerEntity player,
                                               ClientWorld world,
                                               BlockRegion boundary,
                                               com.refillminerpro.config.ModConfig config) {
        List<BlockPos> results = new ArrayList<>();
        if (player == null || world == null) return results;

        net.minecraft.util.math.Vec3d eyePos = player.getEyePos();
        float yawRad = (float) Math.toRadians(player.getYaw());
        net.minecraft.util.math.Vec3d forwardHeading = new net.minecraft.util.math.Vec3d(-Math.sin(yawRad), 0, Math.cos(yawRad)).normalize();
        double maxDist = config != null ? Math.max(config.getScanDistance(), 4.5) : 5.0;
        // Permissive forward arc (120 degrees default) to cover top, bottom, left, right, center
        double fovLimit = config != null ? Math.cos(Math.toRadians(Math.max(config.getForwardScanFov(), 120.0) / 2.0)) : -0.1;

        int radius = (int) Math.ceil(maxDist);
        int halfHeight = config != null ? Math.max(2, config.getScanHeight() / 2) : 2;
        BlockPos playerPos = player.getBlockPos();
        BlockPos.Mutable mutable = new BlockPos.Mutable();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -halfHeight; dy <= halfHeight + 1; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    mutable.set(playerPos.getX() + dx, playerPos.getY() + dy, playerPos.getZ() + dz);
                    if (boundary != null && !boundary.contains(mutable)) {
                        continue;
                    }
                    if (!world.isChunkLoaded(mutable)) {
                        continue;
                    }

                    net.minecraft.util.math.Vec3d targetCenter = net.minecraft.util.math.Vec3d.ofCenter(mutable);
                    net.minecraft.util.math.Vec3d toTarget = targetCenter.subtract(eyePos);
                    double dist = toTarget.length();
                    if (dist > maxDist || dist < 0.5) {
                        continue;
                    }

                    // Forward sector check decoupled from camera pitch (uses horizontal forward heading)
                    net.minecraft.util.math.Vec3d toTargetHoriz = new net.minecraft.util.math.Vec3d(toTarget.x, 0, toTarget.z);
                    if (toTargetHoriz.lengthSquared() > 0.001) {
                        toTargetHoriz = toTargetHoriz.normalize();
                        if (toTargetHoriz.dotProduct(forwardHeading) < fovLimit) {
                            continue;
                        }
                    }

                    BlockState state = world.getBlockState(mutable);
                    if (!state.isAir() && filter != null && filter.isEligible(world, mutable, state)) {
                        results.add(mutable.toImmutable());
                    }
                }
            }
        }

        // Fallback scan: If no forward candidates found in front sector, scan local 360-degree perimeter
        if (results.isEmpty()) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dy = -halfHeight; dy <= halfHeight + 1; dy++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        mutable.set(playerPos.getX() + dx, playerPos.getY() + dy, playerPos.getZ() + dz);
                        if (boundary != null && !boundary.contains(mutable)) continue;
                        if (!world.isChunkLoaded(mutable)) continue;

                        net.minecraft.util.math.Vec3d targetCenter = net.minecraft.util.math.Vec3d.ofCenter(mutable);
                        double dist = targetCenter.distanceTo(eyePos);
                        if (dist > maxDist || dist < 0.5) continue;

                        BlockState state = world.getBlockState(mutable);
                        if (!state.isAir() && filter != null && filter.isEligible(world, mutable, state)) {
                            results.add(mutable.toImmutable());
                        }
                    }
                }
            }
        }
        return results;
    }
}
