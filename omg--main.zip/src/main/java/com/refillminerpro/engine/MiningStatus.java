package com.refillminerpro.engine;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Distinguishable operating states for the Refill Miner Pro state machine.
 */
public enum MiningStatus {
    IDLE("Idle", Formatting.GRAY),
    SCANNING("Scanning Area", Formatting.YELLOW),
    MINING("Mining Target", Formatting.AQUA),
    TARGET_COMPLETE("Target Complete", Formatting.GREEN),
    RESCANNING("Rescanning", Formatting.GOLD),
    COMPLETE("Completed", Formatting.GREEN),
    ERROR("Error", Formatting.RED),
    PAUSED("Paused", Formatting.YELLOW),
    READY("Ready", Formatting.GREEN),
    MANUAL_HOLDING("Mining (Held)", Formatting.AQUA),
    OUTSIDE_BOUNDARY("Outside Boundary", Formatting.RED),
    FILTER_BLOCKED("Filtered Out", Formatting.GOLD),
    DURABILITY_LOW("Low Durability", Formatting.RED),

    // Backward-compatible aliases
    DISABLED("Disabled", Formatting.RED),
    ENABLED("Active", Formatting.GREEN),
    WAITING_FOR_REFILLS("Waiting for Refills", Formatting.GOLD),
    TEMPORARILY_BLOCKED("Temporarily Blocked", Formatting.LIGHT_PURPLE),
    INVALID_SELECTION("Invalid Selection", Formatting.DARK_RED);

    private final String label;
    private final Formatting formatting;

    MiningStatus(String label, Formatting formatting) {
        this.label = label;
        this.formatting = formatting;
    }

    public String getLabel() {
        return label;
    }

    public Formatting getFormatting() {
        return formatting;
    }

    public Text getFormattedText() {
        return Text.literal(label).formatted(formatting);
    }
}
