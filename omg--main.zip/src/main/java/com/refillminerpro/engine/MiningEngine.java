package com.refillminerpro.engine;

import com.refillminerpro.client.rotation.SmoothRotationController;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.MovementSmoothness;
import com.refillminerpro.config.RecoveryMode;
import com.refillminerpro.config.TargetPriority;
import com.refillminerpro.pathfinding.*;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Reliable Mining Engine for Refill Miner Pro (Minecraft 1.21.11 Fabric).
 * Features:
 * - Deterministic initial area scan and ordered target queue
 * - Strict state machine: IDLE, SCANNING, MINING, RESCANNING, COMPLETE, ERROR, PAUSED
 * - Zero fallback rotation loops: rotates ONLY when aimed at a valid reachable target
 * - Anti-kick protection: attack key and packets emitted only when crosshair is verified on target
 * - Tool-aware mining speed (Efficiency V & full status mechanics)
 * - True first-wall voxel raycast line-of-sight validation
 */
public class MiningEngine {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/MiningEngine");

    private final ModConfig config;
    private final BlockFilter filter;
    private final AStarPathfinder pathfinder;
    private final SmoothRotationController rotationController;
    private final AreaScanner areaScanner;

    // Deterministic ordered target queue and fast O(1) membership set
    private final List<BlockPos> targetQueue = Collections.synchronizedList(new ArrayList<>());
    private final Set<BlockPos> targetLookupSet = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<BlockPos> refilledTargets = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<BlockPos> unreachableTargets = Collections.newSetFromMap(new ConcurrentHashMap<>());

    // Cooldown and retry tracking
    private final Map<BlockPos, Long> retryCooldowns = new ConcurrentHashMap<>();
    private final Map<BlockPos, Integer> retryCounts = new ConcurrentHashMap<>();

    private BlockPos currentTarget = null;
    private Direction currentTargetFace = null;
    private int currentTargetMiningTicks = 0;
    private int expectedMiningDurationTicks = 1;
    private int consecutiveTargetFailures = 0;
    public static final int MAX_CONSECUTIVE_FAILURES = 3;

    // Explicit 10-state mining lifecycle
    private MiningState miningState = MiningState.IDLE;
    private int failedTargetsCount = 0;
    private int alignmentTicks = 0;
    private int waitingUpdateTicks = 0;
    private int validatingTicks = 0;
    private int temporarilyBlockedTicks = 0;
    private Vec3d lastAdvancePos = null;
    private int advanceStuckTicks = 0;
    private long advanceTickCounter = 0;

    // Stable 6x3 Area-Mining Footprint tracking
    private BlockPos activeFootprintAnchor = null;
    private final List<BlockPos> activeFootprint = new ArrayList<>();

    // Navigation and path follower state
    private NavigationState navState = NavigationState.IDLE;
    private PathResult activePath = null;
    private int currentPathIndex = 0;
    private int pathStuckTicks = 0;
    private int recalculateCooldown = 0;
    private int obstructionTicks = 0;
    private final Set<BlockPos> serverRestrictedTargets = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Map<BlockPos, Long> serverRestrictedCooldowns = new ConcurrentHashMap<>();
    private int consecutiveServerRestrictions = 0;
    private long lastRestrictionWarningMs = 0;
    private boolean isHandlingServerRestriction = false;
    private long lastInteractionTimeMs = 0;
    private BlockPos lastAttemptedTarget = null;

    private MiningStatus status = MiningStatus.IDLE;
    private Text statusDetail = Text.literal("Mod idle.").formatted(Formatting.GRAY);
    private BlockRegion activeRegion = null;
    private int initialBatchTargetCount = 0;

    // Session statistics
    private long sessionMinedBlocks = 0;

    public MiningEngine(ModConfig config, BlockFilter filter) {
        this.config = config;
        this.filter = filter;
        this.pathfinder = new AStarPathfinder(config);
        this.rotationController = new SmoothRotationController(config);
        this.areaScanner = new AreaScanner(filter);
    }

    public SmoothRotationController getRotationController() {
        return rotationController;
    }

    public NavigationState getNavigationState() {
        return navState;
    }

    public AreaScanner getAreaScanner() {
        return areaScanner;
    }

    public synchronized void setActiveRegion(BlockRegion region) {
        boolean changed = !Objects.equals(this.activeRegion, region);
        this.activeRegion = region;
        if (region != null && config.isAutoMineEnabled() && (changed || targetQueue.isEmpty())) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.world != null) {
                startAreaScan(client.world);
            }
        }
    }

    public BlockRegion getActiveRegion() {
        return activeRegion;
    }

    /**
     * Initiates a deterministic upfront area scan of the active region.
     */
    public synchronized void startAreaScan(ClientWorld world) {
        if (activeRegion == null) {
            status = MiningStatus.IDLE;
            statusDetail = Text.literal("No active region selected.").formatted(Formatting.RED);
            return;
        }

        if (world == null) {
            status = MiningStatus.ERROR;
            statusDetail = Text.literal("Error — World is not available.").formatted(Formatting.RED);
            return;
        }

        filter.updateCache();
        targetQueue.clear();
        targetLookupSet.clear();
        refilledTargets.clear();
        unreachableTargets.clear();
        retryCooldowns.clear();
        retryCounts.clear();
        consecutiveTargetFailures = 0;
        consecutiveServerRestrictions = 0;
        serverRestrictedTargets.clear();
        serverRestrictedCooldowns.clear();
        initialBatchTargetCount = 0;

        cancelCurrentMining(MinecraftClient.getInstance());

        status = MiningStatus.SCANNING;
        navState = NavigationState.IDLE;
        statusDetail = Text.literal(String.format("Scanning — 0 / %,d positions", activeRegion.getVolume())).formatted(Formatting.YELLOW);
        areaScanner.startScan(activeRegion, world);
    }

    /**
     * Refreshes targets in the active region without clearing session statistics.
     */
    public synchronized void rescanArea(ClientWorld world) {
        if (activeRegion == null || world == null) return;
        filter.updateCache();
        cancelCurrentMining(MinecraftClient.getInstance());
        status = MiningStatus.RESCANNING;
        navState = NavigationState.IDLE;
        statusDetail = Text.literal("Refreshing region targets...").formatted(Formatting.GOLD);
        areaScanner.startScan(activeRegion, world);
    }

    public synchronized boolean enqueueTarget(BlockPos pos, boolean highPriority) {
        if (pos == null) return false;
        BlockPos immutable = pos.toImmutable();

        if (activeRegion != null && !activeRegion.contains(immutable)) {
            return false;
        }

        Long cooldownEnd = retryCooldowns.get(immutable);
        if (cooldownEnd != null) {
            if (System.currentTimeMillis() < cooldownEnd) {
                return false;
            } else {
                retryCooldowns.remove(immutable);
            }
        }

        if (targetLookupSet.contains(immutable) || immutable.equals(currentTarget)) {
            return false;
        }

        if (targetLookupSet.size() >= config.getMaxQueuedTargets()) {
            return false;
        }

        targetLookupSet.add(immutable);
        unreachableTargets.remove(immutable);

        if (highPriority) {
            targetQueue.add(0, immutable);
            refilledTargets.add(immutable);
        } else {
            targetQueue.add(immutable);
        }

        if (status == MiningStatus.COMPLETE || status == MiningStatus.WAITING_FOR_REFILLS) {
            status = MiningStatus.MINING;
            statusDetail = Text.literal("New target detected. Resuming mining.").formatted(Formatting.AQUA);
        }
        return true;
    }

    public synchronized void removeTarget(BlockPos pos) {
        if (pos == null) return;
        targetLookupSet.remove(pos);
        targetQueue.remove(pos);
        refilledTargets.remove(pos);
        unreachableTargets.remove(pos);
        if (pos.equals(currentTarget)) {
            cancelCurrentMining(MinecraftClient.getInstance());
        }
    }

    public boolean isTargetQueuedOrActive(BlockPos pos) {
        if (pos == null) return false;
        return pos.equals(currentTarget) || targetLookupSet.contains(pos);
    }

    public synchronized void onTargetBroken(BlockPos pos) {
        if (pos == null) return;
        boolean wasCurrent = pos.equals(currentTarget);
        boolean wasQueued = targetLookupSet.remove(pos);
        targetQueue.remove(pos);
        refilledTargets.remove(pos);
        unreachableTargets.remove(pos);
        retryCooldowns.remove(pos);
        retryCounts.remove(pos);
        consecutiveTargetFailures = 0; // Success resets failure streak

        if (wasCurrent || wasQueued) {
            sessionMinedBlocks++;
            if (wasCurrent) {
                currentTarget = null;
                currentTargetFace = null;
                currentTargetMiningTicks = 0;
                activePath = null;
                currentPathIndex = 0;
                pathStuckTicks = 0;
                obstructionTicks = 0;
            }
            LOGGER.debug("Target successfully mined at [{}, {}, {}]. Total: {}", pos.getX(), pos.getY(), pos.getZ(), sessionMinedBlocks);
        }
    }

    public synchronized void reset(boolean resetStats) {
        targetQueue.clear();
        targetLookupSet.clear();
        refilledTargets.clear();
        unreachableTargets.clear();
        retryCooldowns.clear();
        retryCounts.clear();
        consecutiveTargetFailures = 0;
        consecutiveServerRestrictions = 0;
        serverRestrictedTargets.clear();
        serverRestrictedCooldowns.clear();
        initialBatchTargetCount = 0;
        areaScanner.reset();

        cancelCurrentMining(MinecraftClient.getInstance());

        if (resetStats) {
            sessionMinedBlocks = 0;
            activeRegion = null; // Crucial: clear runtime active region
        }

        com.refillminerpro.client.RefillMinerClient cInst = com.refillminerpro.client.RefillMinerClient.getInstance();
        if (cInst != null && cInst.getAutoStorageEngine() != null) {
            cInst.getAutoStorageEngine().resetAllVaultsCompleted();
        }

        status = MiningStatus.IDLE;
        miningState = MiningState.IDLE;
        failedTargetsCount = 0;
        alignmentTicks = 0;
        waitingUpdateTicks = 0;
        validatingTicks = 0;
        lastAdvancePos = null;
        advanceStuckTicks = 0;
        activeFootprintAnchor = null;
        activeFootprint.clear();
        navState = NavigationState.IDLE;
        statusDetail = Text.literal("Auto Mine is disabled.").formatted(Formatting.RED);
    }

    public void tick(MinecraftClient client) {
        if (client == null || client.world == null || client.player == null) {
            cancelCurrentMining(client);
            return;
        }

        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;

        // Anti-kick / GUI protection: Never tick mining actions when non-handled screens are open
        if (client.currentScreen != null && !(client.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen)) {
            stopAttacking(client);
            stopWalking(client);
            rotationController.clearTarget();
            currentTarget = null;
            return;
        }

        // Auto Storage Active & Inventory Threshold Check
        com.refillminerpro.client.RefillMinerClient clientInstance = com.refillminerpro.client.RefillMinerClient.getInstance();
        if (clientInstance != null && clientInstance.getAutoStorageEngine() != null) {
            com.refillminerpro.storage.AutoStorageEngine storageEngine = clientInstance.getAutoStorageEngine();
            com.refillminerpro.storage.AutoStorageConfig storageConfig = clientInstance.getConfig().getAutoStorage();

            if (storageEngine.isBusy()) {
                stopWalking(client);
                stopAttacking(client);
                rotationController.clearTarget();
                statusDetail = Text.literal("Paused for Auto Storage: " + storageEngine.getStatusDetail().getString()).formatted(Formatting.GOLD);
                return;
            }

            if (config.isAutoMineEnabled() && !config.isPaused() && storageConfig.isEnabled() && !storageConfig.isPaused() && !storageEngine.isAllVaultsCompleted()) {
                if (com.refillminerpro.storage.InventoryHelper.isThresholdReached(player.getInventory(), storageConfig)) {
                    cancelCurrentMining(client);
                    stopWalking(client);
                    stopAttacking(client);
                    rotationController.clearTarget();
                    statusDetail = Text.literal("Inventory full — Pausing for Auto Storage").formatted(Formatting.GOLD);
                    storageEngine.startStorageWorkflow(client);
                    return;
                }
            }
        }

        // Operating Mode Check: Automation only permitted in singleplayer or verified authorized servers
        if (!com.refillminerpro.client.RefillMinerClient.getInstance().getCurrentOperatingMode().isAutoMineAllowed()) {
            if (config.isAutoMineEnabled()) {
                config.setAutoMineEnabled(false);
                cancelCurrentMining(client);
                status = MiningStatus.DISABLED;
                navState = NavigationState.IDLE;
                statusDetail = Text.literal("Automation disabled on unauthorized server (Utility Only mode active).").formatted(Formatting.RED);
            }
            return;
        }

        // Disabled Check
        if (!config.isAutoMineEnabled()) {
            if (status != MiningStatus.IDLE && status != MiningStatus.DISABLED) {
                cancelCurrentMining(client);
                status = MiningStatus.IDLE;
                navState = NavigationState.IDLE;
                statusDetail = Text.literal("Mining assistance disabled.").formatted(Formatting.RED);
            }
            return;
        }

        // Pause Check
        if (config.isPaused()) {
            if (status != MiningStatus.PAUSED) {
                cancelCurrentMining(client);
                status = MiningStatus.PAUSED;
                navState = NavigationState.PAUSED;
                statusDetail = Text.literal("Mining assistance paused.").formatted(Formatting.YELLOW);
            }
            return;
        }

        // Check if player explicitly configured manual crosshair assist workflow
        if (config.isPlayerControlledMining()) {
            tickPlayerControlledMining(client, player, world, interactionManager);
            return;
        }

        tickAutonomousMining(client, player, world, interactionManager);
    }

    private void tickPlayerControlledMining(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        // Guarantee camera rotation and automated walking are completely cleared
        rotationController.clearTarget();
        stopWalking(client);
        navState = NavigationState.IDLE;

        // 1. Inspect player crosshair target
        HitResult hit = client.crosshairTarget;
        BlockPos crosshairPos = null;
        Direction hitFace = null;
        BlockState crosshairState = null;

        if (hit instanceof BlockHitResult blockHit && hit.getType() == HitResult.Type.BLOCK) {
            crosshairPos = blockHit.getBlockPos();
            hitFace = blockHit.getSide();
            if (world.isChunkLoaded(crosshairPos)) {
                crosshairState = world.getBlockState(crosshairPos);
            }
        }

        // Update diagnostic tracking for HUD, GUI, and live inspector
        MiningDebugInfo.crosshairPos = crosshairPos;
        MiningDebugInfo.crosshairBlockName = (crosshairState != null && !crosshairState.isAir())
                ? crosshairState.getBlock().getName().getString() : "None";

        boolean insideBoundary = (activeRegion == null) || (crosshairPos != null && activeRegion.contains(crosshairPos));
        MiningDebugInfo.crosshairInsideBoundary = insideBoundary;

        boolean filterEligible = (crosshairPos != null && crosshairState != null && !crosshairState.isAir())
                && filter.isEligible(world, crosshairPos, crosshairState);
        MiningDebugInfo.crosshairFilterEligible = filterEligible;

        boolean isPhysicallyHoldingAttack = client.options.attackKey.isPressed();
        MiningDebugInfo.isHoldingAttack = isPhysicallyHoldingAttack;
        MiningDebugInfo.manualAssistanceActive = true;

        // If player is NOT holding attack:
        if (!isPhysicallyHoldingAttack) {
            currentTarget = null;
            currentTargetFace = null;
            currentTargetMiningTicks = 0;
            MiningDebugInfo.currentTarget = null;
            MiningDebugInfo.miningState = MiningState.IDLE;
            status = MiningStatus.READY;
            statusDetail = Text.literal("Ready — Aim and hold left-click to mine").formatted(Formatting.GREEN);
            return;
        }

        // Player IS holding left click!
        if (crosshairPos == null || crosshairState == null || crosshairState.isAir()) {
            currentTarget = null;
            currentTargetFace = null;
            currentTargetMiningTicks = 0;
            MiningDebugInfo.currentTarget = null;
            status = MiningStatus.IDLE;
            statusDetail = Text.literal("Aiming at air or out of range").formatted(Formatting.GRAY);
            return;
        }

        // Boundary constraint check
        if (config.isEnforceAreaBoundary() && activeRegion != null && !activeRegion.contains(crosshairPos)) {
            client.options.attackKey.setPressed(false);
            currentTarget = null;
            currentTargetMiningTicks = 0;
            status = MiningStatus.OUTSIDE_BOUNDARY;
            statusDetail = Text.literal("Target outside selected boundary!").formatted(Formatting.RED);
            return;
        }

        // Filter eligibility check
        if (!filter.isEligible(world, crosshairPos, crosshairState)) {
            currentTarget = null;
            currentTargetMiningTicks = 0;
            status = MiningStatus.FILTER_BLOCKED;
            statusDetail = Text.literal("Block filtered out (" + crosshairState.getBlock().getName().getString() + ")").formatted(Formatting.GOLD);
            return;
        }

        // Durability protection check
        ItemStack held = player.getMainHandStack();
        if (config.isProtectLowDurability() && held != null && held.isDamageable()) {
            int remaining = held.getMaxDamage() - held.getDamage();
            if (remaining <= config.getMinDurabilityThreshold()) {
                if (config.isAutoSwitchTool()) {
                    selectBestToolInHotbar(player, crosshairState, world, crosshairPos);
                    held = player.getMainHandStack();
                    if (held != null && held.isDamageable() && (held.getMaxDamage() - held.getDamage()) <= config.getMinDurabilityThreshold()) {
                        client.options.attackKey.setPressed(false);
                        status = MiningStatus.DURABILITY_LOW;
                        statusDetail = Text.literal("Tool durability low (" + remaining + ") — mining stopped to protect tool!").formatted(Formatting.RED);
                        return;
                    }
                } else {
                    client.options.attackKey.setPressed(false);
                    status = MiningStatus.DURABILITY_LOW;
                    statusDetail = Text.literal("Tool durability low (" + remaining + ") — mining stopped to protect tool!").formatted(Formatting.RED);
                    return;
                }
            }
        }

        // Auto Switch Tool (if enabled)
        if (config.isAutoSwitchTool()) {
            selectBestToolInHotbar(player, crosshairState, world, crosshairPos);
        }

        // Track active mining target and duration
        if (currentTarget == null || !currentTarget.equals(crosshairPos)) {
            currentTarget = crosshairPos;
            currentTargetFace = hitFace;
            currentTargetMiningTicks = 0;
            expectedMiningDurationTicks = Math.max(1, (int) Math.ceil(1.0f / crosshairState.calcBlockBreakingDelta(player, world, crosshairPos)));
        } else {
            currentTargetMiningTicks++;
        }

        MiningDebugInfo.currentTarget = currentTarget;
        MiningDebugInfo.miningState = MiningState.MINING_IN_PROGRESS;
        MiningDebugInfo.currentMiningTicks = currentTargetMiningTicks;
        MiningDebugInfo.expectedDurationTicks = expectedMiningDurationTicks;
        MiningDebugInfo.miningProgressPercent = Math.min(100, (int) ((float) currentTargetMiningTicks / expectedMiningDurationTicks * 100.0f));

        status = MiningStatus.MANUAL_HOLDING;
        statusDetail = Text.literal(String.format("Mining %s at [%d, %d, %d]",
                crosshairState.getBlock().getName().getString(),
                crosshairPos.getX(), crosshairPos.getY(), crosshairPos.getZ())).formatted(Formatting.AQUA);
    }

    public synchronized void onBlockStateChanged(BlockPos pos, BlockState newState) {
        if (pos == null) return;
        if (pos.equals(currentTarget) && (newState == null || newState.isAir())) {
            miningState = MiningState.CONFIRMING_COMPLETION;
            status = MiningStatus.TARGET_COMPLETE;
            statusDetail = Text.literal("Block mined successfully!").formatted(Formatting.GREEN);
        }
    }

    private void tickAutonomousMining(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        // Region Check: Automation cannot run without an active region selection in this session
        if (activeRegion == null) {
            if (status != MiningStatus.IDLE) {
                cancelCurrentMining(client);
                status = MiningStatus.IDLE;
                navState = NavigationState.IDLE;
                statusDetail = Text.literal("No active region selected.").formatted(Formatting.RED);
            }
            return;
        }

        long now = System.currentTimeMillis();
        retryCooldowns.entrySet().removeIf(entry -> entry.getValue() <= now);
        // Periodically clear unreachable set so blocks get a fresh chance after player moves
        if (advanceTickCounter % 200 == 0) {
            unreachableTargets.clear();
        }
        serverRestrictedCooldowns.entrySet().removeIf(entry -> {
            if (entry.getValue() <= now) {
                serverRestrictedTargets.remove(entry.getKey());
                LOGGER.debug("Server protection cooldown expired for position [{}, {}, {}]. Restored for mining.",
                        entry.getKey().getX(), entry.getKey().getY(), entry.getKey().getZ());
                return true;
            }
            return false;
        });
        MiningDebugInfo.serverRestrictedCount = serverRestrictedCooldowns.size();

        if (recalculateCooldown > 0) {
            recalculateCooldown--;
        }

        // Dynamic queue re-sort: keep nearest targets at front as player moves
        advanceTickCounter++;
        if (advanceTickCounter % 40 == 0 && !targetQueue.isEmpty() && player != null) {
            Vec3d sortEyePos = player.getEyePos();
            BlockPos sortFoot = player.getBlockPos();
            synchronized (targetQueue) {
                List<BlockPos> snapshot = new ArrayList<>(targetQueue);
                sortCandidates(snapshot, config.getTargetPriority(), sortEyePos, sortFoot);
                targetQueue.clear();
                targetQueue.addAll(snapshot);
            }
        }

        // 1. SCANNING / RESCANNING PHASE
        if (status == MiningStatus.SCANNING || status == MiningStatus.RESCANNING) {
            stopWalking(client);
            stopAttacking(client);
            rotationController.clearTarget();

            int batchSize = config.getScanBatchSize();
            boolean scanFinished = areaScanner.stepScan(world, batchSize);

            if (!scanFinished) {
                long scanned = areaScanner.getScannedBlocks();
                long total = areaScanner.getTotalBlocks();
                int pct = (int) (areaScanner.getProgress() * 100.0f);
                statusDetail = Text.literal(String.format("Scanning — %,d / %,d positions (%d%%)", scanned, total, pct)).formatted(Formatting.YELLOW);
                return;
            }

            // Check if scan encountered an exception
            if (areaScanner.hasError()) {
                status = MiningStatus.ERROR;
                navState = NavigationState.IDLE;
                String err = areaScanner.getLastErrorMessage();
                statusDetail = Text.literal("Error — " + (err.isEmpty() ? "Scan failed" : err)).formatted(Formatting.RED);
                LOGGER.error("Area scan encountered error: {}", err);
                return;
            }

            // Scan completed deterministically
            List<BlockPos> detected = areaScanner.getDetectedTargets();
            targetQueue.clear();
            targetLookupSet.clear();
            unreachableTargets.clear();
            failedTargetsCount = 0;

            if (detected.isEmpty()) {
                status = MiningStatus.COMPLETE;
                miningState = MiningState.IDLE;
                navState = NavigationState.IDLE;
                String reason = areaScanner.getLastReasonForZeroTargets();
                statusDetail = Text.literal((reason != null && !reason.isEmpty()) ? "Complete — " + reason : "Complete — No eligible blocks found").formatted(Formatting.GREEN);
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("Auto Mine: Scan complete — " + ((reason != null && !reason.isEmpty()) ? reason : "No eligible blocks found in area.")).formatted(Formatting.YELLOW), false);
                }
                return;
            }

            // Sort detected targets deterministically according to strategy
            sortCandidates(detected, config.getTargetPriority(), player.getEyePos(), player.getBlockPos());
            for (BlockPos pos : detected) {
                targetLookupSet.add(pos);
                targetQueue.add(pos);
            }
            initialBatchTargetCount = targetQueue.size();

            status = MiningStatus.MINING;
            miningState = MiningState.SELECTING_NEXT_TARGET;
            navState = NavigationState.IDLE;
            statusDetail = Text.literal(String.format("Ready — %d targets found", targetQueue.size())).formatted(Formatting.AQUA);

            if (client.player != null) {
                client.player.sendMessage(Text.literal(String.format("Auto Mine: Scan finished! Found %d targets. Starting mining...", targetQueue.size())).formatted(Formatting.GREEN), false);
            }
            return;
        }

        // 2. COMPLETE PHASE (Clean idle state, zero residual rotation)
        if (status == MiningStatus.COMPLETE) {
            stopWalking(client);
            stopAttacking(client);
            rotationController.clearTarget();
            miningState = MiningState.IDLE;

            if (!targetQueue.isEmpty() || currentTarget != null) {
                status = MiningStatus.MINING;
                miningState = MiningState.SELECTING_NEXT_TARGET;
            } else {
                statusDetail = Text.literal("Completed: All eligible blocks cleared.").formatted(Formatting.GREEN);
                return;
            }
        }

        // 3. EXPLICIT 10-STATE MINING CONTROLLER
        MiningDebugInfo.miningState = this.miningState;
        MiningDebugInfo.currentTarget = this.currentTarget;
        MiningDebugInfo.queuedTargetsCount = this.targetLookupSet.size();
        MiningDebugInfo.pendingTargetsCount = this.targetLookupSet.size();
        MiningDebugInfo.completedTargetsCount = (int) this.sessionMinedBlocks;
        MiningDebugInfo.failedTargetsCount = this.failedTargetsCount;

        switch (miningState) {
            case IDLE -> {
                stopWalking(client);
                stopAttacking(client);
                rotationController.clearTarget();
                if (config.isAutoMineEnabled() && activeRegion != null && !targetQueue.isEmpty()) {
                    miningState = MiningState.SELECTING_NEXT_TARGET;
                }
            }
            case PAUSED -> {
                stopWalking(client);
                stopAttacking(client);
                rotationController.clearTarget();
                if (!config.isPaused()) {
                    miningState = (currentTarget != null) ? MiningState.VALIDATING_TARGET : MiningState.SELECTING_NEXT_TARGET;
                }
            }
            case SELECTING_NEXT_TARGET -> {
                stopAttacking(client);
                statusDetail = Text.literal("Finding Eligible Block...").formatted(Formatting.AQUA);
                currentTarget = selectNextTarget(player, world);
                currentTargetMiningTicks = 0;
                alignmentTicks = 0;
                waitingUpdateTicks = 0;
                validatingTicks = 0;

                if (currentTarget != null) {
                    temporarilyBlockedTicks = 0;
                }

                if (currentTarget == null) {
                    stopAttacking(client);
                    stopWalking(client);
                    rotationController.clearTarget();

                    boolean hasCooldowns = !serverRestrictedCooldowns.isEmpty() || !retryCooldowns.isEmpty();
                    if (targetQueue.isEmpty() && !hasCooldowns) {
                        // Before declaring complete, verify the region actually has no remaining blocks
                        if (activeRegion != null && client.world != null && regionStillHasEligibleBlocks(client.world)) {
                            // Region still has blocks – trigger a full rescan to rediscover them
                            LOGGER.info("Queue empty but region still has eligible blocks. Triggering rescan...");
                            rescanArea(client.world);
                            return;
                        }
                        status = MiningStatus.COMPLETE;
                        miningState = MiningState.IDLE;
                        navState = NavigationState.IDLE;
                        statusDetail = Text.literal("No Eligible Blocks Found").formatted(Formatting.GREEN);
                        return;
                    }
                    status = MiningStatus.TEMPORARILY_BLOCKED;
                    navState = NavigationState.TEMPORARILY_BLOCKED;
                    if (!serverRestrictedCooldowns.isEmpty()) {
                        statusDetail = Text.literal(String.format("Waiting: %d blocks server-protected (cooling down)", serverRestrictedCooldowns.size())).formatted(Formatting.GOLD);
                    } else {
                        statusDetail = Text.literal("Waiting: Targets unreachable or on cooldown").formatted(Formatting.LIGHT_PURPLE);
                    }
                    // Stuck temporarily blocked: try navigating toward remaining blocks in region
                    temporarilyBlockedTicks++;
                    if (temporarilyBlockedTicks >= 60 && activeRegion != null && client.world != null) {
                        temporarilyBlockedTicks = 0;
                        BlockPos nearestRemaining = findNearestEligibleInRegion(player, client.world);
                        if (nearestRemaining != null) {
                            LOGGER.info("Navigating to distant remaining block at [{}, {}, {}]",
                                nearestRemaining.getX(), nearestRemaining.getY(), nearestRemaining.getZ());
                            if (!targetLookupSet.contains(nearestRemaining)) {
                                enqueueTarget(nearestRemaining, true);
                            }
                            currentTarget = nearestRemaining;
                            currentTargetFace = null;
                            validatingTicks = 0;
                            miningState = MiningState.VALIDATING_TARGET;
                            status = MiningStatus.MINING;
                        } else if (regionStillHasEligibleBlocks(client.world)) {
                            rescanArea(client.world);
                        }
                    }
                    return;
                }

                status = MiningStatus.MINING;
                miningState = MiningState.VALIDATING_TARGET;
                tickValidatingTarget(client, player, world);
            }
            case VALIDATING_TARGET -> {
                tickValidatingTarget(client, player, world);
            }
            case ALIGNING_WITH_TARGET -> {
                tickAligningWithTarget(client, player);
            }
            case STARTING_MINING -> {
                tickStartingMining(client, player, world, interactionManager);
            }
            case MINING_IN_PROGRESS -> {
                tickMiningInProgress(client, player, world, interactionManager);
            }
            case WAITING_FOR_BLOCK_UPDATE -> {
                tickWaitingForBlockUpdate(client, world);
            }
            case CONFIRMING_COMPLETION -> {
                tickConfirmingCompletion(client);
            }
            case RECOVERING_FROM_FAILURE -> {
                tickRecoveringFromFailure(client);
            }
        }
    }

    private void tickValidatingTarget(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (currentTarget == null) {
            miningState = MiningState.SELECTING_NEXT_TARGET;
            return;
        }

        if (!world.isChunkLoaded(currentTarget)) {
            recordSkipReason("Chunk not loaded");
            miningState = MiningState.RECOVERING_FROM_FAILURE;
            return;
        }

        BlockState targetState = world.getBlockState(currentTarget);
        if (targetState.isAir()) {
            miningState = MiningState.CONFIRMING_COMPLETION;
            return;
        }

        if (!filter.isEligible(world, currentTarget, targetState)) {
            targetQueue.remove(currentTarget);
            targetLookupSet.remove(currentTarget);
            currentTarget = null;
            miningState = MiningState.SELECTING_NEXT_TARGET;
            return;
        }

        double maxReach = getPlayerBlockReach(player);
        Vec3d eyePos = player.getEyePos();
        if (currentTargetFace == null) {
            currentTargetFace = findBestExposedFace(world, currentTarget, eyePos);
        }
        if (currentTargetFace == null) {
            recordSkipReason("Target has no exposed face");
            miningState = MiningState.RECOVERING_FROM_FAILURE;
            return;
        }

        Vec3d targetPoint = getFaceCenter(currentTarget, currentTargetFace);
        double distanceToFace = eyePos.distanceTo(targetPoint);
        double comfortableReach = Math.min(maxReach - 0.4, config.getTargetReachPreference());
        boolean canMove = config.isAutoNavigate() || config.isAutoWalk() || config.isAutoAdvance();

        // Hard reject: if block is beyond max reach and no movement enabled, skip immediately
        if (distanceToFace > maxReach + 1.0) {
            if (!canMove) {
                recordSkipReason(String.format("Hard out-of-range (dist: %.1f, maxReach: %.1f)", distanceToFace, maxReach));
                miningState = MiningState.RECOVERING_FROM_FAILURE;
                return;
            }
        }

        boolean hasLineOfSight = hasLineOfSightToTarget(world, eyePos, currentTarget);

        MiningDebugInfo.distanceToTarget = distanceToFace;
        MiningDebugInfo.withinReach = (distanceToFace <= maxReach);
        MiningDebugInfo.lineOfSightValid = hasLineOfSight;

        if (distanceToFace > comfortableReach || (!hasLineOfSight && canMove)) {
            stopAttacking(client);
            validatingTicks++;
            if (validatingTicks > 25) {
                recordSkipReason("Approach/validation timeout (taking >2s to reach target)");
                stopWalking(client);
                validatingTicks = 0;
                lastAdvancePos = null;
                advanceStuckTicks = 0;
                if (currentTarget != null) {
                    retryCooldowns.put(currentTarget, System.currentTimeMillis() + 2500L);
                    targetQueue.remove(currentTarget);
                    targetQueue.add(currentTarget);
                }
                currentTarget = null;
                miningState = MiningState.SELECTING_NEXT_TARGET;
                return;
            }

            if (config.isAutoNavigate()) {
                handleNavigation(client, player, world, maxReach);
                return;
            } else if (config.isAutoAdvance()) {
                updateMovementAndAdvance(client, player, world);
                return;
            } else if (config.isAutoWalk()) {
                handleDirectWalk(client, player, targetPoint, maxReach);
                return;
            } else {
                recordSkipReason(String.format("Out of reach or obstructed (dist: %.1f, los: %b)", distanceToFace, hasLineOfSight));
                miningState = MiningState.RECOVERING_FROM_FAILURE;
                return;
            }
        }

        if (!config.isAutoAdvance()) {
            stopWalking(client);
        } else {
            updateMovementAndAdvance(client, player, world);
        }

        // Line of sight check: ensure target face has unobstructed view
        if (config.isCheckLineOfSight() && !isCrosshairOnTarget(client, currentTarget)) {
            HitResult hit = world.raycast(new RaycastContext(
                    eyePos, targetPoint,
                    RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE,
                    player
            ));
            if (hit.getType() == HitResult.Type.BLOCK) {
                BlockHitResult blockHit = (BlockHitResult) hit;
                BlockPos hitPos = blockHit.getBlockPos();
                if (!hitPos.equals(currentTarget)) {
                    MiningDebugInfo.lineOfSightValid = false;
                    MiningDebugInfo.firstObstructingBlock = hitPos;

                    // Check if an alternate exposed face of the same target has clear line of sight
                    Direction altFace = findVisibleExposedFace(world, currentTarget, eyePos);
                    if (altFace != null) {
                        currentTargetFace = altFace;
                        targetPoint = getFaceCenter(currentTarget, currentTargetFace);
                        MiningDebugInfo.lineOfSightValid = true;
                        MiningDebugInfo.firstObstructingBlock = null;
                        obstructionTicks = 0;
                    } else {
                        obstructionTicks++;
                        if (obstructionTicks > 4) {
                            recordSkipReason("Obstructed by " + world.getBlockState(hitPos).getBlock().getName().getString() + " at [" + hitPos.getX() + "," + hitPos.getY() + "," + hitPos.getZ() + "]");
                            miningState = MiningState.RECOVERING_FROM_FAILURE;
                            return;
                        }
                        stopAttacking(client);
                        return;
                    }
                }
            }
        }
        MiningDebugInfo.lineOfSightValid = true;
        MiningDebugInfo.firstObstructingBlock = null;
        obstructionTicks = 0;

        miningState = MiningState.ALIGNING_WITH_TARGET;
        tickAligningWithTarget(client, player);
    }

    private void tickAligningWithTarget(MinecraftClient client, ClientPlayerEntity player) {
        if (currentTarget == null) {
            miningState = MiningState.SELECTING_NEXT_TARGET;
            return;
        }

        if (client.world != null) {
            updateMovementAndAdvance(client, player, client.world);
        }

        if (currentTargetFace == null && client.world != null) {
            currentTargetFace = findBestExposedFace(client.world, currentTarget, player.getEyePos());
        }
        Vec3d targetPoint = getFaceCenter(currentTarget, currentTargetFace);
        rotationController.setTarget(targetPoint, currentTarget);
        stopAttacking(client);
        statusDetail = Text.literal("Aiming at block face...").formatted(Formatting.AQUA);
        MiningDebugInfo.rotationReady = false;

        if (isAimedAt(client, player, currentTarget, targetPoint)) {
            if (client.crosshairTarget instanceof BlockHitResult hit && hit.getBlockPos().equals(currentTarget)) {
                currentTargetFace = hit.getSide();
            }
            MiningDebugInfo.rotationReady = true;
            alignmentTicks = 0;
            miningState = MiningState.STARTING_MINING;
            if (client.interactionManager != null && client.world != null) {
                tickStartingMining(client, player, client.world, client.interactionManager);
            }
        } else {
            alignmentTicks++;
            if (alignmentTicks > 40) {
                recordSkipReason("Aim alignment timeout");
                miningState = MiningState.RECOVERING_FROM_FAILURE;
            }
        }
    }

    private void tickStartingMining(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        if (currentTarget == null || world == null) {
            miningState = MiningState.SELECTING_NEXT_TARGET;
            return;
        }

        updateMovementAndAdvance(client, player, world);

        BlockState targetState = world.getBlockState(currentTarget);
        if (targetState.isAir()) {
            miningState = MiningState.CONFIRMING_COMPLETION;
            return;
        }

        if (config.isAutoSwitchTool()) {
            selectBestToolInHotbar(player, targetState, world, currentTarget);
        }

        if (config.isProtectLowDurability()) {
            ItemStack held = player.getMainHandStack();
            if (held != null && held.isDamageable()) {
                int remaining = held.getMaxDamage() - held.getDamage();
                if (remaining <= config.getMinDurabilityThreshold()) {
                    status = MiningStatus.PAUSED;
                    miningState = MiningState.PAUSED;
                    config.setPaused(true);
                    statusDetail = Text.literal(String.format("Tool durability low (%d left)! Mining paused to protect tool.", remaining)).formatted(Formatting.RED);
                    cancelCurrentMining(client);
                    return;
                }
            }
        }

        if (client.crosshairTarget instanceof BlockHitResult hit && hit.getBlockPos().equals(currentTarget)) {
            currentTargetFace = hit.getSide();
        }
        if (currentTargetFace == null) {
            currentTargetFace = findBestExposedFace(world, currentTarget, player.getEyePos());
        }

        float delta = targetState.calcBlockBreakingDelta(player, world, currentTarget);
        expectedMiningDurationTicks = delta >= 1.0f ? 1 : (int) Math.ceil(1.0f / delta);
        currentTargetMiningTicks = 0;
        waitingUpdateTicks = 0;
        MiningDebugInfo.expectedDurationTicks = expectedMiningDurationTicks;
        MiningDebugInfo.currentTargetFace = (currentTargetFace != null) ? currentTargetFace.name() : "None";
        MiningDebugInfo.wasRejected = false;
        MiningDebugInfo.blockConfirmedRemoved = false;

        client.options.attackKey.setPressed(true);

        lastInteractionTimeMs = System.currentTimeMillis();
        lastAttemptedTarget = currentTarget;

        if (interactionManager != null) {
            interactionManager.attackBlock(currentTarget, currentTargetFace);
            player.swingHand(Hand.MAIN_HAND);
        }

        status = MiningStatus.MINING;
        statusDetail = Text.literal(String.format("Mining %s [%d ticks]",
                targetState.getBlock().getName().getString(),
                expectedMiningDurationTicks)).formatted(Formatting.AQUA);

        if (world.getBlockState(currentTarget).isAir()) {
            miningState = MiningState.CONFIRMING_COMPLETION;
        } else {
            miningState = MiningState.MINING_IN_PROGRESS;
        }
    }

    private void tickMiningInProgress(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        if (currentTarget == null || world == null) {
            miningState = MiningState.SELECTING_NEXT_TARGET;
            return;
        }

        updateMovementAndAdvance(client, player, world);

        BlockState targetState = world.getBlockState(currentTarget);
        if (targetState.isAir()) {
            miningState = MiningState.CONFIRMING_COMPLETION;
            return;
        }

        Vec3d targetPoint = getFaceCenter(currentTarget, currentTargetFace);
        rotationController.setTarget(targetPoint, currentTarget);

        if (!isAimedAt(client, player, currentTarget, targetPoint)) {
            alignmentTicks++;
            if (alignmentTicks > 4) {
                stopAttacking(client);
            }
            if (alignmentTicks > 40) {
                recordSkipReason("Aim alignment lost during mining");
                miningState = MiningState.RECOVERING_FROM_FAILURE;
            }
            return;
        }

        alignmentTicks = 0;
        client.options.attackKey.setPressed(true);

        if (client.crosshairTarget instanceof BlockHitResult hit && hit.getBlockPos().equals(currentTarget)) {
            currentTargetFace = hit.getSide();
            MiningDebugInfo.currentTargetFace = currentTargetFace.name();
        }

        lastInteractionTimeMs = System.currentTimeMillis();
        lastAttemptedTarget = currentTarget;

        if (interactionManager != null) {
            interactionManager.updateBlockBreakingProgress(currentTarget, currentTargetFace);
            if (!player.handSwinging || currentTargetMiningTicks % 4 == 0) {
                player.swingHand(Hand.MAIN_HAND);
            }
        }

        currentTargetMiningTicks++;
        MiningDebugInfo.currentMiningTicks = currentTargetMiningTicks;

        int vanillaProgress = (interactionManager != null) ? interactionManager.getBlockBreakingProgress() : -1;
        MiningDebugInfo.vanillaBreakingProgress = vanillaProgress;
        int progressPct = (vanillaProgress >= 0) ? (vanillaProgress * 10) :
                Math.min(99, (int) ((float) currentTargetMiningTicks / Math.max(1, expectedMiningDurationTicks) * 100.0f));
        MiningDebugInfo.miningProgressPercent = progressPct;

        status = MiningStatus.MINING;
        statusDetail = Text.literal(String.format("Mining %s [%d%%]",
                targetState.getBlock().getName().getString(),
                progressPct)).formatted(Formatting.AQUA);

        if (world.getBlockState(currentTarget).isAir()) {
            miningState = MiningState.CONFIRMING_COMPLETION;
            return;
        }

        if (currentTargetMiningTicks >= expectedMiningDurationTicks) {
            waitingUpdateTicks = 0;
            miningState = MiningState.WAITING_FOR_BLOCK_UPDATE;
        }
    }

    private void tickWaitingForBlockUpdate(MinecraftClient client, ClientWorld world) {
        if (currentTarget == null || world == null) {
            miningState = MiningState.SELECTING_NEXT_TARGET;
            return;
        }

        if (client.player != null) {
            updateMovementAndAdvance(client, client.player, world);
        }

        if (world.getBlockState(currentTarget).isAir()) {
            miningState = MiningState.CONFIRMING_COMPLETION;
            return;
        }

        // Continue holding attack key and updating breaking progress naturally across client ticks
        client.options.attackKey.setPressed(true);
        if (client.interactionManager != null) {
            client.interactionManager.updateBlockBreakingProgress(currentTarget, currentTargetFace);
            if (client.player != null && (!client.player.handSwinging || waitingUpdateTicks % 4 == 0)) {
                client.player.swingHand(Hand.MAIN_HAND);
            }
        }

        waitingUpdateTicks++;
        int vanillaProgress = (client.interactionManager != null) ? client.interactionManager.getBlockBreakingProgress() : -1;
        MiningDebugInfo.vanillaBreakingProgress = vanillaProgress;

        statusDetail = Text.literal(String.format("Breaking %s (finishing)...",
                world.getBlockState(currentTarget).getBlock().getName().getString())).formatted(Formatting.YELLOW);

        int maxWaitTicks = Math.max(expectedMiningDurationTicks + 25, 45);
        if (waitingUpdateTicks > maxWaitTicks) {
            recordSkipReason("Server block break timeout (block breaking rejected or protected)");
            MiningDebugInfo.wasRejected = true;
            miningState = MiningState.RECOVERING_FROM_FAILURE;
        }
    }

    private void tickConfirmingCompletion(MinecraftClient client) {
        if (currentTarget != null) {
            BlockPos broken = currentTarget;
            targetQueue.remove(broken);
            targetLookupSet.remove(broken);
            refilledTargets.remove(broken);
            retryCooldowns.remove(broken);
            retryCounts.remove(broken);
            sessionMinedBlocks++;
            consecutiveTargetFailures = 0;

            MiningDebugInfo.blockConfirmedRemoved = true;
            MiningDebugInfo.completedTargetsCount = (int) sessionMinedBlocks;
            LOGGER.debug("Target confirmed mined at [{}, {}, {}]. Session total: {}",
                    broken.getX(), broken.getY(), broken.getZ(), sessionMinedBlocks);

            currentTarget = null;
            currentTargetFace = null;
        }

        // Continuous Mining: Immediately select and begin mining the next eligible target without releasing attack key
        if (config.isContinuousMining() && client != null && client.player != null && client.world != null) {
            BlockPos nextTarget = selectNextTarget(client.player, client.world);
            if (nextTarget != null) {
                double dist = client.player.getEyePos().distanceTo(Vec3d.ofCenter(nextTarget));
                double maxReach = getPlayerBlockReach(client.player);
                if (dist <= maxReach && hasLineOfSightToTarget(client.world, client.player.getEyePos(), nextTarget)) {
                    currentTarget = nextTarget;
                    currentTargetFace = findBestExposedFace(client.world, currentTarget, client.player.getEyePos());
                    if (currentTargetFace != null) {
                        Vec3d targetPoint = getFaceCenter(currentTarget, currentTargetFace);
                        rotationController.setTarget(targetPoint, currentTarget);

                        if (isAimedAt(client, client.player, currentTarget, targetPoint)) {
                            client.options.attackKey.setPressed(true);
                            if (client.interactionManager != null) {
                                client.interactionManager.attackBlock(currentTarget, currentTargetFace);
                                client.player.swingHand(Hand.MAIN_HAND);
                            }
                            BlockState targetState = client.world.getBlockState(currentTarget);
                            float delta = targetState.calcBlockBreakingDelta(client.player, client.world, currentTarget);
                            expectedMiningDurationTicks = delta >= 1.0f ? 1 : (int) Math.ceil(1.0f / delta);
                            currentTargetMiningTicks = 0;
                            waitingUpdateTicks = 0;
                            status = MiningStatus.MINING;
                            miningState = MiningState.MINING_IN_PROGRESS;
                            return;
                        } else {
                            alignmentTicks = 0;
                            miningState = MiningState.ALIGNING_WITH_TARGET;
                            return;
                        }
                    }
                }
            }
        }

        stopAttacking(client);
        if (client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }

        status = MiningStatus.TARGET_COMPLETE;
        miningState = MiningState.SELECTING_NEXT_TARGET;
    }

    private void tickRecoveringFromFailure(MinecraftClient client) {
        stopAttacking(client);
        stopWalking(client);
        rotationController.clearTarget();
        if (client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }

        if (currentTarget != null) {
            int retries = retryCounts.getOrDefault(currentTarget, 0) + 1;
            retryCounts.put(currentTarget, retries);
            long cooldownMs = config.getProtectionCooldownSeconds() * 1000L;

            if (retries >= config.getMaxRetriesPerTarget() || MiningDebugInfo.wasRejected) {
                consecutiveTargetFailures++;
                LOGGER.warn("Target at [{}, {}, {}] failed/rejected ({}/{}). Reason: {}. Applying cooldown ({}s).",
                        currentTarget.getX(), currentTarget.getY(), currentTarget.getZ(),
                        retries, config.getMaxRetriesPerTarget(), MiningDebugInfo.whySkippedReason, config.getProtectionCooldownSeconds());
                
                serverRestrictedCooldowns.put(currentTarget, System.currentTimeMillis() + cooldownMs);
                serverRestrictedTargets.add(currentTarget);
                targetQueue.remove(currentTarget);
                targetLookupSet.remove(currentTarget);
                refilledTargets.remove(currentTarget);
                failedTargetsCount++;
                MiningDebugInfo.failedTargetsCount = failedTargetsCount;

                if (consecutiveTargetFailures >= MAX_CONSECUTIVE_FAILURES) {
                    LOGGER.warn("Encountered {} consecutive target failures near [{}, {}, {}]. Temporarily excluding local area on cooldown.",
                            consecutiveTargetFailures, currentTarget.getX(), currentTarget.getY(), currentTarget.getZ());
                    int radius = 1;
                    for (int dx = -radius; dx <= radius; dx++) {
                        for (int dy = -radius; dy <= radius; dy++) {
                            for (int dz = -radius; dz <= radius; dz++) {
                                BlockPos near = currentTarget.add(dx, dy, dz);
                                serverRestrictedCooldowns.put(near, System.currentTimeMillis() + cooldownMs);
                                serverRestrictedTargets.add(near);
                                targetQueue.remove(near);
                                targetLookupSet.remove(near);
                            }
                        }
                    }
                }
            } else {
                targetQueue.remove(currentTarget);
                targetQueue.add(currentTarget);
                retryCooldowns.put(currentTarget, System.currentTimeMillis() + (config.getRetryCooldownTicks() * 50L));
                LOGGER.info("Target at [{}, {}, {}] deferred for retry ({}/{}). Reason: {}",
                        currentTarget.getX(), currentTarget.getY(), currentTarget.getZ(),
                        retries, config.getMaxRetriesPerTarget(), MiningDebugInfo.whySkippedReason);
            }

            currentTarget = null;
            currentTargetFace = null;
            currentTargetMiningTicks = 0;
            waitingUpdateTicks = 0;
            validatingTicks = 0;
            alignmentTicks = 0;
        }

        miningState = MiningState.SELECTING_NEXT_TARGET;
    }

    public void executeStep(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, ClientPlayerInteractionManager interactionManager) {
        if (miningState == MiningState.IDLE || miningState == MiningState.SELECTING_NEXT_TARGET) {
            miningState = MiningState.VALIDATING_TARGET;
        }
        tick(client);
    }

    private void handleNavigation(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, double maxReach) {
        BlockPos playerPos = player.getBlockPos();

        if (activePath == null || currentPathIndex >= activePath.getNodes().size()) {
            if (recalculateCooldown <= 0) {
                navState = NavigationState.PLANNING_ROUTE;
                statusDetail = Text.literal("Computing A* path to target...").formatted(Formatting.AQUA);

                activePath = pathfinder.findPath(world, playerPos, currentTarget, maxReach);
                currentPathIndex = 0;
                pathStuckTicks = 0;
                recalculateCooldown = config.getRecalculateCooldownTicks();

                if (!activePath.isSuccess() || activePath.getNodes().isEmpty()) {
                    if (config.isAutoAdvance()) {
                        updateMovementAndAdvance(client, player, world);
                        return;
                    } else if (config.isAutoWalk()) {
                        handleDirectWalk(client, player, getFaceCenter(currentTarget, currentTargetFace), maxReach);
                        return;
                    }
                    navState = NavigationState.NO_VALID_PATH;
                    statusDetail = Text.literal("No valid route to target.").formatted(Formatting.RED);
                    unreachableTargets.add(currentTarget);
                    putOnCooldown(currentTarget, config.getRetryCooldownTicks() * 3L);
                    cancelCurrentMining(client);
                    return;
                }
            } else {
                return;
            }
        }

        navState = NavigationState.FOLLOWING_ROUTE;
        status = MiningStatus.MINING;
        statusDetail = Text.literal(String.format("Navigating path (step %d/%d)...",
                currentPathIndex + 1, activePath.getNodes().size())).formatted(Formatting.BLUE);

        PathNode waypoint = activePath.getNodes().get(currentPathIndex);
        Vec3d waypointCenter = new Vec3d(waypoint.pos.getX() + 0.5, waypoint.pos.getY(), waypoint.pos.getZ() + 0.5);

        double dx = waypointCenter.x - player.getX();
        double dz = waypointCenter.z - player.getZ();
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        if (horizontalDist < 0.75 && Math.abs(player.getY() - waypoint.pos.getY()) <= 1.25) {
            currentPathIndex++;
            pathStuckTicks = 0;
            if (currentPathIndex >= activePath.getNodes().size()) {
                activePath = null;
                currentPathIndex = 0;
                stopWalking(client);
                return;
            }
            waypoint = activePath.getNodes().get(currentPathIndex);
            waypointCenter = new Vec3d(waypoint.pos.getX() + 0.5, waypoint.pos.getY(), waypoint.pos.getZ() + 0.5);
            dx = waypointCenter.x - player.getX();
            dz = waypointCenter.z - player.getZ();
            horizontalDist = Math.sqrt(dx * dx + dz * dz);
        }

        Vec3d lookPoint = new Vec3d(waypointCenter.x, waypoint.pos.getY() + 1.2, waypointCenter.z);
        if (currentTarget != null && isAimedAt(client, player, currentTarget, getFaceCenter(currentTarget, currentTargetFace))) {
            // Keep aiming at current target if crosshair is verified
        } else {
            rotationController.setTarget(lookPoint, currentTarget);
        }

        float moveYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        applyCoordinatedMovement(client, player, moveYaw, horizontalDist, waypoint.action);

        pathStuckTicks++;
        if (pathStuckTicks > config.getStuckDetectionThreshold()) {
            navState = NavigationState.RECALCULATING_ROUTE;
            activePath = null;
            currentPathIndex = 0;
            pathStuckTicks = 0;
            recalculateCooldown = 0;
        }
    }

    private void handleDirectWalk(MinecraftClient client, ClientPlayerEntity player, Vec3d targetPoint, double maxReach) {
        double dx = targetPoint.x - player.getX();
        double dz = targetPoint.z - player.getZ();
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        rotationController.setTarget(targetPoint, currentTarget);
        float moveYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;

        // Region boundary guard during automated direct walk
        if (config.isEnforceAreaBoundary() && activeRegion != null) {
            Vec3d forwardVec = Vec3d.fromPolar(0, player.getYaw()).multiply(0.7);
            BlockPos futurePos = BlockPos.ofFloored(player.getX() + forwardVec.x, player.getY(), player.getZ() + forwardVec.z);
            if (activeRegion.contains(player.getBlockPos()) && !activeRegion.contains(futurePos)) {
                stopWalking(client);
                return;
            }
        }

        applyCoordinatedMovement(client, player, moveYaw, horizontalDist, PathAction.WALK);

        navState = NavigationState.APPROACHING_TARGET;
        status = MiningStatus.MINING;
        statusDetail = Text.literal("Walking smoothly to target...").formatted(Formatting.AQUA);
    }

    private void handleAutoAdvance(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, BlockPos target) {
        updateMovementAndAdvance(client, player, world);
    }

    /**
     * Unified, coordinated movement and advance controller.
     * Advances the player forward while maintaining the configured 1-2 block gap (default 1.5 blocks).
     * Smoothly strafes when the target or waypoint is off-center, clears 1x2 forward walking obstacles,
     * avoids hazards, drops, and boundaries, verifies physical displacement over time, and triggers
     * safe pathfinding / recovery when stuck.
     */
    private void updateMovementAndAdvance(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (!config.isAutoAdvance() || client == null || player == null || world == null) {
            return;
        }

        // GUI / Screen Protection: Never move while any screen or GUI is open
        if (client.currentScreen != null) {
            stopWalking(client);
            return;
        }

        // Auto Storage Check: Never advance if storage engine is performing actions
        com.refillminerpro.client.RefillMinerClient clientInstance = com.refillminerpro.client.RefillMinerClient.getInstance();
        if (clientInstance != null && clientInstance.getAutoStorageEngine() != null) {
            if (clientInstance.getAutoStorageEngine().isBusy()) {
                stopWalking(client);
                return;
            }
        }

        if (currentTarget == null && (activePath == null || !activePath.isSuccess())) {
            stopWalking(client);
            return;
        }

        // 1. Follow active A* path if navigating around an obstacle
        if (config.isAutoNavigate() && activePath != null && activePath.isSuccess() && currentPathIndex < activePath.getNodes().size()) {
            handleNavigation(client, player, world, getPlayerBlockReach(player));
            return;
        }

        // Target face and position
        Vec3d targetPoint = (currentTargetFace != null && currentTarget != null)
                ? getFaceCenter(currentTarget, currentTargetFace)
                : (currentTarget != null ? Vec3d.ofCenter(currentTarget) : player.getEyePos());

        double dx = targetPoint.x - player.getX();
        double dz = targetPoint.z - player.getZ();
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        double eyeDist = player.getEyePos().distanceTo(targetPoint);
        double desiredGap = config.getDesiredMiningGap(); // default 1.5 blocks (range 1.0 to 2.0)

        // 2. Maintain the configured 1-2 block gap from the active mining target or mining face:
        if (horizontalDist <= desiredGap) {
            // Already within the ideal mining gap! Halt forward advance but continue mining!
            client.options.forwardKey.setPressed(false);
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
            client.options.sprintKey.setPressed(false);
            advanceStuckTicks = 0;
            lastAdvancePos = null;

            // Prevent standing inside or clipping into the block
            if (horizontalDist < 0.65 && eyeDist < 1.0) {
                if (client.options.backKey != null) client.options.backKey.setPressed(true);
            } else {
                if (client.options.backKey != null) client.options.backKey.setPressed(false);
            }
            return;
        }

        if (client.options.backKey != null) {
            client.options.backKey.setPressed(false);
        }

        // 3. Obstacle clearance: Check if player's foot or head path is physically blocked by an obstacle
        Direction facing = player.getHorizontalFacing();
        BlockPos playerFoot = player.getBlockPos();
        BlockPos nextFoot = playerFoot.offset(facing);
        BlockPos nextHead = nextFoot.up();

        BlockState footState = world.getBlockState(nextFoot);
        if (!footState.isAir() && (!footState.getCollisionShape(world, nextFoot).isEmpty() || footState.blocksMovement())) {
            if (!nextFoot.equals(currentTarget)) {
                if (!isServerRestricted(nextFoot) && filter.isEligible(world, nextFoot, footState)) {
                    currentTarget = nextFoot;
                    currentTargetFace = facing.getOpposite();
                    stopWalking(client);
                    miningState = MiningState.ALIGNING_WITH_TARGET;
                    return;
                } else {
                    // Blocked by unbreakable/protected block: attempt A* pathfinding around it
                    if (config.isAutoNavigate()) {
                        triggerPathfinding(client, player, world);
                        return;
                    } else {
                        stopWalking(client);
                        return;
                    }
                }
            }
        }

        BlockState headState = world.getBlockState(nextHead);
        if (!headState.isAir() && (!headState.getCollisionShape(world, nextHead).isEmpty() || headState.blocksMovement())) {
            if (!nextHead.equals(currentTarget)) {
                if (!isServerRestricted(nextHead) && filter.isEligible(world, nextHead, headState)) {
                    currentTarget = nextHead;
                    currentTargetFace = facing.getOpposite();
                    stopWalking(client);
                    miningState = MiningState.ALIGNING_WITH_TARGET;
                    return;
                } else {
                    if (config.isAutoNavigate()) {
                        triggerPathfinding(client, player, world);
                        return;
                    } else {
                        stopWalking(client);
                        return;
                    }
                }
            }
        }

        // 4. Ground & Hazard Safety check: Never step forward into cliffs, lava, or boundary limits
        if (!canSafelyStepForward(player, world, facing)) {
            stopWalking(client);
            if (config.isAutoNavigate()) {
                triggerPathfinding(client, player, world);
            }
            return;
        }

        // 5. Apply coordinated movement towards the target
        float targetMoveYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        applyCoordinatedMovement(client, player, targetMoveYaw, horizontalDist, PathAction.WALK);

        // 6. Stuck Detection: Verify the player is actually changing position over time
        if (config.isStuckRecoveryEnabled() && (client.options.forwardKey.isPressed() || client.options.leftKey.isPressed() || client.options.rightKey.isPressed())) {
            Vec3d curPos = new Vec3d(player.getX(), player.getY(), player.getZ());
            if (lastAdvancePos == null || curPos.squaredDistanceTo(lastAdvancePos) > 0.015) {
                lastAdvancePos = curPos;
                advanceStuckTicks = 0;
            } else {
                advanceStuckTicks++;
                if (advanceStuckTicks >= config.getStuckDetectionThreshold()) {
                    triggerStuckRecovery(client, player, world);
                }
            }
        } else {
            advanceStuckTicks = 0;
        }
    }

    private void applyCoordinatedMovement(MinecraftClient client, ClientPlayerEntity player, float targetMoveYaw, double distance, PathAction action) {
        if (client == null || client.options == null || player == null) return;

        float yawDiff = MathHelper.wrapDegrees(targetMoveYaw - player.getYaw());
        float absDiff = Math.abs(yawDiff);

        // Handle safe elevation step up
        if (action == PathAction.JUMP_UP) {
            client.options.jumpKey.setPressed(true);
        } else {
            client.options.jumpKey.setPressed(false);
        }

        // Smooth speed adjustment
        MovementSmoothness smoothness = config.getMovementSmoothness();
        if (smoothness == MovementSmoothness.FAST && distance > 2.5 && absDiff < 30.0f) {
            client.options.sprintKey.setPressed(true);
            client.options.sneakKey.setPressed(false);
        } else if (smoothness == MovementSmoothness.SLOW) {
            client.options.sprintKey.setPressed(false);
            client.options.sneakKey.setPressed(true);
        } else {
            client.options.sprintKey.setPressed(false);
            client.options.sneakKey.setPressed(false);
        }

        // Smoothly adjust travel direction when target is off-center (continuous forward + strafe)
        if (absDiff <= 25.0f) {
            client.options.forwardKey.setPressed(true);
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
        } else if (yawDiff > 25.0f && yawDiff <= 70.0f) {
            client.options.forwardKey.setPressed(true);
            client.options.rightKey.setPressed(true);
            client.options.leftKey.setPressed(false);
        } else if (yawDiff < -25.0f && yawDiff >= -70.0f) {
            client.options.forwardKey.setPressed(true);
            client.options.leftKey.setPressed(true);
            client.options.rightKey.setPressed(false);
        } else if (yawDiff > 70.0f && yawDiff <= 115.0f) {
            client.options.forwardKey.setPressed(false);
            client.options.rightKey.setPressed(true);
            client.options.leftKey.setPressed(false);
        } else if (yawDiff < -70.0f && yawDiff >= -115.0f) {
            client.options.forwardKey.setPressed(false);
            client.options.leftKey.setPressed(true);
            client.options.rightKey.setPressed(false);
        } else {
            // Target is behind current heading: wait for camera alignment before advancing
            client.options.forwardKey.setPressed(false);
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
        }
    }

    private void triggerPathfinding(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (currentTarget == null) return;
        double reach = getPlayerBlockReach(player);
        activePath = pathfinder.findPath(world, player.getBlockPos(), currentTarget, reach);
        if (activePath.isSuccess() && !activePath.getNodes().isEmpty()) {
            currentPathIndex = 0;
            navState = NavigationState.FOLLOWING_ROUTE;
        } else {
            navState = NavigationState.NO_VALID_PATH;
        }
    }

    private void triggerStuckRecovery(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        LOGGER.debug("Forward advance stuck detected at [{}, {}, {}]. Triggering recovery mode: {}",
                player.getX(), player.getY(), player.getZ(), config.getRecoveryMode());

        stopWalking(client);
        advanceStuckTicks = 0;
        lastAdvancePos = null;

        // 1. Check if obstacle block is directly in front of the player's walking corridor
        Direction facing = player.getHorizontalFacing();
        BlockPos nextFoot = player.getBlockPos().offset(facing);
        BlockPos nextHead = nextFoot.up();

        BlockState footState = world.getBlockState(nextFoot);
        if (!footState.isAir() && footState.blocksMovement() && filter.isEligible(world, nextFoot, footState) && !isServerRestricted(nextFoot)) {
            currentTarget = nextFoot;
            currentTargetFace = facing.getOpposite();
            miningState = MiningState.ALIGNING_WITH_TARGET;
            return;
        }

        BlockState headState = world.getBlockState(nextHead);
        if (!headState.isAir() && headState.blocksMovement() && filter.isEligible(world, nextHead, headState) && !isServerRestricted(nextHead)) {
            currentTarget = nextHead;
            currentTargetFace = facing.getOpposite();
            miningState = MiningState.ALIGNING_WITH_TARGET;
            return;
        }

        // 2. Try A* route replanning around obstacle
        if (config.isAutoNavigate() && currentTarget != null) {
            double reach = getPlayerBlockReach(player);
            activePath = pathfinder.findPath(world, player.getBlockPos(), currentTarget, reach);
            if (activePath.isSuccess() && !activePath.getNodes().isEmpty()) {
                currentPathIndex = 0;
                navState = NavigationState.FOLLOWING_ROUTE;
                return;
            }
        }

        // 3. Apply configurable RecoveryMode
        RecoveryMode mode = config.getRecoveryMode();
        switch (mode) {
            case RESCAN -> {
                if (currentTarget != null) {
                    retryCooldowns.put(currentTarget, System.currentTimeMillis() + 3000L);
                    currentTarget = null;
                }
                navState = NavigationState.IDLE;
                status = MiningStatus.RESCANNING;
                miningState = MiningState.SELECTING_NEXT_TARGET;
                rescanArea(world);
            }
            case REPLAN -> {
                if (currentTarget != null) {
                    retryCooldowns.put(currentTarget, System.currentTimeMillis() + 3000L);
                    currentTarget = null;
                }
                activePath = null;
                currentPathIndex = 0;
                recalculateCooldown = 0;
                navState = NavigationState.RECALCULATING_ROUTE;
                miningState = MiningState.SELECTING_NEXT_TARGET;
            }
            case PAUSE_SAFELY -> {
                stopAttacking(client);
                cancelCurrentMining(client);
                config.setPaused(true);
                status = MiningStatus.PAUSED;
                miningState = MiningState.PAUSED;
                navState = NavigationState.PAUSED;
                statusDetail = Text.literal("Auto Mine paused safely: Route blocked").formatted(Formatting.YELLOW);
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("Auto Mine: Paused safely — Route blocked and no path found.").formatted(Formatting.YELLOW), false);
                }
            }
        }
    }

    private boolean canSafelyStepForward(ClientPlayerEntity player, ClientWorld world, Direction facing) {
        if (player == null || world == null || facing == null) return false;

        BlockPos playerFoot = player.getBlockPos();
        BlockPos nextFoot = playerFoot.offset(facing);
        BlockPos nextHead = nextFoot.up();

        // 1. Boundary guard: only enforce if player is already inside the active region
        if (config.isEnforceAreaBoundary() && activeRegion != null) {
            if (activeRegion.contains(playerFoot) && !activeRegion.contains(nextFoot)) {
                return false;
            }
        }

        // 2. Obstacle check: nextFoot and nextHead must be passable or eligible to mine
        BlockState footState = world.getBlockState(nextFoot);
        BlockState headState = world.getBlockState(nextHead);
        if (!footState.isAir() && (!footState.getCollisionShape(world, nextFoot).isEmpty() || footState.blocksMovement())) {
            if (isServerRestricted(nextFoot) || !filter.isEligible(world, nextFoot, footState)) {
                return false;
            }
        }
        if (!headState.isAir() && (!headState.getCollisionShape(world, nextHead).isEmpty() || headState.blocksMovement())) {
            if (isServerRestricted(nextHead) || !filter.isEligible(world, nextHead, headState)) {
                return false;
            }
        }

        // 3. Ground and Hazard check
        BlockPos groundPos = nextFoot.down();
        BlockState groundState = world.getBlockState(groundPos);

        if (isHazardous(groundState) || isHazardous(footState) || isHazardous(headState)) {
            return false;
        }

        // If groundPos is air, check if there's solid ground within 1-2 block drop (no cliffs)
        if (groundState.isAir()) {
            BlockPos drop1 = groundPos.down();
            BlockState drop1State = world.getBlockState(drop1);
            if (drop1State.isAir() || isHazardous(drop1State)) {
                BlockPos drop2 = drop1.down();
                BlockState drop2State = world.getBlockState(drop2);
                if (drop2State.isAir() || isHazardous(drop2State)) {
                    return false;
                }
            }
        }

        return true;
    }

    private boolean isHazardous(BlockState state) {
        if (state == null) return false;
        return !state.getFluidState().isEmpty()
                || state.isOf(net.minecraft.block.Blocks.LAVA)
                || state.isOf(net.minecraft.block.Blocks.FIRE)
                || state.isOf(net.minecraft.block.Blocks.SOUL_FIRE)
                || state.isOf(net.minecraft.block.Blocks.MAGMA_BLOCK)
                || state.isOf(net.minecraft.block.Blocks.CACTUS)
                || state.isOf(net.minecraft.block.Blocks.SWEET_BERRY_BUSH)
                || state.isOf(net.minecraft.block.Blocks.WITHER_ROSE);
    }

    private BlockPos selectNextTarget(ClientPlayerEntity player, ClientWorld world) {
        if (targetQueue.isEmpty()) {
            List<BlockPos> forwardCands = areaScanner.scanForwardCandidates(player, world, activeRegion, config);
            if (!forwardCands.isEmpty()) {
                for (BlockPos cand : forwardCands) {
                    enqueueTarget(cand, false);
                }
            }
        }

        if (targetQueue.isEmpty()) {
            // Last resort: scan entire region for remaining blocks
            if (activeRegion != null && world != null) {
                BlockPos distant = findNearestEligibleInRegion(player, world);
                if (distant != null) {
                    enqueueTarget(distant, true);
                    LOGGER.debug("Queue was empty; found distant eligible block at [{}, {}, {}]",
                        distant.getX(), distant.getY(), distant.getZ());
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }

        double maxReach = getPlayerBlockReach(player);
        Vec3d eyePos = player.getEyePos();
        Vec3d lookVec = player.getRotationVec(1.0f);

        // Dynamic forward scan prioritization: inspect forward candidates first
        List<BlockPos> forwardCandidates = areaScanner.scanForwardCandidates(player, world, activeRegion, config);
        if (!forwardCandidates.isEmpty()) {
            sortCandidates(forwardCandidates, config.getTargetPriority(), eyePos, player.getBlockPos());
            for (BlockPos cand : forwardCandidates) {
                if (isServerRestricted(cand)) {
                    LOGGER.debug("Skipping forward candidate at [{}, {}, {}] (active server restriction cooldown)",
                            cand.getX(), cand.getY(), cand.getZ());
                    continue;
                }
                if (!unreachableTargets.contains(cand)) {
                    Long cd = retryCooldowns.get(cand);
                    if (cd == null || System.currentTimeMillis() >= cd) {
                        double dist = eyePos.distanceTo(Vec3d.ofCenter(cand));
                        double candComfortableReach = Math.min(maxReach - 0.4, config.getTargetReachPreference());
                        if (dist <= candComfortableReach && hasLineOfSightToTarget(world, eyePos, cand)) {
                            currentTargetFace = findBestExposedFace(world, cand, eyePos);
                            if (currentTargetFace != null) {
                                if (!targetLookupSet.contains(cand)) {
                                    targetLookupSet.add(cand);
                                    targetQueue.add(cand);
                                }
                                MiningDebugInfo.whySelectedReason = "Forward candidate (LOS + reachable)";
                                LOGGER.debug("Target selected at [{}, {}, {}] (reason: Forward candidate, dist: {}b)",
                                        cand.getX(), cand.getY(), cand.getZ(), String.format("%.2f", dist));
                                return cand;
                            }
                        }
                    }
                }
            }
        }

        // 6x3 Area Mining Mode integration: only enforce area footprint if anchor has remaining blocks
        if (config.isAreaMiningEnabled() && activeRegion != null) {
            BlockPos areaTarget = selectAreaMiningTarget(player, world, maxReach, eyePos);
            if (areaTarget != null) {
                return areaTarget;
            }
        }

        boolean canMove = config.isAutoNavigate() || config.isAutoWalk() || config.isAutoAdvance();

        // Search through the deterministic queue
        Iterator<BlockPos> it = targetQueue.iterator();
        BlockPos bestReachableVisible = null;
        double bestReachableVisibleDist = Double.MAX_VALUE;
        BlockPos bestReachableExposed = null;
        double bestReachableExposedDist = Double.MAX_VALUE;
        BlockPos bestReachable = null;
        double bestReachableDist = Double.MAX_VALUE;
        BlockPos bestOtherForward = null;
        double bestOtherForwardDist = Double.MAX_VALUE;
        BlockPos bestOther = null;
        double bestOtherDist = Double.MAX_VALUE;

        while (it.hasNext()) {
            BlockPos pos = it.next();

            // Validate chunk
            if (!world.isChunkLoaded(pos)) {
                continue;
            }

            // Validate state
            BlockState state = world.getBlockState(pos);
            if (state.isAir()) {
                it.remove();
                targetLookupSet.remove(pos);
                refilledTargets.remove(pos);
                continue;
            }

            if (!filter.isEligible(world, pos, state)) {
                it.remove();
                targetLookupSet.remove(pos);
                refilledTargets.remove(pos);
                continue;
            }

            // Cooldown check
            Long cd = retryCooldowns.get(pos);
            if (cd != null && System.currentTimeMillis() < cd) {
                continue;
            }

            if (unreachableTargets.contains(pos) || isServerRestricted(pos)) {
                if (isServerRestricted(pos)) {
                    LOGGER.debug("Skipping queue target at [{}, {}, {}] (active server restriction cooldown)",
                            pos.getX(), pos.getY(), pos.getZ());
                }
                continue;
            }

            double dist = eyePos.distanceTo(Vec3d.ofCenter(pos));
            double comfReach = Math.min(maxReach - 0.4, config.getTargetReachPreference());
            boolean withinReach = dist <= comfReach;
            boolean exposed = isBlockExposed(world, pos);
            boolean visible = exposed && hasLineOfSightToTarget(world, eyePos, pos);

            // Avoid choosing blocks that require large backwards turns (> 100 degrees) when forward blocks exist
            Vec3d toCand = Vec3d.ofCenter(pos).subtract(eyePos).normalize();
            boolean isForward = toCand.dotProduct(lookVec) > -0.2;

            if (withinReach && visible) {
                if (isForward && dist < bestReachableVisibleDist) {
                    bestReachableVisible = pos;
                    bestReachableVisibleDist = dist;
                } else if (bestReachableVisible == null && dist < bestReachableVisibleDist) {
                    bestReachableVisible = pos;
                    bestReachableVisibleDist = dist;
                }
            } else if (withinReach && exposed && canMove) {
                if (dist < bestReachableExposedDist) {
                    bestReachableExposed = pos;
                    bestReachableExposedDist = dist;
                }
            } else if (withinReach && exposed && canMove) {
                if (dist < bestReachableDist) {
                    bestReachable = pos;
                    bestReachableDist = dist;
                }
            } else if (canMove && exposed) {
                if (isForward && dist < bestOtherForwardDist) {
                    bestOtherForward = pos;
                    bestOtherForwardDist = dist;
                } else if (dist < bestOtherDist) {
                    bestOther = pos;
                    bestOtherDist = dist;
                }
            }
        }

        BlockPos chosen = null;
        if (bestReachableVisible != null) {
            chosen = bestReachableVisible;
        } else if (bestReachableExposed != null) {
            chosen = bestReachableExposed;
        } else if (bestReachable != null) {
            chosen = bestReachable;
        } else if (canMove && !forwardCandidates.isEmpty()) {
            for (BlockPos cand : forwardCandidates) {
                if (!unreachableTargets.contains(cand) && !isServerRestricted(cand)) {
                    Long cd = retryCooldowns.get(cand);
                    if (cd == null || System.currentTimeMillis() >= cd) {
                        chosen = cand;
                        if (!targetLookupSet.contains(cand)) {
                            targetLookupSet.add(cand);
                            targetQueue.add(cand);
                        }
                        break;
                    }
                }
            }
        }

        if (chosen == null) {
            if (bestOtherForward != null) {
                chosen = bestOtherForward;
            } else if (bestOther != null) {
                chosen = bestOther;
            }
        }

        if (chosen != null) {
            currentTargetFace = findBestExposedFace(world, chosen, eyePos);
            String reason;
            if (chosen == bestReachableVisible) {
                reason = "Nearest reachable visible";
            } else if (chosen == bestReachableExposed) {
                reason = "Reachable exposed";
            } else if (chosen == bestReachable) {
                reason = "Reachable in queue";
            } else if (chosen == bestOtherForward) {
                reason = "Candidate forward";
            } else {
                reason = "Queue target";
            }
            MiningDebugInfo.whySelectedReason = reason;
            LOGGER.debug("Target selected at [{}, {}, {}] (reason: {}, dist: {}b)",
                    chosen.getX(), chosen.getY(), chosen.getZ(), reason, String.format("%.2f", eyePos.distanceTo(Vec3d.ofCenter(chosen))));
            // CRUCIAL: Do NOT remove chosen from targetQueue here.
            // Target remains tracked until confirmed air in CONFIRMING_COMPLETION.
            return chosen;
        }

        return null;
    }

    private BlockPos selectAreaMiningTarget(ClientPlayerEntity player, ClientWorld world, double maxReach, Vec3d eyePos) {
        // 1. Maintain active footprint until all blocks within it are cleared
        if (activeFootprintAnchor != null && !activeFootprint.isEmpty()) {
            for (BlockPos pos : activeFootprint) {
                if (targetLookupSet.contains(pos) && world.isChunkLoaded(pos)) {
                    BlockState state = world.getBlockState(pos);
                    if (!state.isAir() && filter.isEligible(world, pos, state)) {
                        double dist = eyePos.distanceTo(Vec3d.ofCenter(pos));
                        if (dist <= maxReach && hasLineOfSightToTarget(world, eyePos, pos)) {
                            currentTargetFace = findBestExposedFace(world, pos, eyePos);
                            return pos;
                        }
                    }
                }
            }
            for (BlockPos pos : activeFootprint) {
                if (targetLookupSet.contains(pos) && world.isChunkLoaded(pos)) {
                    BlockState state = world.getBlockState(pos);
                    if (!state.isAir() && filter.isEligible(world, pos, state)) {
                        double dist = eyePos.distanceTo(Vec3d.ofCenter(pos));
                        if (dist <= maxReach) {
                            currentTargetFace = findBestExposedFace(world, pos, eyePos);
                            return pos;
                        }
                    }
                }
            }
        }

        // Active footprint completed or exhausted! Select next anchor from targetQueue
        activeFootprint.clear();
        activeFootprintAnchor = null;

        for (BlockPos pos : targetQueue) {
            if (world.isChunkLoaded(pos)) {
                BlockState state = world.getBlockState(pos);
                if (!state.isAir() && filter.isEligible(world, pos, state) && isBlockExposed(world, pos)) {
                    activeFootprintAnchor = pos;
                    break;
                }
            }
        }
        if (activeFootprintAnchor == null) {
            for (BlockPos pos : targetQueue) {
                if (world.isChunkLoaded(pos)) {
                    BlockState state = world.getBlockState(pos);
                    if (!state.isAir() && filter.isEligible(world, pos, state)) {
                        activeFootprintAnchor = pos;
                        break;
                    }
                }
            }
        }
        if (activeFootprintAnchor == null) return null;

        Direction miningFace = findBestExposedFace(world, activeFootprintAnchor, eyePos);
        activeFootprint.addAll(AreaMiningCalculator.calculateFootprint(activeFootprintAnchor, miningFace, activeRegion, config));

        for (BlockPos pos : activeFootprint) {
            if (targetLookupSet.contains(pos) && world.isChunkLoaded(pos)) {
                BlockState state = world.getBlockState(pos);
                if (!state.isAir() && filter.isEligible(world, pos, state)) {
                    currentTargetFace = findBestExposedFace(world, pos, eyePos);
                    return pos;
                }
            }
        }
        return null;
    }

    public void sortCandidates(List<BlockPos> candidates, TargetPriority priority, Vec3d eyePos, BlockPos playerFoot) {
        if (candidates == null || candidates.size() <= 1) return;
        TargetPriority strat = priority != null ? priority : TargetPriority.BOTTOM_TO_TOP;

        switch (strat) {
            case SMART -> {
                // Smart order: clears lower rows first, minimizing direction reversals
                candidates.sort((p1, p2) -> {
                    int cmpY = Integer.compare(p1.getY(), p2.getY());
                    if (cmpY != 0) return cmpY;
                    int row = Math.abs(p1.getY());
                    if (row % 2 == 0) {
                        int cx = Integer.compare(p1.getX(), p2.getX());
                        if (cx != 0) return cx;
                        return Integer.compare(p1.getZ(), p2.getZ());
                    } else {
                        int cx = Integer.compare(p2.getX(), p1.getX());
                        if (cx != 0) return cx;
                        return Integer.compare(p2.getZ(), p1.getZ());
                    }
                });
            }
            case CROSSHAIR_PRIORITY -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                Vec3d lookVec = (mc.player != null) ? mc.player.getRotationVec(1.0f) : new Vec3d(0, 0, 1);
                candidates.sort((p1, p2) -> {
                    Vec3d v1 = Vec3d.ofCenter(p1).subtract(eyePos).normalize();
                    Vec3d v2 = Vec3d.ofCenter(p2).subtract(eyePos).normalize();
                    double dot1 = v1.dotProduct(lookVec);
                    double dot2 = v2.dotProduct(lookVec);
                    int cmpDot = Double.compare(dot2, dot1); // Higher dot product = closer to crosshair
                    if (cmpDot != 0) return cmpDot;
                    return Double.compare(eyePos.squaredDistanceTo(Vec3d.ofCenter(p1)), eyePos.squaredDistanceTo(Vec3d.ofCenter(p2)));
                });
            }
            case ROW_SWEEP -> candidates.sort((p1, p2) -> {
                int cmpY = Integer.compare(p1.getY(), p2.getY()); // Bottom-up row sweep
                if (cmpY != 0) return cmpY;
                int row = Math.abs(p1.getY());
                if (row % 2 == 0) {
                    int cx = Integer.compare(p1.getX(), p2.getX());
                    if (cx != 0) return cx;
                    return Integer.compare(p1.getZ(), p2.getZ());
                } else {
                    int cx = Integer.compare(p2.getX(), p1.getX());
                    if (cx != 0) return cx;
                    return Integer.compare(p2.getZ(), p1.getZ());
                }
            });
            case ROW_BY_ROW -> candidates.sort((p1, p2) -> {
                int cmpY = Integer.compare(p2.getY(), p1.getY()); // Top-down layer sweep
                if (cmpY != 0) return cmpY;
                int row = Math.abs(p1.getY());
                if (row % 2 == 0) {
                    int cx = Integer.compare(p1.getX(), p2.getX());
                    if (cx != 0) return cx;
                    return Integer.compare(p1.getZ(), p2.getZ());
                } else {
                    int cx = Integer.compare(p2.getX(), p1.getX());
                    if (cx != 0) return cx;
                    return Integer.compare(p2.getZ(), p1.getZ());
                }
            });
            case HOVER_SWEEP -> {
                candidates.sort((p1, p2) -> {
                    double d1 = eyePos.squaredDistanceTo(Vec3d.ofCenter(p1));
                    double d2 = eyePos.squaredDistanceTo(Vec3d.ofCenter(p2));

                    int bucket1 = (int) (Math.sqrt(d1) / 1.5);
                    int bucket2 = (int) (Math.sqrt(d2) / 1.5);
                    if (bucket1 != bucket2) {
                        return Integer.compare(bucket1, bucket2);
                    }

                    int cmpY = Integer.compare(p1.getY(), p2.getY()); // Bottom-up bias
                    if (cmpY != 0) return cmpY;

                    int hash1 = (p1.getX() * 31 + p1.getZ() * 17) & 0x7;
                    int hash2 = (p2.getX() * 31 + p2.getZ() * 17) & 0x7;
                    int cmpHash = Integer.compare(hash1, hash2);
                    if (cmpHash != 0) return cmpHash;

                    int cmpX = Integer.compare(p1.getX(), p2.getX());
                    if (cmpX != 0) return cmpX;
                    return Integer.compare(p1.getZ(), p2.getZ());
                });
            }
            case NEAREST_FIRST -> candidates.sort((p1, p2) -> {
                int cmp = Double.compare(eyePos.squaredDistanceTo(Vec3d.ofCenter(p1)), eyePos.squaredDistanceTo(Vec3d.ofCenter(p2)));
                if (cmp != 0) return cmp;
                return compareTieBreaker(p1, p2);
            });
            case FURTHEST_FIRST -> candidates.sort((p1, p2) -> {
                int cmp = Double.compare(eyePos.squaredDistanceTo(Vec3d.ofCenter(p2)), eyePos.squaredDistanceTo(Vec3d.ofCenter(p1)));
                if (cmp != 0) return cmp;
                return compareTieBreaker(p1, p2);
            });
            case TOP_TO_BOTTOM -> candidates.sort((p1, p2) -> {
                int cmp = Integer.compare(p2.getY(), p1.getY());
                if (cmp != 0) return cmp;
                int cmpD = Double.compare(eyePos.squaredDistanceTo(Vec3d.ofCenter(p1)), eyePos.squaredDistanceTo(Vec3d.ofCenter(p2)));
                if (cmpD != 0) return cmpD;
                return compareTieBreaker(p1, p2);
            });
            case BOTTOM_TO_TOP -> candidates.sort((p1, p2) -> {
                int cmp = Integer.compare(p1.getY(), p2.getY());
                if (cmp != 0) return cmp;
                int cmpD = Double.compare(eyePos.squaredDistanceTo(Vec3d.ofCenter(p1)), eyePos.squaredDistanceTo(Vec3d.ofCenter(p2)));
                if (cmpD != 0) return cmpD;
                return compareTieBreaker(p1, p2);
            });
            case LEFT_TO_RIGHT -> candidates.sort((p1, p2) -> {
                int cmpY = Integer.compare(p1.getY(), p2.getY());
                if (cmpY != 0) return cmpY;
                int cmpX = Integer.compare(p1.getX(), p2.getX());
                if (cmpX != 0) return cmpX;
                return Integer.compare(p1.getZ(), p2.getZ());
            });
            case RIGHT_TO_LEFT -> candidates.sort((p1, p2) -> {
                int cmpY = Integer.compare(p1.getY(), p2.getY());
                if (cmpY != 0) return cmpY;
                int cmpX = Integer.compare(p2.getX(), p1.getX());
                if (cmpX != 0) return cmpX;
                return Integer.compare(p2.getZ(), p1.getZ());
            });
            case REFILL_PRIORITY -> candidates.sort((p1, p2) -> {
                boolean r1 = refilledTargets.contains(p1);
                boolean r2 = refilledTargets.contains(p2);
                if (r1 && !r2) return -1;
                if (!r1 && r2) return 1;
                int cmp = Double.compare(eyePos.squaredDistanceTo(Vec3d.ofCenter(p1)), eyePos.squaredDistanceTo(Vec3d.ofCenter(p2)));
                if (cmp != 0) return cmp;
                return compareTieBreaker(p1, p2);
            });
            case LOWEST_TRAVEL_COST -> candidates.sort((p1, p2) -> {
                double dx1 = p1.getX() - playerFoot.getX();
                double dy1 = p1.getY() - playerFoot.getY();
                double dz1 = p1.getZ() - playerFoot.getZ();
                double c1 = Math.sqrt(dx1 * dx1 + dz1 * dz1 + dy1 * dy1 * 1.5);

                double dx2 = p2.getX() - playerFoot.getX();
                double dy2 = p2.getY() - playerFoot.getY();
                double dz2 = p2.getZ() - playerFoot.getZ();
                double c2 = Math.sqrt(dx2 * dx2 + dz2 * dz2 + dy2 * dy2 * 1.5);

                int cmp = Double.compare(c1, c2);
                if (cmp != 0) return cmp;
                return compareTieBreaker(p1, p2);
            });
            case SELECTION_ORDER -> { /* Insertion order preserved */ }
        }
    }

    private static int compareTieBreaker(BlockPos p1, BlockPos p2) {
        int cx = Integer.compare(p1.getX(), p2.getX());
        if (cx != 0) return cx;
        int cy = Integer.compare(p1.getY(), p2.getY());
        if (cy != 0) return cy;
        return Integer.compare(p1.getZ(), p2.getZ());
    }

    private void selectBestToolInHotbar(ClientPlayerEntity player, BlockState state, ClientWorld world, BlockPos pos) {
        int originalSlot = player.getInventory().getSelectedSlot();
        int bestSlot = originalSlot;
        float bestDelta = -1.0f;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (config.isProtectLowDurability() && stack != null && stack.isDamageable()) {
                int remaining = stack.getMaxDamage() - stack.getDamage();
                if (remaining <= config.getMinDurabilityThreshold()) {
                    continue;
                }
            }

            player.getInventory().setSelectedSlot(i);
            float delta = state.calcBlockBreakingDelta(player, world, pos);

            if (delta > bestDelta) {
                bestDelta = delta;
                bestSlot = i;
            }
        }

        player.getInventory().setSelectedSlot(bestSlot);
    }

    private Direction findBestExposedFace(ClientWorld world, BlockPos pos, Vec3d eyePos) {
        Direction bestFace = null;
        double bestScore = -Double.MAX_VALUE;

        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            BlockState neighborState = world.getBlockState(neighbor);
            if (neighborState.isAir() || !neighborState.isOpaque()) {
                Vec3d faceCenter = getFaceCenter(pos, dir);
                Vec3d toEye = eyePos.subtract(faceCenter);
                double dist = toEye.length();
                if (dist < 0.001) dist = 0.001;

                Vec3d normal = Vec3d.of(dir.getVector());
                double dot = toEye.normalize().dotProduct(normal);

                // Prioritize faces that are facing directly toward the player's eyes
                if (dot > 0.05) {
                    double score = (dot * 2.5) - (dist * 0.35);

                    // High bonus for confirmed unobstructed raycast visibility
                    HitResult hit = world.raycast(new RaycastContext(
                            eyePos, faceCenter,
                            RaycastContext.ShapeType.OUTLINE,
                            RaycastContext.FluidHandling.NONE,
                            MinecraftClient.getInstance().player
                    ));
                    if (hit.getType() == HitResult.Type.BLOCK && ((BlockHitResult) hit).getBlockPos().equals(pos)) {
                        score += 5.0;
                    }

                    if (score > bestScore) {
                        bestScore = score;
                        bestFace = dir;
                    }
                }
            }
        }

        if (bestFace == null) {
            Vec3d center = Vec3d.ofCenter(pos);
            bestFace = Direction.getFacing(
                    (float) (eyePos.x - center.x),
                    (float) (eyePos.y - center.y),
                    (float) (eyePos.z - center.z)
            );
        }
        return bestFace;
    }

    private Direction findVisibleExposedFace(ClientWorld world, BlockPos pos, Vec3d eyePos) {
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            BlockState neighborState = world.getBlockState(neighbor);
            if (neighborState.isAir() || !neighborState.isOpaque()) {
                Vec3d facePoint = getFaceCenter(pos, dir);
                HitResult hit = world.raycast(new RaycastContext(
                        eyePos, facePoint,
                        RaycastContext.ShapeType.OUTLINE,
                        RaycastContext.FluidHandling.NONE,
                        MinecraftClient.getInstance().player
                ));
                if (hit.getType() == HitResult.Type.BLOCK && ((BlockHitResult) hit).getBlockPos().equals(pos)) {
                    return dir;
                }
            }
        }
        return null;
    }

    private Vec3d getFaceCenter(BlockPos pos, Direction dir) {
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.5;
        double z = pos.getZ() + 0.5;
        if (dir == null) return new Vec3d(x, y, z);
        return switch (dir) {
            case DOWN -> new Vec3d(x, pos.getY() + 0.02, z);
            case UP -> new Vec3d(x, pos.getY() + 0.98, z);
            case NORTH -> new Vec3d(x, y, pos.getZ() + 0.02);
            case SOUTH -> new Vec3d(x, y, pos.getZ() + 0.98);
            case WEST -> new Vec3d(pos.getX() + 0.02, y, z);
            case EAST -> new Vec3d(pos.getX() + 0.98, y, z);
        };
    }

    public boolean hasLineOfSightToTarget(ClientWorld world, Vec3d eyePos, BlockPos targetPos) {
        if (world == null || eyePos == null || targetPos == null) return false;

        Vec3d targetCenter = Vec3d.ofCenter(targetPos);
        HitResult hit = world.raycast(new RaycastContext(
                eyePos, targetCenter,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                MinecraftClient.getInstance().player
        ));

        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) hit;
            if (blockHit.getBlockPos().equals(targetPos)) {
                return true;
            }
        }

        for (Direction dir : Direction.values()) {
            Vec3d facePoint = getFaceCenter(targetPos, dir);
            HitResult faceHit = world.raycast(new RaycastContext(
                    eyePos, facePoint,
                    RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE,
                    MinecraftClient.getInstance().player
            ));
            if (faceHit.getType() == HitResult.Type.BLOCK) {
                BlockHitResult blockHit = (BlockHitResult) faceHit;
                if (blockHit.getBlockPos().equals(targetPos)) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isBlockExposed(ClientWorld world, BlockPos pos) {
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            BlockState state = world.getBlockState(neighbor);
            if (state.isAir() || !state.isOpaque()) {
                return true;
            }
        }
        return false;
    }

    private double getPlayerBlockReach(ClientPlayerEntity player) {
        try {
            if (player.getAttributes().hasAttribute(EntityAttributes.BLOCK_INTERACTION_RANGE)) {
                return player.getAttributeValue(EntityAttributes.BLOCK_INTERACTION_RANGE);
            }
        } catch (Exception ignored) {}
        return 4.5;
    }

    private boolean isCrosshairOnTarget(MinecraftClient client, BlockPos target) {
        if (client == null || target == null) return false;
        if (client.crosshairTarget instanceof BlockHitResult hit) {
            return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(target);
        }
        return false;
    }

    private boolean isAimedAt(MinecraftClient client, ClientPlayerEntity player, BlockPos targetPos, Vec3d targetPoint) {
        if (client == null || targetPos == null || player == null) return false;

        // 1. Crosshair on target block check
        if (isCrosshairOnTarget(client, targetPos)) {
            return true;
        }

        // 2. Direct camera raycast check along view vector
        Vec3d eyePos = player.getEyePos();
        Vec3d lookVec = player.getRotationVec(1.0f);
        double reach = getPlayerBlockReach(player);
        Vec3d rayEnd = eyePos.add(lookVec.multiply(reach));
        if (client.world != null) {
            HitResult hit = client.world.raycast(new RaycastContext(
                    eyePos, rayEnd,
                    RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE,
                    player
            ));
            if (hit.getType() == HitResult.Type.BLOCK && ((BlockHitResult) hit).getBlockPos().equals(targetPos)) {
                return true;
            }
        }

        // 3. Angular difference window to targetPoint
        if (targetPoint != null) {
            double diffX = targetPoint.x - eyePos.x;
            double diffY = targetPoint.y - eyePos.y;
            double diffZ = targetPoint.z - eyePos.z;
            double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            double totalDist = Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);
            float idealYaw = (float) (MathHelper.atan2(diffZ, diffX) * (180.0 / Math.PI)) - 90.0F;
            float idealPitch = (float) (-(MathHelper.atan2(diffY, diffXZ) * (180.0 / Math.PI)));
            float yawDiff = Math.abs(MathHelper.wrapDegrees(idealYaw - player.getYaw()));
            float pitchDiff = Math.abs(idealPitch - player.getPitch());

            float maxTolerance = (float) Math.min(14.0, Math.max(6.0, Math.toDegrees(Math.atan2(0.48, Math.max(0.8, totalDist)))));
            return (yawDiff < maxTolerance && pitchDiff < maxTolerance);
        }

        return false;
    }

    public void stopAttacking(MinecraftClient client) {
        if (client != null && client.options != null && client.options.attackKey != null) {
            client.options.attackKey.setPressed(false);
        }
    }

    public void stopWalking(MinecraftClient client) {
        if (client != null && client.options != null) {
            if (client.options.forwardKey != null) client.options.forwardKey.setPressed(false);
            if (client.options.backKey != null) client.options.backKey.setPressed(false);
            if (client.options.jumpKey != null) client.options.jumpKey.setPressed(false);
            if (client.options.leftKey != null) client.options.leftKey.setPressed(false);
            if (client.options.rightKey != null) client.options.rightKey.setPressed(false);
            if (client.options.sprintKey != null) client.options.sprintKey.setPressed(false);
            if (client.options.sneakKey != null) client.options.sneakKey.setPressed(false);
        }
    }

    public void cancelCurrentMining(MinecraftClient client) {
        if (client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
        currentTarget = null;
        currentTargetFace = null;
        currentTargetMiningTicks = 0;
        activePath = null;
        currentPathIndex = 0;
        pathStuckTicks = 0;
        obstructionTicks = 0;
        validatingTicks = 0;
        lastAdvancePos = null;
        advanceStuckTicks = 0;
        advanceTickCounter = 0;
        rotationController.clearTarget();
        stopAttacking(client);
        stopWalking(client);
    }

    public synchronized void resumeFromAutoStorage(MinecraftClient client) {
        stopAttacking(client);
        stopWalking(client);
        rotationController.clearTarget();
        if (config.isAutoMineEnabled()) {
            status = MiningStatus.MINING;
            miningState = MiningState.SELECTING_NEXT_TARGET;
            statusDetail = net.minecraft.text.Text.literal("Auto Storage complete. Resumed mining.").formatted(net.minecraft.util.Formatting.GREEN);
        }
    }

    /**
     * Completes a target according to the strict hold-to-mine state machine.
     * Cancels block breaking, releases attack key, transitions to TARGET_COMPLETE,
     * updates session statistics, and transitions to MINING or COMPLETE.
     */
    public void handleTargetComplete(MinecraftClient client, BlockPos pos) {
        if (client != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
        stopAttacking(client);
        status = MiningStatus.TARGET_COMPLETE;
        miningState = MiningState.CONFIRMING_COMPLETION;
        onTargetBroken(pos);

        if (targetQueue.isEmpty()) {
            // Check region for remaining blocks before declaring complete
            MinecraftClient mc = MinecraftClient.getInstance();
            if (activeRegion != null && mc != null && mc.world != null && regionStillHasEligibleBlocks(mc.world)) {
                rescanArea(mc.world);
            } else {
                status = MiningStatus.COMPLETE;
                miningState = MiningState.IDLE;
                navState = NavigationState.IDLE;
                statusDetail = Text.literal("Completed: All eligible blocks cleared.").formatted(Formatting.GREEN);
                rotationController.clearTarget();
                stopWalking(mc);
                if (mc != null && mc.player != null) {
                    mc.player.sendMessage(Text.literal("Auto Mine: All targets cleared!").formatted(Formatting.GREEN), false);
                }
            }
        } else {
            status = MiningStatus.MINING;
            miningState = MiningState.SELECTING_NEXT_TARGET;
        }
    }

    public boolean isServerRestricted(BlockPos pos) {
        if (pos == null) return false;
        Long expiry = serverRestrictedCooldowns.get(pos);
        if (expiry != null) {
            if (System.currentTimeMillis() < expiry) {
                return true;
            } else {
                serverRestrictedCooldowns.remove(pos);
                serverRestrictedTargets.remove(pos);
                return false;
            }
        }
        return serverRestrictedTargets.contains(pos);
    }

    public boolean isActivelyInteracting() {
        return currentTarget != null || (System.currentTimeMillis() - lastInteractionTimeMs < 2500L);
    }

    public BlockPos getLastAttemptedTarget() {
        return lastAttemptedTarget;
    }

    public Map<BlockPos, Long> getServerRestrictedCooldowns() {
        return Collections.unmodifiableMap(serverRestrictedCooldowns);
    }

    /**
     * Handles detected server-side block protection, claim restrictions,
     * or anti-cheat warnings safely as recoverable target failures.
     * Clears stale aim/input state, marks denied target/area temporarily excluded on cooldown,
     * and smoothly recovers to scan and mine permitted alternative targets without fatal suspension.
     */
    public synchronized void handleServerRestrictionDetected(MinecraftClient client, String reason) {
        if (!config.isAutoMineEnabled() || isHandlingServerRestriction) {
            return;
        }

        isHandlingServerRestriction = true;
        try {
            BlockPos restrictedPos = (currentTarget != null) ? currentTarget : lastAttemptedTarget;
            if (restrictedPos == null) {
                return;
            }

            long now = System.currentTimeMillis();
            long cooldownMs = config.getProtectionCooldownSeconds() * 1000L;
            long expiryTime = now + cooldownMs;

            LOGGER.warn("Server restriction detected for target [{}, {}, {}] (reason: {}). Applying {}s cooldown and recovering to next candidate.",
                    restrictedPos.getX(), restrictedPos.getY(), restrictedPos.getZ(), reason, config.getProtectionCooldownSeconds());

            serverRestrictedCooldowns.put(restrictedPos, expiryTime);
            serverRestrictedTargets.add(restrictedPos);
            targetQueue.remove(restrictedPos);
            targetLookupSet.remove(restrictedPos);
            refilledTargets.remove(restrictedPos);
            failedTargetsCount++;
            consecutiveServerRestrictions++;
            MiningDebugInfo.whySkippedReason = "Server restricted (" + (reason != null ? reason : "Protected") + ")";
            MiningDebugInfo.wasRejected = true;
            MiningDebugInfo.blockConfirmedRemoved = false;

            // If the denial indicates area protection or repeated adjacent restrictions,
            // mark immediate local cluster (radius 2) as temporarily excluded to avoid thrashing
            String reasonLower = reason != null ? reason.toLowerCase(java.util.Locale.ROOT) : "";
            boolean isArea = reasonLower.contains("area")
                    || reasonLower.contains("region")
                    || reasonLower.contains("zone")
                    || reasonLower.contains("multiple blocks")
                    || reasonLower.contains("claim")
                    || reasonLower.contains("spawn")
                    || consecutiveServerRestrictions >= 2;

            if (isArea) {
                int radius = 2;
                for (int dx = -radius; dx <= radius; dx++) {
                    for (int dy = -radius; dy <= radius; dy++) {
                        for (int dz = -radius; dz <= radius; dz++) {
                            BlockPos nearby = restrictedPos.add(dx, dy, dz);
                            serverRestrictedCooldowns.put(nearby, expiryTime);
                            serverRestrictedTargets.add(nearby);
                            targetQueue.remove(nearby);
                            targetLookupSet.remove(nearby);
                            refilledTargets.remove(nearby);
                        }
                    }
                }
                LOGGER.info("Area protection detected. Temporarily excluded 5x5x5 cluster around [{}, {}, {}] for {}s",
                        restrictedPos.getX(), restrictedPos.getY(), restrictedPos.getZ(), config.getProtectionCooldownSeconds());
            }

            // Invalidate current target and clear all stale interaction, aim, movement, and timer states
            stopAttacking(client);
            stopWalking(client);
            rotationController.clearTarget();
            if (client != null && client.interactionManager != null) {
                client.interactionManager.cancelBlockBreaking();
            }

            currentTarget = null;
            currentTargetFace = null;
            currentTargetMiningTicks = 0;
            waitingUpdateTicks = 0;
            validatingTicks = 0;
            alignmentTicks = 0;

            // Inform the player (rate limited to once per 3s to prevent chat flood)
            if (now - lastRestrictionWarningMs > 3000L && client != null && client.player != null) {
                client.player.sendMessage(Text.literal(String.format("Auto Mine: Block at [%d, %d, %d] is server-protected. Skipping to next valid block.",
                        restrictedPos.getX(), restrictedPos.getY(), restrictedPos.getZ())).formatted(Formatting.GOLD), false);
                lastRestrictionWarningMs = now;
            }

            // Safe non-fatal recovery: Transition to SELECTING_NEXT_TARGET without pausing Auto Mine
            miningState = MiningState.SELECTING_NEXT_TARGET;
            status = MiningStatus.RESCANNING;
            statusDetail = Text.literal("Server protected block skipped. Searching for permitted targets...").formatted(Formatting.GOLD);
        } finally {
            isHandlingServerRestriction = false;
        }
    }

    public int getConsecutiveTargetFailures() {
        return consecutiveTargetFailures;
    }

    public void setConsecutiveTargetFailures(int count) {
        this.consecutiveTargetFailures = count;
    }

    public MiningState getMiningState() {
        return miningState;
    }

    public void setMiningState(MiningState state) {
        this.miningState = state;
    }

    public int getFailedTargetsCount() {
        return failedTargetsCount;
    }

    public Set<BlockPos> getServerRestrictedTargets() {
        return Collections.unmodifiableSet(serverRestrictedTargets);
    }

    public void recordSkipReason(String reason) {
        MiningDebugInfo.whySkippedReason = reason != null ? reason : "Unknown";
        LOGGER.debug("Target skip/deferred: {}", reason);
    }

    private void putOnCooldown(BlockPos pos, long ticks) {
        if (pos == null) return;
        targetLookupSet.remove(pos);
        targetQueue.remove(pos);
        refilledTargets.remove(pos);
        retryCooldowns.put(pos, System.currentTimeMillis() + (ticks * 50L));
    }

    public BlockPos getCurrentTarget() {
        return currentTarget;
    }

    public void setCurrentTarget(BlockPos pos) {
        this.currentTarget = pos;
    }

    public BlockPos getActiveFootprintAnchor() {
        return activeFootprintAnchor;
    }

    public List<BlockPos> getActiveFootprint() {
        return new ArrayList<>(activeFootprint);
    }

    public int getQueuedTargetsCount() {
        return targetLookupSet.size();
    }

    public List<BlockPos> getTargetQueue() {
        return new ArrayList<>(targetQueue);
    }

    public long getSessionMinedBlocks() {
        return sessionMinedBlocks;
    }

    public MiningStatus getStatus() {
        return status;
    }

    public Text getStatusDetail() {
        return statusDetail;
    }

    public int getInitialBatchTargetCount() {
        return initialBatchTargetCount;
    }

    public int getCurrentTargetIndex() {
        if (initialBatchTargetCount <= 0) return 0;
        int remaining = targetQueue.size() + (currentTarget != null ? 1 : 0);
        return Math.max(1, Math.min(initialBatchTargetCount, initialBatchTargetCount - remaining + 1));
    }

    /**
     * Ticks background area scanning safely while player is in a menu screen,
     * without sending attack or movement packets.
     */
    public synchronized void tickScanOnly(MinecraftClient client) {
        if (client == null || client.world == null || client.player == null) return;
        if (!config.isAutoMineEnabled() || activeRegion == null) return;
        if (status != MiningStatus.SCANNING && status != MiningStatus.RESCANNING) return;

        stopWalking(client);
        stopAttacking(client);
        rotationController.clearTarget();

        int batchSize = config.getScanBatchSize();
        boolean scanFinished = areaScanner.stepScan(client.world, batchSize);

        if (!scanFinished) {
            long scanned = areaScanner.getScannedBlocks();
            long total = areaScanner.getTotalBlocks();
            int pct = (int) (areaScanner.getProgress() * 100.0f);
            statusDetail = Text.literal(String.format("Scanning — %,d / %,d positions (%d%%)", scanned, total, pct)).formatted(Formatting.YELLOW);
            return;
        }

        if (areaScanner.hasError()) {
            status = MiningStatus.ERROR;
            navState = NavigationState.IDLE;
            String err = areaScanner.getLastErrorMessage();
            statusDetail = Text.literal("Error — " + (err.isEmpty() ? "Scan failed" : err)).formatted(Formatting.RED);
            return;
        }

        List<BlockPos> detected = areaScanner.getDetectedTargets();
        targetQueue.clear();
        targetLookupSet.clear();
        unreachableTargets.clear();

        if (detected.isEmpty()) {
            status = MiningStatus.COMPLETE;
            navState = NavigationState.IDLE;
            String reason = areaScanner.getLastReasonForZeroTargets();
            statusDetail = Text.literal((reason != null && !reason.isEmpty()) ? "Complete — " + reason : "Complete — No eligible blocks found").formatted(Formatting.GREEN);
            if (client.player != null) {
                client.player.sendMessage(Text.literal("Auto Mine: Scan complete — " + ((reason != null && !reason.isEmpty()) ? reason : "No eligible blocks found in area.")).formatted(Formatting.YELLOW), false);
            }
            return;
        }

        sortCandidates(detected, config.getTargetPriority(), client.player.getEyePos(), client.player.getBlockPos());
        for (BlockPos pos : detected) {
            targetLookupSet.add(pos);
            targetQueue.add(pos);
        }
        initialBatchTargetCount = targetQueue.size();

        status = MiningStatus.MINING;
        miningState = MiningState.SELECTING_NEXT_TARGET;
        navState = NavigationState.IDLE;
        statusDetail = Text.literal(String.format("Ready — %d targets found", targetQueue.size())).formatted(Formatting.AQUA);
        if (client.player != null) {
            client.player.sendMessage(Text.literal(String.format("Auto Mine: Scan finished! Found %d targets. Starting mining...", targetQueue.size())).formatted(Formatting.GREEN), false);
        }
    }

    /**
     * Generates a clear, professional runtime status summary for HUD and GUI cards.
     */
    public String getStatusSummary() {
        switch (status) {
            case SCANNING, RESCANNING -> {
                long scanned = areaScanner.getScannedBlocks();
                long total = areaScanner.getTotalBlocks();
                if (total > 0) {
                    int pct = (int) (areaScanner.getProgress() * 100.0f);
                    return String.format("Scanning — %,d / %,d positions (%d%%)", scanned, total, pct);
                }
                return "Scanning — Initializing...";
            }
            case MINING, TARGET_COMPLETE -> {
                if (currentTarget != null && initialBatchTargetCount > 0) {
                    return String.format("Mining — Target %d of %d", getCurrentTargetIndex(), initialBatchTargetCount);
                } else if (!targetQueue.isEmpty()) {
                    return String.format("Ready — %d targets found", targetQueue.size());
                } else {
                    return "Mining — Searching targets...";
                }
            }
            case COMPLETE -> {
                if (initialBatchTargetCount > 0 && targetQueue.isEmpty() && currentTarget == null) {
                    return String.format("Complete — All %d targets mined", initialBatchTargetCount);
                }
                String reason = areaScanner.getLastReasonForZeroTargets();
                return (reason != null && !reason.isEmpty()) ? "Complete — " + reason : "Complete — No eligible blocks found";
            }
            case ERROR -> {
                String err = areaScanner.getLastErrorMessage();
                return (err != null && !err.isEmpty()) ? "Error — " + err : "Error — Scan failed. Check area selection.";
            }
            case PAUSED -> {
                return "Paused — Auto Mine suspended";
            }
            case IDLE, DISABLED -> {
                if (config.isAutoMineEnabled() && !targetQueue.isEmpty()) {
                    return String.format("Ready — %d targets found", targetQueue.size());
                }
                return config.isAutoMineEnabled() ? "Standby — Ready" : "Disabled";
            }
            case WAITING_FOR_REFILLS -> {
                return "Waiting for refills...";
            }
            case TEMPORARILY_BLOCKED -> {
                return "Blocked — Target unreachable";
            }
            default -> {
                return status.getLabel();
            }
        }
    }

    /**
     * Quickly samples the active region to check if any eligible blocks remain.
     * Uses a limited scan to avoid lag; stops as soon as one eligible block is found.
     */
    private boolean regionStillHasEligibleBlocks(ClientWorld world) {
        if (activeRegion == null || world == null) return false;
        int minX = activeRegion.getMinX(), maxX = activeRegion.getMaxX();
        int minY = activeRegion.getMinY(), maxY = activeRegion.getMaxY();
        int minZ = activeRegion.getMinZ(), maxZ = activeRegion.getMaxZ();
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        int checked = 0;
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    mutable.set(x, y, z);
                    if (!world.isChunkLoaded(mutable)) continue;
                    if (checked++ > 5000) return false; // Safety limit
                    BlockState state = world.getBlockState(mutable);
                    if (!state.isAir() && filter.isEligible(world, mutable, state)) {
                        if (!isServerRestricted(mutable.toImmutable())) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Finds the nearest eligible block within the active region using a radius-expanding search.
     * Used to navigate toward remaining blocks when the local queue is exhausted.
     */
    private BlockPos findNearestEligibleInRegion(ClientPlayerEntity player, ClientWorld world) {
        if (activeRegion == null || world == null || player == null) return null;
        Vec3d eyePos = player.getEyePos();
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        int minX = activeRegion.getMinX(), maxX = activeRegion.getMaxX();
        int minY = activeRegion.getMinY(), maxY = activeRegion.getMaxY();
        int minZ = activeRegion.getMinZ(), maxZ = activeRegion.getMaxZ();
        int checked = 0;
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    mutable.set(x, y, z);
                    if (!world.isChunkLoaded(mutable)) continue;
                    if (checked++ > 8000) break;
                    BlockState state = world.getBlockState(mutable);
                    if (state.isAir() || !filter.isEligible(world, mutable, state)) continue;
                    BlockPos immutable = mutable.toImmutable();
                    if (isServerRestricted(immutable)) continue;
                    Long cd = retryCooldowns.get(immutable);
                    if (cd != null && System.currentTimeMillis() < cd) continue;
                    double dist = eyePos.squaredDistanceTo(Vec3d.ofCenter(immutable));
                    if (dist < bestDist) {
                        bestDist = dist;
                        best = immutable;
                    }
                }
            }
        }
        return best;
    }
}
