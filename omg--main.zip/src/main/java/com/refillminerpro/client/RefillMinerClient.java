package com.refillminerpro.client;

import com.refillminerpro.client.gui.RefillMinerHud;
import com.refillminerpro.client.gui.RefillMinerScreen;
import com.refillminerpro.client.render.RegionRenderer;
import com.refillminerpro.config.ConfigManager;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.OperatingMode;
import com.refillminerpro.config.ServerIdentifier;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.RefillMonitor;
import com.refillminerpro.region.BlockRegion;
import com.refillminerpro.region.SelectionManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RefillMinerClient implements ClientModInitializer {
    public static final String MOD_ID = "refillminerpro";
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/Client");

    private static RefillMinerClient instance;

    private ConfigManager configManager;
    private SelectionManager selectionManager;
    private BlockFilter blockFilter;
    private MiningEngine miningEngine;
    private RefillMonitor refillMonitor;
    private com.refillminerpro.storage.StorageActivityLogger storageLogger;
    private com.refillminerpro.storage.AutoStorageEngine autoStorageEngine;

    // Environment tracking for saved area restoration
    private String lastKnownServer = null;
    private String lastKnownDimension = null;

    // Keybindings
    private KeyBinding toggleAutoMineKey;
    private KeyBinding toggleSelectionModeKey;
    private KeyBinding togglePauseKey;
    private KeyBinding resetSelectionKey;
    private KeyBinding toggleOutlineKey;
    private KeyBinding openSettingsKey;

    public static RefillMinerClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("Initializing Refill Miner Pro client...");

        this.configManager = new ConfigManager();
        this.configManager.load();

        this.selectionManager = new SelectionManager();
        this.selectionManager.reset(); // Crucial constraint: strictly clean runtime state on launch
        this.configManager.getConfig().setAutoMineEnabled(false);
        this.configManager.getConfig().setPaused(false);

        this.blockFilter = new BlockFilter(configManager.getConfig());
        this.miningEngine = new MiningEngine(configManager.getConfig(), blockFilter);
        this.refillMonitor = new RefillMonitor(configManager.getConfig(), blockFilter, miningEngine);
        this.storageLogger = new com.refillminerpro.storage.StorageActivityLogger();
        this.autoStorageEngine = new com.refillminerpro.storage.AutoStorageEngine(configManager.getConfig().getAutoStorage(), storageLogger);

        registerKeybindings();
        registerEvents();

        LOGGER.info("Refill Miner Pro client initialized successfully.");
    }

    private void registerKeybindings() {
        KeyBinding.Category category = KeyBinding.Category.create(net.minecraft.util.Identifier.of("refillminerpro", "controls"));

        toggleAutoMineKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.refillminerpro.toggle_automine",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                category
        ));

        toggleSelectionModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.refillminerpro.toggle_selection_mode",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                category
        ));

        togglePauseKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.refillminerpro.toggle_pause",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_N,
                category
        ));

        resetSelectionKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.refillminerpro.reset_selection",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                category
        ));

        toggleOutlineKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.refillminerpro.toggle_outline",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                category
        ));

        openSettingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.refillminerpro.open_settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                category
        ));
    }

    private void registerEvents() {
        // Intercept block break punch in selection mode
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.isClient() && selectionManager.isSelectionModeActive()) {
                selectionManager.setCorner1(pos);
                notifyPlayer(player, Text.literal(String.format("Corner 1 set to [%d, %d, %d]", pos.getX(), pos.getY(), pos.getZ())).formatted(Formatting.GREEN));
                playClickFeedback();
                if (getConfig().isAutoMineEnabled() && selectionManager.isComplete()) {
                    miningEngine.setActiveRegion(selectionManager.getCurrentRegion());
                }
                return ActionResult.FAIL; // Prevent block breaking
            }
            return ActionResult.PASS;
        });

        // Intercept block right-click in selection mode
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.isClient() && selectionManager.isSelectionModeActive()) {
                BlockPos pos = hitResult.getBlockPos();
                selectionManager.setCorner2(pos);
                notifyPlayer(player, Text.literal(String.format("Corner 2 set to [%d, %d, %d]", pos.getX(), pos.getY(), pos.getZ())).formatted(Formatting.GREEN));
                playClickFeedback();

                SelectionManager.ValidationResult result = selectionManager.validate(getConfig());
                notifyPlayer(player, result.message());

                if (getConfig().isAutoMineEnabled() && selectionManager.isComplete()) {
                    miningEngine.setActiveRegion(selectionManager.getCurrentRegion());
                }
                return ActionResult.FAIL; // Prevent block placing
            }
            return ActionResult.PASS;
        });

        // Client Tick Handler
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            handleKeyInputs(client);

            if (client.world != null && client.player != null) {
                // Check for dimension switch
                String currentDim = getDimensionIdentifier(client);
                if (lastKnownDimension != null && !lastKnownDimension.equals(currentDim)) {
                    LOGGER.info("Dimension changed from {} to {}", lastKnownDimension, currentDim);
                    lastKnownDimension = currentDim;
                    if (getConfig().isRestoreLastAreaOnJoin()) {
                        restoreSavedAreaForCurrentEnvironment(client, true);
                    } else {
                        selectionManager.reset();
                    }
                } else if (lastKnownDimension == null) {
                    lastKnownDimension = currentDim;
                }

                // Anti-kick protection: Do not tick automated actions while in non-handled GUI screens (such as settings, pause menu)
                boolean isInNonHandledScreen = client.currentScreen != null && !(client.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen);
                if (isInNonHandledScreen) {
                    miningEngine.stopAttacking(client);
                    miningEngine.stopWalking(client);
                    miningEngine.getRotationController().clearTarget();
                    // Crucial: Allow deterministic area scanning to proceed safely in the background while GUI screens are open!
                    if (miningEngine.getStatus() == com.refillminerpro.engine.MiningStatus.SCANNING || miningEngine.getStatus() == com.refillminerpro.engine.MiningStatus.RESCANNING) {
                        miningEngine.tickScanOnly(client);
                    }
                    return;
                }

                if (autoStorageEngine != null) {
                    autoStorageEngine.tick(client);
                }

                if (autoStorageEngine != null && autoStorageEngine.isBusy()) {
                    miningEngine.stopAttacking(client);
                    miningEngine.stopWalking(client);
                    miningEngine.getRotationController().clearTarget();
                } else {
                    refillMonitor.tick(client.world);
                    try {
                        miningEngine.tick(client);
                    } catch (Throwable t) {
                        LOGGER.error("Safely caught unexpected exception in miningEngine.tick(): ", t);
                    }
                }
            }
        });

        // World connection handlers
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            String serverAddress = getServerIdentifier(client);
            String dimension = getDimensionIdentifier(client);
            lastKnownServer = serverAddress;
            lastKnownDimension = dimension;
            LOGGER.info("Joined world/server: {} ({})", serverAddress, dimension);

            // Clean runtime automation state strictly to IDLE on every world/server join
            getConfig().setAutoMineEnabled(false);
            getConfig().setPaused(false);
            miningEngine.reset(true);
            refillMonitor.stopMonitoring();
            if (autoStorageEngine != null) {
                autoStorageEngine.reset();
            }

            // Restore saved area if enabled
            if (getConfig().isRestoreLastAreaOnJoin()) {
                restoreSavedAreaForCurrentEnvironment(client, true);
            } else {
                selectionManager.reset();
            }

            // Enforce safe operating mode immediately on join
            OperatingMode mode = getCurrentOperatingMode();
            if (!mode.isAutoMineAllowed()) {
                LOGGER.info("Joined unverified server '{}' - Safe Utility Only mode active; automation inhibited.", serverAddress);
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            LOGGER.info("Disconnected from world/server. Cleaning up transient state...");
            // Save active selection coordinates if an active profile is linked
            if (selectionManager.isComplete() && lastKnownServer != null && lastKnownDimension != null) {
                String activeId = getConfig().getLastActiveAreaId();
                if (activeId != null) {
                    configManager.updateAreaCoordinates(activeId, selectionManager.getCurrentRegion());
                }
            }

            selectionManager.reset();
            getConfig().setAutoMineEnabled(false);
            getConfig().setPaused(false);
            miningEngine.reset(true);
            refillMonitor.stopMonitoring();
            if (autoStorageEngine != null) {
                autoStorageEngine.reset();
            }
            lastKnownServer = null;
            lastKnownDimension = null;
        });

        // Server protection & chat message interceptor (including actionbar overlay messages)
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (message != null) {
                checkServerProtectionMessage(message.getString());
            }
        });
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            if (message != null) {
                checkServerProtectionMessage(message.getString());
            }
        });

        // Render callbacks
        HudRenderCallback.EVENT.register(RefillMinerHud::render);
        WorldRenderEvents.START_MAIN.register(context -> {
            if (miningEngine != null && miningEngine.getRotationController() != null) {
                miningEngine.getRotationController().onRenderFrame(MinecraftClient.getInstance());
            }
        });
        WorldRenderEvents.AFTER_ENTITIES.register(RegionRenderer::render);
    }

    private void handleKeyInputs(MinecraftClient client) {
        if (client.currentScreen != null) return;

        while (toggleAutoMineKey.wasPressed()) {
            toggleAutoMine();
        }

        while (toggleSelectionModeKey.wasPressed()) {
            selectionManager.toggleSelectionMode();
            Text msg = selectionManager.isSelectionModeActive()
                    ? Text.literal("Selection Mode: ACTIVE (Left-click: C1, Right-click: C2)").formatted(Formatting.GREEN)
                    : Text.literal("Selection Mode: INACTIVE").formatted(Formatting.RED);
            notifyPlayer(client.player, msg);
            playClickFeedback();
        }

        while (togglePauseKey.wasPressed()) {
            togglePause();
        }

        while (resetSelectionKey.wasPressed()) {
            resetSelection();
        }

        while (toggleOutlineKey.wasPressed()) {
            boolean outline = !getConfig().isOutlineVisible();
            getConfig().setOutlineVisible(outline);
            configManager.save();
            notifyPlayer(client.player, Text.literal("Outline visibility: " + (outline ? "ON" : "OFF")).formatted(Formatting.YELLOW));
            playClickFeedback();
        }

        while (openSettingsKey.wasPressed()) {
            miningEngine.stopWalking(client);
            client.setScreen(new RefillMinerScreen(null));
        }
    }

    public OperatingMode getCurrentOperatingMode() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return OperatingMode.UTILITY_ONLY;
        if (mc.isInSingleplayer()) {
            return OperatingMode.SINGLEPLAYER;
        }
        String serverId = getServerIdentifier(mc);
        if (getConfig().isEnvironmentAuthorized(serverId)) {
            return OperatingMode.AUTHORIZED_SERVER;
        }
        return OperatingMode.UTILITY_ONLY;
    }

    public void setAutoMineEnabled(boolean enabled) {
        ModConfig cfg = getConfig();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (enabled) {
            OperatingMode mode = getCurrentOperatingMode();
            if (!mode.isAutoMineAllowed()) {
                cfg.setAutoMineEnabled(false);
                notifyPlayer(mc != null ? mc.player : null, Text.literal("Auto Mine is disabled on unauthorized public servers (Utility Only mode active).").formatted(Formatting.RED));
                playClickFeedback();
                configManager.save();
                return;
            }

            cfg.setAutoMineEnabled(true);
            cfg.setPaused(false);
            cfg.setPlayerControlledMining(false);
            if (autoStorageEngine != null) {
                autoStorageEngine.resetAllVaultsCompleted();
            }
            miningEngine.reset(false);

            BlockRegion reg = selectionManager.getCurrentRegion();
            if (reg == null && mc != null && mc.player != null) {
                // Try restoring saved area for current server/dimension
                restoreSavedAreaForCurrentEnvironment(mc, false);
                reg = selectionManager.getCurrentRegion();
            }

            if (reg == null && mc != null && mc.player != null) {
                // Auto-create a default 9x6x9 area centered on player if none exists yet
                BlockPos p = mc.player.getBlockPos();
                reg = new BlockRegion(p.add(-4, -2, -4), p.add(4, 3, 4));
                selectionManager.setCorner1(reg.getMinPos());
                selectionManager.setCorner2(reg.getMaxPos());
                notifyPlayer(mc.player, Text.literal("Auto Mine: Created default 9x6x9 area around you. (Use C1/C2 or Saved Areas to customize)").formatted(Formatting.YELLOW));
            }

            if (reg != null) {
                miningEngine.setActiveRegion(reg);
                if (mc != null && mc.world != null) {
                    miningEngine.startAreaScan(mc.world);
                    refillMonitor.startMonitoring(reg, mc.world);
                }
                notifyPlayer(mc != null ? mc.player : null, Text.literal("Auto Mine ENABLED — Started scanning and mining " + reg.getVolume() + " blocks.").formatted(Formatting.GREEN));
            }
            playClickFeedback();
        } else {
            cfg.setAutoMineEnabled(false);
            if (autoStorageEngine != null) {
                autoStorageEngine.reset();
            }
            miningEngine.reset(false);
            refillMonitor.stopMonitoring();
            notifyPlayer(mc != null ? mc.player : null, Text.literal("Auto Mine DISABLED.").formatted(Formatting.RED));
            playClickFeedback();
        }
        configManager.save();
    }

    public void toggleAutoMine() {
        setAutoMineEnabled(!getConfig().isAutoMineEnabled());
    }

    public void togglePause() {
        ModConfig cfg = getConfig();
        if (!cfg.isAutoMineEnabled()) {
            notifyPlayer(MinecraftClient.getInstance().player, Text.literal("Cannot pause: Auto Mine is disabled.").formatted(Formatting.YELLOW));
            return;
        }
        boolean paused = !cfg.isPaused();
        cfg.setPaused(paused);
        if (paused) {
            miningEngine.stopWalking(MinecraftClient.getInstance());
        }
        configManager.save();
        notifyPlayer(MinecraftClient.getInstance().player, Text.literal("Auto Mine " + (paused ? "PAUSED." : "RESUMED.")).formatted(paused ? Formatting.YELLOW : Formatting.GREEN));
        playClickFeedback();
    }

    public void resetSelection() {
        selectionManager.reset();
        refillMonitor.stopMonitoring();
        miningEngine.reset(false);
        notifyPlayer(MinecraftClient.getInstance().player, Text.literal("Region selection reset.").formatted(Formatting.RED));
        playClickFeedback();
    }

    public void onBlockUpdate(BlockPos pos, BlockState newState) {
        if (miningEngine != null) {
            miningEngine.onBlockStateChanged(pos, newState);
        }
        if (refillMonitor != null) {
            refillMonitor.onBlockStateChanged(MinecraftClient.getInstance().world, pos, newState);
        }
    }

    public void checkServerProtectionMessage(String messageText) {
        if (messageText == null || !getConfig().isAutoMineEnabled() || miningEngine == null) return;
        
        String clean = messageText.trim();
        String lower = clean.toLowerCase(java.util.Locale.ROOT);

        // Crucial: Never self-trigger on the mod's own notifications!
        if (lower.startsWith("auto mine") || lower.contains("[refill miner") || lower.contains("kiiuwt")) {
            return;
        }

        // Only react to protection messages if mining is actively interacting or aimed at a target
        if (!miningEngine.isActivelyInteracting() && miningEngine.getCurrentTarget() == null) {
            return;
        }
        boolean isProtectionDenial = lower.contains("can't break")
                || lower.contains("cannot break")
                || lower.contains("cant break")
                || lower.contains("don't have permission")
                || lower.contains("do not have permission")
                || lower.contains("no permission")
                || lower.contains("not have permission")
                || lower.contains("area is protected")
                || lower.contains("region is protected")
                || lower.contains("block is protected")
                || lower.contains("server-protected")
                || lower.contains("server protected")
                || lower.contains("protected area")
                || lower.contains("protected region")
                || lower.contains("protected block")
                || lower.contains("not permitted to break")
                || lower.contains("not permitted")
                || lower.contains("cannot mine")
                || lower.contains("can't mine")
                || lower.contains("cant mine")
                || lower.contains("you are not allowed to break")
                || lower.contains("you are not allowed to mine")
                || lower.contains("you are not allowed to interact")
                || lower.contains("not allowed to edit")
                || lower.contains("protected by")
                || lower.contains("claim")
                || lower.contains("belongs to")
                || lower.contains("spawn protection")
                || lower.contains("action prevented")
                || lower.contains("you can't build")
                || lower.contains("you cannot build")
                || (lower.contains("protected") && (lower.contains("area") || lower.contains("block") || lower.contains("multiple") || lower.contains("server") || lower.contains("zone")));

        if (isProtectionDenial) {
            MinecraftClient mc = MinecraftClient.getInstance();
            miningEngine.handleServerRestrictionDetected(mc, messageText);
            playErrorFeedback();
        }
    }

    public String getServerIdentifier(MinecraftClient client) {
        if (client == null) return "unknown";
        if (client.getCurrentServerEntry() != null) {
            return ServerIdentifier.normalize(client.getCurrentServerEntry().address);
        } else if (client.isInSingleplayer()) {
            if (client.getServer() != null) {
                try {
                    String levelName = client.getServer().getSaveProperties().getLevelName();
                    if (levelName != null && !levelName.trim().isEmpty()) {
                        return "singleplayer:" + levelName.trim().toLowerCase(java.util.Locale.ROOT);
                    }
                } catch (Throwable ignored) {}
            }
            return "singleplayer:default";
        }
        return "unknown";
    }

    public String getDimensionIdentifier(MinecraftClient client) {
        if (client == null || client.world == null) return "minecraft:overworld";
        try {
            return client.world.getRegistryKey().getValue().toString();
        } catch (Throwable ignored) {
            return "minecraft:overworld";
        }
    }

    public void restoreSavedAreaForCurrentEnvironment(MinecraftClient client, boolean announce) {
        if (client == null) return;
        String server = getServerIdentifier(client);
        String dim = getDimensionIdentifier(client);

        if (!getConfig().isRestoreLastAreaOnJoin()) {
            LOGGER.info("Restore Last Area on Join is disabled; skipping auto-restore for {} ({})", server, dim);
            return;
        }

        com.refillminerpro.config.SavedAreaProfile profile = configManager.findLastActiveArea(server, dim);
        if (profile != null) {
            selectionManager.setRegion(profile.toBlockRegion());
            configManager.setActiveArea(profile.getId());
            LOGGER.info("Restored saved area '{}' for {} ({})", profile.getName(), server, dim);
            if (announce && client.player != null) {
                notifyPlayer(client.player, Text.literal("Restored saved area: " + profile.getName())
                        .formatted(Formatting.AQUA));
            }
        } else {
            LOGGER.debug("No saved area found matching {} ({})", server, dim);
        }
    }

    public boolean loadSavedArea(com.refillminerpro.config.SavedAreaProfile profile) {
        if (profile == null) return false;
        selectionManager.setRegion(profile.toBlockRegion());
        configManager.setActiveArea(profile.getId());
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            notifyPlayer(mc.player, Text.literal("Loaded area: " + profile.getName()).formatted(Formatting.GREEN));
            playClickFeedback();
        }
        return true;
    }

    public com.refillminerpro.config.SavedAreaProfile saveActiveSelectionAsNamedArea(String name) {
        if (!selectionManager.isComplete()) return null;
        MinecraftClient mc = MinecraftClient.getInstance();
        String server = getServerIdentifier(mc);
        String dim = getDimensionIdentifier(mc);

        com.refillminerpro.config.SavedAreaProfile profile = com.refillminerpro.config.SavedAreaProfile.fromRegion(
                name, server, dim, selectionManager.getCurrentRegion()
        );
        configManager.saveArea(profile);
        if (mc.player != null) {
            notifyPlayer(mc.player, Text.literal("Saved area: " + profile.getName()).formatted(Formatting.GREEN));
            playClickFeedback();
        }
        return profile;
    }

    private void notifyPlayer(net.minecraft.entity.player.PlayerEntity player, Text message) {
        if (player != null && message != null) {
            player.sendMessage(message, true);
        }
    }

    public void playClickFeedback() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.35f, 1.2f);
        }
    }

    public void playCompletionSound() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.player != null) {
            mc.player.playSound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        }
    }

    public void playErrorFeedback() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 0.5f, 0.6f);
        }
    }

    public ModConfig getConfig() {
        return configManager.getConfig();
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public SelectionManager getSelectionManager() {
        return selectionManager;
    }

    public BlockFilter getBlockFilter() {
        return blockFilter;
    }

    public MiningEngine getMiningEngine() {
        return miningEngine;
    }

    public RefillMonitor getRefillMonitor() {
        return refillMonitor;
    }

    public com.refillminerpro.storage.StorageActivityLogger getStorageLogger() {
        return storageLogger;
    }

    public com.refillminerpro.storage.AutoStorageEngine getAutoStorageEngine() {
        return autoStorageEngine;
    }
}
