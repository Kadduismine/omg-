package com.refillminerpro.client.render;

import com.refillminerpro.client.RefillMinerClient;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.region.BlockRegion;
import com.refillminerpro.region.SelectionManager;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * High-performance, lightweight wireframe renderer for selected regions and active mining targets.
 */
public class RegionRenderer {
    public static void render(WorldRenderContext context) {
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance == null) return;

        ModConfig config = clientInstance.getConfig();
        if (config == null || !config.isOutlineVisible()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) return;

        Vec3d cameraPos = mc.gameRenderer.getCamera().getCameraPos();
        MatrixStack matrices = context.matrices();
        VertexConsumer consumer = context.consumers().getBuffer(RenderLayers.lines());

        SelectionManager selection = clientInstance.getSelectionManager();
        BlockRegion region = selection.getCurrentRegion();

        // 1. Render Region wireframe if region exists
        if (region != null) {
            float r = config.isAutoMineEnabled() ? (config.isPaused() ? 1.0f : 0.2f) : 0.8f;
            float g = config.isAutoMineEnabled() ? (config.isPaused() ? 0.8f : 1.0f) : 0.3f;
            float b = config.isAutoMineEnabled() ? (config.isPaused() ? 0.2f : 0.4f) : 1.0f;
            float a = 0.85f;

            drawBoxOutline(matrices, consumer, cameraPos,
                    region.getMinX(), region.getMinY(), region.getMinZ(),
                    region.getMaxX() + 1.0, region.getMaxY() + 1.0, region.getMaxZ() + 1.0,
                    r, g, b, a);
        } else if (selection.isSelectionModeActive() && selection.getCorner1() != null) {
            // Render Corner 1 indicator box
            BlockPos c1 = selection.getCorner1();
            drawBoxOutline(matrices, consumer, cameraPos,
                    c1.getX(), c1.getY(), c1.getZ(),
                    c1.getX() + 1.0, c1.getY() + 1.0, c1.getZ() + 1.0,
                    1.0f, 0.9f, 0.2f, 0.7f);
        }

        // 2. Render Active Target block highlight (amber pulsating)
        BlockPos currentTarget = clientInstance.getMiningEngine().getCurrentTarget();
        if (currentTarget != null) {
            float pulse = (float) (Math.sin(System.currentTimeMillis() / 150.0) * 0.2 + 0.8);
            drawBoxOutline(matrices, consumer, cameraPos,
                    currentTarget.getX(), currentTarget.getY(), currentTarget.getZ(),
                    currentTarget.getX() + 1.0, currentTarget.getY() + 1.0, currentTarget.getZ() + 1.0,
                    1.0f, 0.5f * pulse, 0.1f, 0.9f);
        }
    }

    private static void drawBoxOutline(MatrixStack matrices, VertexConsumer consumer, Vec3d cam,
                                       double minX, double minY, double minZ,
                                       double maxX, double maxY, double maxZ,
                                       float r, float g, float b, float a) {
        float x1 = (float) (minX - cam.x);
        float y1 = (float) (minY - cam.y);
        float z1 = (float) (minZ - cam.z);
        float x2 = (float) (maxX - cam.x);
        float y2 = (float) (maxY - cam.y);
        float z2 = (float) (maxZ - cam.z);

        // Bottom 4 edges
        drawLine(matrices, consumer, x1, y1, z1, x2, y1, z1, r, g, b, a);
        drawLine(matrices, consumer, x2, y1, z1, x2, y1, z2, r, g, b, a);
        drawLine(matrices, consumer, x2, y1, z2, x1, y1, z2, r, g, b, a);
        drawLine(matrices, consumer, x1, y1, z2, x1, y1, z1, r, g, b, a);

        // Top 4 edges
        drawLine(matrices, consumer, x1, y2, z1, x2, y2, z1, r, g, b, a);
        drawLine(matrices, consumer, x2, y2, z1, x2, y2, z2, r, g, b, a);
        drawLine(matrices, consumer, x2, y2, z2, x1, y2, z2, r, g, b, a);
        drawLine(matrices, consumer, x1, y2, z2, x1, y2, z1, r, g, b, a);

        // Vertical 4 edges
        drawLine(matrices, consumer, x1, y1, z1, x1, y2, z1, r, g, b, a);
        drawLine(matrices, consumer, x2, y1, z1, x2, y2, z1, r, g, b, a);
        drawLine(matrices, consumer, x2, y1, z2, x2, y2, z2, r, g, b, a);
        drawLine(matrices, consumer, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void drawLine(MatrixStack matrices, VertexConsumer consumer,
                                 float x1, float y1, float z1,
                                 float x2, float y2, float z2,
                                 float r, float g, float b, float a) {
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f mat = entry.getPositionMatrix();

        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        float nx = len > 1.0e-5f ? dx / len : 0.0f;
        float ny = len > 1.0e-5f ? dy / len : 1.0f;
        float nz = len > 1.0e-5f ? dz / len : 0.0f;

        consumer.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(entry, nx, ny, nz).lineWidth(2.0f);
        consumer.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(entry, nx, ny, nz).lineWidth(2.0f);
    }
}

