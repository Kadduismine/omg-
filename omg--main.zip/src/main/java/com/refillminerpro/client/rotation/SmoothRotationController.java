package com.refillminerpro.client.rotation;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.engine.MiningDebugInfo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Natural, frame-rate-independent visual camera and head rotation controller.
 * Runs on rendering frame events (WorldRenderEvents.START_MAIN).
 * Features:
 * - Proper critically damped spring-damper / smooth exponential decay without oscillation
 * - Shortest-path yaw wraparound (-180 to +180) to eliminate 180-degree snapping
 * - Pitch clamped smoothly between -90 and +90
 * - Angular acceleration and velocity limiting
 * - Sensitive, zero-lag manual human mouse override
 * - Fully decoupled from 20 TPS tick rate
 */
public class SmoothRotationController {
    private final ModConfig config;

    private Vec3d targetLookPoint = null;
    private BlockPos targetBlock = null;

    private float targetYaw = 0.0f;
    private float targetPitch = 0.0f;
    private boolean hasTarget = false;

    // Velocity state for smooth acceleration/deceleration (degrees/sec)
    private double currentYawVelocity = 0.0;
    private double currentPitchVelocity = 0.0;

    // High-resolution delta time tracking
    private long lastRenderTimeNanos = 0;

    // Manual override tracking
    private float lastKnownPlayerYaw = 0.0f;
    private float lastKnownPlayerPitch = 0.0f;
    private long manualOverrideUntilMs = 0;

    public SmoothRotationController(ModConfig config) {
        this.config = config;
    }

    /**
     * Sets the target point that the player camera should smoothly face.
     */
    public synchronized void setTarget(Vec3d lookPoint, BlockPos targetBlock) {
        this.targetLookPoint = lookPoint;
        this.targetBlock = targetBlock;
        this.hasTarget = lookPoint != null;
    }

    public synchronized void clearTarget() {
        this.targetLookPoint = null;
        this.targetBlock = null;
        this.hasTarget = false;
        this.currentYawVelocity = 0.0;
        this.currentPitchVelocity = 0.0;
    }

    public boolean hasTarget() {
        return hasTarget;
    }

    public boolean isManualOverrideActive() {
        return System.currentTimeMillis() < manualOverrideUntilMs;
    }

    /**
     * Frame-rate-independent render frame interpolation.
     * Called on WorldRenderEvents.START_MAIN before every rendered frame.
     */
    public void onRenderFrame(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) {
            lastRenderTimeNanos = 0;
            return;
        }

        ClientPlayerEntity player = client.player;
        long nowNanos = System.nanoTime();

        if (lastRenderTimeNanos == 0) {
            lastRenderTimeNanos = nowNanos;
            lastKnownPlayerYaw = player.getYaw();
            lastKnownPlayerPitch = player.getPitch();
            return;
        }

        double dt = (nowNanos - lastRenderTimeNanos) / 1_000_000_000.0;
        lastRenderTimeNanos = nowNanos;

        // Cap dt to prevent massive jumps when alt-tabbing or loading worlds
        if (dt > 0.1) dt = 0.1;
        if (dt <= 0.0001) return;

        float playerYaw = player.getYaw();
        float playerPitch = player.getPitch();

        // Disable automated camera control if automation is inactive, paused, or manual assist is selected
        if (!config.isAutoMineEnabled() || config.isPaused() || config.isPlayerControlledMining()) {
            clearTarget();
            lastKnownPlayerYaw = playerYaw;
            lastKnownPlayerPitch = playerPitch;
            return;
        }

        // 1. Detect manual player mouse input (human override)
        float manualYawDiff = Math.abs(MathHelper.wrapDegrees(playerYaw - lastKnownPlayerYaw));
        float manualPitchDiff = Math.abs(playerPitch - lastKnownPlayerPitch);

        // If player moved mouse independently, grant immediate override
        if (config.isManualOverrideEnabled() && (manualYawDiff > 2.5f || manualPitchDiff > 2.5f)) {
            manualOverrideUntilMs = System.currentTimeMillis() + Math.min(config.getManualOverrideCooldownMs(), 300L);
            currentYawVelocity = 0.0;
            currentPitchVelocity = 0.0;
        }

        if (isManualOverrideActive()) {
            lastKnownPlayerYaw = player.getYaw();
            lastKnownPlayerPitch = player.getPitch();
            return;
        }

        if (!hasTarget || targetLookPoint == null) {
            lastKnownPlayerYaw = player.getYaw();
            lastKnownPlayerPitch = player.getPitch();
            currentYawVelocity = 0.0;
            currentPitchVelocity = 0.0;
            return;
        }

        // 2. Calculate ideal target yaw & pitch
        Vec3d eyePos = player.getEyePos();
        double diffX = targetLookPoint.x - eyePos.x;
        double diffY = targetLookPoint.y - eyePos.y;
        double diffZ = targetLookPoint.z - eyePos.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        if (Double.isNaN(diffX) || Double.isNaN(diffY) || Double.isNaN(diffZ) || diffXZ < 1e-4) {
            return;
        }

        targetYaw = (float) (MathHelper.atan2(diffZ, diffX) * (180.0 / Math.PI)) - 90.0F;
        targetPitch = (float) (-(MathHelper.atan2(diffY, diffXZ) * (180.0 / Math.PI)));

        if (Float.isNaN(targetYaw) || Float.isInfinite(targetYaw) || Float.isNaN(targetPitch) || Float.isInfinite(targetPitch)) {
            return;
        }

        targetPitch = MathHelper.clamp(targetPitch, -90.0F, 90.0F);

        MiningDebugInfo.targetYaw = targetYaw;
        MiningDebugInfo.targetPitch = targetPitch;
        MiningDebugInfo.playerYaw = playerYaw;
        MiningDebugInfo.playerPitch = playerPitch;

        // Shortest-distance yaw wraparound
        float yawDiff = MathHelper.wrapDegrees(targetYaw - playerYaw);
        float pitchDiff = targetPitch - playerPitch;

        // Fine deadzone: when crosshair is already settled within 0.1 degrees
        if (Math.abs(yawDiff) < 0.1f && Math.abs(pitchDiff) < 0.1f) {
            currentYawVelocity = 0.0;
            currentPitchVelocity = 0.0;
            lastKnownPlayerYaw = player.getYaw();
            lastKnownPlayerPitch = player.getPitch();
            return;
        }

        // 3. Smooth Critical Damped Dynamics
        // Smoothly accelerates towards target and naturally decelerates to zero as it settles
        double response = config.getRotationResponse(); // e.g. 12.0 - 18.0
        double maxVelocity = config.getMaxAngularVelocity(); // e.g. 210 deg/s

        // Desired velocity proportional to angular displacement
        double desiredYawVel = MathHelper.clamp(yawDiff * response, -maxVelocity, maxVelocity);
        double desiredPitchVel = MathHelper.clamp(pitchDiff * response, -maxVelocity, maxVelocity);

        // Max angular acceleration (e.g. 1200 deg/s^2)
        double maxAccel = maxVelocity * 5.0;
        double maxAccelStep = maxAccel * dt;

        currentYawVelocity += MathHelper.clamp(desiredYawVel - currentYawVelocity, -maxAccelStep, maxAccelStep);
        currentPitchVelocity += MathHelper.clamp(desiredPitchVel - currentPitchVelocity, -maxAccelStep, maxAccelStep);

        double stepYaw = currentYawVelocity * dt;
        double stepPitch = currentPitchVelocity * dt;

        // Prevent overshooting the target position in this frame
        if (stepYaw * yawDiff > 0 && Math.abs(stepYaw) >= Math.abs(yawDiff)) {
            stepYaw = yawDiff;
            currentYawVelocity = 0.0;
        }
        if (stepPitch * pitchDiff > 0 && Math.abs(stepPitch) >= Math.abs(pitchDiff)) {
            stepPitch = pitchDiff;
            currentPitchVelocity = 0.0;
        }

        float newYaw = playerYaw + (float) stepYaw;
        float newPitch = MathHelper.clamp(playerPitch + (float) stepPitch, -90.0F, 90.0F);

        player.setYaw(newYaw);
        player.setHeadYaw(newYaw);
        player.setPitch(newPitch);

        lastKnownPlayerYaw = newYaw;
        lastKnownPlayerPitch = newPitch;
    }
}
