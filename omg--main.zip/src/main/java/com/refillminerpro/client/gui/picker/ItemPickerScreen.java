package com.refillminerpro.client.gui.picker;

import com.refillminerpro.client.RefillMinerClient;
import com.refillminerpro.client.gui.arc.PredictiveArcRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.Consumer;

/**
 * Premium, visual Minecraft Item Picker Screen for Refill Miner Pro.
 * Provides real item icon rendering, instant multi-criteria search, category filters,
 * multi-selection management, and virtual scrolling.
 */
public class ItemPickerScreen extends Screen {
    private static final int COLOR_BG = 0x160B0D12;
    private static final int COLOR_PANEL = 0x1E121620;
    private static final int COLOR_CARD = 0x24171C28;
    private static final int COLOR_CARD_HOVER = 0x3E1E2638;
    private static final int COLOR_CARD_SELECTED = 0x3E142E1F;
    private static final int COLOR_BORDER = 0x358498FF;
    private static final int COLOR_BORDER_SELECTED = 0x883FB950;
    private static final int COLOR_BORDER_HOVER = 0x888498FF;
    private static final int COLOR_ACCENT = 0xFF8498FF;
    private static final int COLOR_TEXT_MAIN = 0xFFF0F6FC;
    private static final int COLOR_TEXT_SEC = 0xFFA0A9B9;
    private static final int COLOR_TEXT_MUTED = 0xFF727D90;

    private final Screen parent;
    private final String pickerTitle;
    private final Set<String> selectedIds = new HashSet<>();
    private final Consumer<List<String>> onConfirm;

    private TextFieldWidget searchField;
    private String searchQuery = "";
    private ItemCategory activeCategory = ItemCategory.ALL;

    private List<ItemCatalogueEntry> filteredEntries = new ArrayList<>();

    // Grid layout and scrolling
    private int gridX;
    private int gridY;
    private int gridW;
    private int gridH;
    private int scrollOffset = 0;
    private int maxScroll = 0;
    private boolean isScrolling = false;

    private ButtonWidget confirmButton;
    private final List<ButtonWidget> categoryButtons = new ArrayList<>();

    public ItemPickerScreen(Screen parent, String title, Collection<String> initialSelection, Consumer<List<String>> onConfirm) {
        super(Text.literal(title));
        this.parent = parent;
        this.pickerTitle = title;
        if (initialSelection != null) {
            this.selectedIds.addAll(initialSelection);
        }
        this.onConfirm = onConfirm;
    }

    @Override
    protected void init() {
        super.init();

        ItemCatalogue.getInstance().ensureInitialized();

        gridX = 16;
        gridY = 72;
        gridW = this.width - 32;
        gridH = this.height - 108;

        // Search Bar at Top
        int searchW = Math.min(260, this.width - 160);
        int searchX = this.width / 2 - searchW / 2 - 40;
        searchField = new TextFieldWidget(this.textRenderer, searchX, 26, searchW, 18, Text.literal("Search"));
        searchField.setText(searchQuery);
        searchField.setPlaceholder(Text.literal("Search item by name or ID...").formatted(Formatting.DARK_GRAY));
        searchField.setChangedListener(query -> {
            this.searchQuery = query;
            this.scrollOffset = 0;
            updateFilter();
        });
        addDrawableChild(searchField);

        // Clear Search Button
        addDrawableChild(ButtonWidget.builder(Text.literal("✕"), btn -> {
            searchField.setText("");
            this.searchQuery = "";
            this.scrollOffset = 0;
            updateFilter();
        }).dimensions(searchX + searchW + 4, 26, 20, 18).build());

        // Quick Bulk Select Buttons
        addDrawableChild(ButtonWidget.builder(Text.literal("+ All Matching"), btn -> selectAllMatching())
                .dimensions(searchX + searchW + 28, 26, 75, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Deselect"), btn -> clearSelection())
                .dimensions(searchX + searchW + 107, 26, 55, 18).build());

        // Category Pills Row
        buildCategoryPills();

        // Footer Actions
        int confirmW = 160;
        int cancelW = 80;
        int footerY = this.height - 26;

        confirmButton = ButtonWidget.builder(getConfirmButtonText(), btn -> {
            if (onConfirm != null) {
                onConfirm.accept(new ArrayList<>(selectedIds));
            }
            if (this.client != null) {
                this.client.setScreen(parent);
            }
        }).dimensions(this.width / 2 - (confirmW + cancelW + 6) / 2, footerY, confirmW, 20).build();
        addDrawableChild(confirmButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), btn -> {
            if (this.client != null) {
                this.client.setScreen(parent);
            }
        }).dimensions(this.width / 2 - (confirmW + cancelW + 6) / 2 + confirmW + 6, footerY, cancelW, 20).build());

        updateFilter();
    }

    private void buildCategoryPills() {
        categoryButtons.clear();
        ItemCategory[] categories = ItemCategory.values();
        int pillH = 16;
        int pillY = 48;

        int totalPillsWidth = 0;
        int[] pillWidths = new int[categories.length];
        for (int i = 0; i < categories.length; i++) {
            pillWidths[i] = Math.max(38, this.textRenderer.getWidth(categories[i].getDisplayName()) + 10);
            totalPillsWidth += pillWidths[i] + 4;
        }

        int startX = Math.max(16, this.width / 2 - totalPillsWidth / 2);
        int curX = startX;

        for (int i = 0; i < categories.length; i++) {
            final ItemCategory cat = categories[i];
            int w = pillWidths[i];
            if (curX + w > this.width - 16) {
                break; // Screen width boundary protection
            }

            ButtonWidget pill = ButtonWidget.builder(cat.getText(), btn -> {
                this.activeCategory = cat;
                this.scrollOffset = 0;
                updateFilter();
                updateCategoryPillColors();
            }).dimensions(curX, pillY, w, pillH).build();

            addDrawableChild(pill);
            categoryButtons.add(pill);
            curX += w + 4;
        }
        updateCategoryPillColors();
    }

    private void updateCategoryPillColors() {
        for (int i = 0; i < categoryButtons.size(); i++) {
            ButtonWidget btn = categoryButtons.get(i);
            ItemCategory cat = ItemCategory.values()[i];
            boolean active = (cat == this.activeCategory);
            Formatting color = active ? Formatting.GREEN : Formatting.GRAY;
            btn.setMessage(Text.literal(cat.getDisplayName()).formatted(color));
        }
    }

    private void updateFilter() {
        this.filteredEntries = ItemCatalogue.getInstance().search(searchQuery, activeCategory, selectedIds);
        updateConfirmButton();
    }

    private void updateConfirmButton() {
        if (confirmButton != null) {
            confirmButton.setMessage(getConfirmButtonText());
        }
    }

    private Text getConfirmButtonText() {
        return Text.literal(String.format("Confirm (%d Selected)", selectedIds.size())).formatted(Formatting.GREEN, Formatting.BOLD);
    }

    private void selectAllMatching() {
        for (ItemCatalogueEntry entry : filteredEntries) {
            selectedIds.add(entry.getIdString());
        }
        updateConfirmButton();
    }

    private void clearSelection() {
        if (activeCategory == ItemCategory.SELECTED || activeCategory == ItemCategory.ALL) {
            selectedIds.clear();
        } else {
            for (ItemCatalogueEntry entry : filteredEntries) {
                selectedIds.remove(entry.getIdString());
            }
        }
        if (activeCategory == ItemCategory.SELECTED) {
            updateFilter();
        }
        updateConfirmButton();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Fully transparent background: do not draw solid blur or dimming
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Render Predictive Arc animated background layer
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance != null) {
            PredictiveArcRenderer.getInstance().render(
                    context, mouseX, mouseY, delta, this.width, this.height, clientInstance.getConfig());
        }

        // Header Title
        context.drawTextWithShadow(this.textRenderer, Text.literal(pickerTitle).formatted(Formatting.BOLD), 18, 12, COLOR_TEXT_MAIN);

        // Header Stats
        String stats = String.format("Showing %d items | %d selected", filteredEntries.size(), selectedIds.size());
        int statsX = this.width - this.textRenderer.getWidth(stats) - 18;
        context.drawTextWithShadow(this.textRenderer, Text.literal(stats), statsX, 12, COLOR_TEXT_SEC);

        // Grid Panel Background & Outline (Glass styling)
        context.fill(gridX, gridY, gridX + gridW, gridY + gridH, COLOR_PANEL);
        context.fill(gridX, gridY, gridX + gridW, gridY + 1, COLOR_BORDER);
        context.fill(gridX, gridY + gridH - 1, gridX + gridW, gridY + gridH, COLOR_BORDER);
        context.fill(gridX, gridY, gridX + 1, gridY + gridH, COLOR_BORDER);
        context.fill(gridX + gridW - 1, gridY, gridX + gridW, gridY + gridH, COLOR_BORDER);

        // Render Item Tiles & Identify Hovered Tile
        ItemCatalogueEntry hoveredEntry = renderItemTiles(context, mouseX, mouseY);

        // Render Scrollbar
        renderScrollbar(context);

        // Render UI widgets
        super.render(context, mouseX, mouseY, delta);

        // Render Tooltip for Hovered Tile (above widgets)
        if (hoveredEntry != null) {
            renderItemTooltip(context, hoveredEntry, mouseX, mouseY);
        }
    }

    private ItemCatalogueEntry renderItemTiles(DrawContext context, int mouseX, int mouseY) {
        if (filteredEntries.isEmpty()) {
            String emptyMsg = searchQuery.isEmpty()
                    ? (activeCategory == ItemCategory.SELECTED ? "No items currently selected." : "No items found in this category.")
                    : "No items matching '" + searchQuery + "' found.";
            context.drawTextWithShadow(this.textRenderer, Text.literal(emptyMsg).formatted(Formatting.GRAY),
                    gridX + gridW / 2 - this.textRenderer.getWidth(emptyMsg) / 2, gridY + gridH / 2 - 4, COLOR_TEXT_MUTED);
            return null;
        }

        int tileW = 118;
        int tileH = 22;
        int spacing = 3;

        int cols = Math.max(2, (gridW - 12) / (tileW + spacing));
        int totalColsWidth = cols * (tileW + spacing) - spacing;
        int startX = gridX + 6 + (gridW - 12 - totalColsWidth) / 2;

        int totalRows = (filteredEntries.size() + cols - 1) / cols;
        int totalContentHeight = totalRows * (tileH + spacing);
        this.maxScroll = Math.max(0, totalContentHeight - gridH + 8);

        int firstRow = Math.max(0, scrollOffset / (tileH + spacing));
        int visibleRowCount = (gridH / (tileH + spacing)) + 2;
        int lastRow = Math.min(totalRows, firstRow + visibleRowCount);

        ItemCatalogueEntry hovered = null;

        // Clip rendering to grid boundaries
        context.enableScissor(gridX + 1, gridY + 1, gridX + gridW - 1, gridY + gridH - 1);

        for (int row = firstRow; row < lastRow; row++) {
            for (int col = 0; col < cols; col++) {
                int index = (row * cols) + col;
                if (index >= filteredEntries.size()) break;

                ItemCatalogueEntry entry = filteredEntries.get(index);
                int x = startX + col * (tileW + spacing);
                int y = gridY + 4 + row * (tileH + spacing) - scrollOffset;

                boolean isSelected = selectedIds.contains(entry.getIdString());
                boolean isHovered = mouseX >= x && mouseX < x + tileW && mouseY >= y && mouseY < y + tileH
                        && mouseY >= gridY && mouseY < gridY + gridH;

                if (isHovered) {
                    hovered = entry;
                }

                // Tile Background
                int bgCol = isSelected ? COLOR_CARD_SELECTED : (isHovered ? COLOR_CARD_HOVER : COLOR_CARD);
                int borderCol = isSelected ? COLOR_BORDER_SELECTED : (isHovered ? COLOR_BORDER_HOVER : COLOR_BORDER);

                context.fill(x, y, x + tileW, y + tileH, bgCol);
                context.fill(x, y, x + tileW, y + 1, borderCol);
                context.fill(x, y + tileH - 1, x + tileW, y + tileH, borderCol);
                context.fill(x, y, x + 1, y + tileH, borderCol);
                context.fill(x + tileW - 1, y, x + tileW, y + tileH, borderCol);

                // Render Item Icon
                context.drawItem(entry.getStack(), x + 3, y + 3);

                // Render Readable Name
                String trimmedName = this.textRenderer.trimToWidth(entry.getDisplayName(), tileW - 28);
                int nameColor = isSelected ? 0xFF58A6FF : (isHovered ? 0xFFFFFFFF : COLOR_TEXT_MAIN);
                context.drawTextWithShadow(this.textRenderer, Text.literal(trimmedName), x + 23, y + 7, nameColor);

                // Selected Checkmark Badge
                if (isSelected) {
                    context.drawTextWithShadow(this.textRenderer, Text.literal("✓").formatted(Formatting.GREEN), x + tileW - 10, y + 2, 0xFF3FB950);
                }
            }
        }

        context.disableScissor();
        return hovered;
    }

    private void renderScrollbar(DrawContext context) {
        if (maxScroll <= 0) return;

        int barX = gridX + gridW - 5;
        int barW = 3;
        int barH = Math.max(16, (int) ((float) gridH / (gridH + maxScroll) * gridH));
        int barY = gridY + (int) ((float) scrollOffset / maxScroll * (gridH - barH));

        context.fill(barX, gridY + 2, barX + barW, gridY + gridH - 2, 0x401E2638);
        context.fill(barX, barY, barX + barW, barY + barH, isScrolling ? 0xFF388BFD : 0xFF2A344A);
    }

    private void renderItemTooltip(DrawContext context, ItemCatalogueEntry entry, int mouseX, int mouseY) {
        List<Text> tooltip = new ArrayList<>();
        tooltip.add(Text.literal(entry.getDisplayName()).formatted(Formatting.WHITE, Formatting.BOLD));
        tooltip.add(Text.literal("§7ID: §f" + entry.getIdString()));
        tooltip.add(Text.literal("§7Mod: §e" + entry.getModName() + " §8(" + entry.getModId() + ")"));
        tooltip.add(Text.literal("§7Category: §b" + entry.getCategory().getDisplayName()));

        boolean isSelected = selectedIds.contains(entry.getIdString());
        tooltip.add(Text.literal(isSelected ? "§a✓ Selected §8(Click to remove)" : "§7Click to select"));

        context.drawTooltip(this.textRenderer, tooltip, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(Click click, boolean bl) {
        if (click.button() == 0) {
            double mouseX = click.x();
            double mouseY = click.y();

            // Check scrollbar click
            int barX = gridX + gridW - 8;
            if (mouseX >= barX && mouseX <= gridX + gridW && mouseY >= gridY && mouseY <= gridY + gridH) {
                isScrolling = true;
                return true;
            }

            // Check tile click
            if (mouseX >= gridX && mouseX < gridX + gridW - 8 && mouseY >= gridY && mouseY < gridY + gridH) {
                int tileW = 118;
                int tileH = 22;
                int spacing = 3;

                int cols = Math.max(2, (gridW - 12) / (tileW + spacing));
                int totalColsWidth = cols * (tileW + spacing) - spacing;
                int startX = gridX + 6 + (gridW - 12 - totalColsWidth) / 2;

                int relativeY = (int) (mouseY - gridY - 4 + scrollOffset);
                int relativeX = (int) (mouseX - startX);

                if (relativeX >= 0 && relativeY >= 0) {
                    int col = relativeX / (tileW + spacing);
                    int row = relativeY / (tileH + spacing);

                    int inTileX = relativeX % (tileW + spacing);
                    int inTileY = relativeY % (tileH + spacing);

                    if (col < cols && inTileX <= tileW && inTileY <= tileH) {
                        int index = row * cols + col;
                        if (index >= 0 && index < filteredEntries.size()) {
                            ItemCatalogueEntry clicked = filteredEntries.get(index);
                            String id = clicked.getIdString();
                            if (selectedIds.contains(id)) {
                                selectedIds.remove(id);
                            } else {
                                selectedIds.add(id);
                            }
                            updateConfirmButton();

                            if (activeCategory == ItemCategory.SELECTED) {
                                updateFilter();
                            }
                            return true;
                        }
                    }
                }
            }
        }
        return super.mouseClicked(click, bl);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (click.button() == 0) {
            isScrolling = false;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        if (isScrolling && maxScroll > 0) {
            float relativeY = (float) (click.y() - gridY) / gridH;
            scrollOffset = (int) (relativeY * maxScroll);
            scrollOffset = MathHelper.clamp(scrollOffset, 0, maxScroll);
            return true;
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (maxScroll > 0) {
            scrollOffset -= (int) (verticalAmount * 24.0);
            scrollOffset = MathHelper.clamp(scrollOffset, 0, maxScroll);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput keyInput) {
        if (keyInput.key() == GLFW.GLFW_KEY_ESCAPE) { // ESC key returns to parent
            if (this.client != null) {
                this.client.setScreen(parent);
            }
            return true;
        }
        return super.keyPressed(keyInput);
    }

    @Override
    public void close() {
        PredictiveArcRenderer.getInstance().reset();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
