package com.refillminerpro.client.gui.picker;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

/**
 * Cached metadata for a single item in the visual picker catalogue.
 */
public class ItemCatalogueEntry {
    private final Identifier id;
    private final String idString;
    private final String idStringLower;
    private final String displayName;
    private final String displayNameLower;
    private final String modName;
    private final String modNameLower;
    private final String modId;
    private final String modIdLower;
    private final Item item;
    private ItemStack stack;
    private final ItemCategory category;

    public ItemCatalogueEntry(Identifier id, Item item, String displayName, String modName, String modId, ItemCategory category) {
        this.id = id;
        this.idString = id != null ? id.toString() : "";
        this.idStringLower = this.idString.toLowerCase();
        this.displayName = displayName != null ? displayName : "";
        this.displayNameLower = this.displayName.toLowerCase();
        this.modName = modName != null ? modName : "";
        this.modNameLower = this.modName.toLowerCase();
        this.modId = modId != null ? modId : "";
        this.modIdLower = this.modId.toLowerCase();
        this.item = item;
        this.category = category != null ? category : ItemCategory.BUILDING;
    }

    public Identifier getId() {
        return id;
    }

    public String getIdString() {
        return idString;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDisplayNameLower() {
        return displayNameLower;
    }

    public String getModName() {
        return modName;
    }

    public String getModId() {
        return modId;
    }

    public Item getItem() {
        return item;
    }

    public ItemCategory getCategory() {
        return category;
    }

    public ItemStack getStack() {
        if (stack == null && item != null) {
            try {
                stack = new ItemStack(item);
            } catch (Throwable ignored) {}
        }
        return stack;
    }

    public boolean isModded() {
        return !modId.equals("minecraft");
    }

    public boolean matchesSearch(String query) {
        if (query == null || query.isEmpty()) {
            return true;
        }
        String q = query.toLowerCase();
        return displayNameLower.contains(q)
                || idStringLower.contains(q)
                || modNameLower.contains(q)
                || modIdLower.contains(q);
    }

    public boolean matchesCategory(ItemCategory cat, boolean isSelected) {
        if (cat == null || cat == ItemCategory.ALL) {
            return true;
        }
        if (cat == ItemCategory.SELECTED) {
            return isSelected;
        }
        if (cat == ItemCategory.MODDED) {
            return isModded();
        }
        return this.category == cat;
    }
}
