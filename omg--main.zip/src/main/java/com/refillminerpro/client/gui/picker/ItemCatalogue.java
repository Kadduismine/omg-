package com.refillminerpro.client.gui.picker;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * High-performance, dynamically discovered item catalogue for Refill Miner Pro.
 * Scans the active Minecraft item registry, caches items, and provides instant searching.
 */
public class ItemCatalogue {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/ItemCatalogue");
    private static ItemCatalogue instance;

    private final List<ItemCatalogueEntry> entries = new ArrayList<>();
    private final Map<String, ItemCatalogueEntry> entryMap = new ConcurrentHashMap<>();
    private final Map<String, String> modNames = new ConcurrentHashMap<>();

    private boolean initialized = false;

    public static synchronized ItemCatalogue getInstance() {
        if (instance == null) {
            instance = new ItemCatalogue();
        }
        return instance;
    }

    public synchronized void ensureInitialized() {
        if (initialized && !entries.isEmpty()) {
            return;
        }
        rebuildCatalogue();
    }

    public synchronized void rebuildCatalogue() {
        entries.clear();
        entryMap.clear();

        try {
            if (Registries.ITEM == null) {
                LOGGER.warn("Registries.ITEM is not yet available.");
                return;
            }

            // Pre-cache known mod names
            cacheModNames();

            Set<Identifier> ids = Registries.ITEM.getIds();
            for (Identifier id : ids) {
                if (id == null) continue;

                Item item = Registries.ITEM.get(id);
                if (item == null || item == Items.AIR) {
                    continue;
                }

                String modId = id.getNamespace();
                String modName = modNames.computeIfAbsent(modId, this::resolveModName);

                ItemStack stack = new ItemStack(item);
                String displayName = stack.getName().getString();
                if (displayName == null || displayName.trim().isEmpty()) {
                    displayName = formatIdToName(id.getPath());
                }

                ItemCategory category = classify(id, item, stack);

                ItemCatalogueEntry entry = new ItemCatalogueEntry(id, item, displayName, modName, modId, category);
                entries.add(entry);
                entryMap.put(entry.getIdString(), entry);
            }

            // Sort catalogue alphabetically by display name
            entries.sort(Comparator.comparing(ItemCatalogueEntry::getDisplayName, String.CASE_INSENSITIVE_ORDER));

            initialized = true;
            LOGGER.info("Item Catalogue initialized with {} registered items ({} mods).", entries.size(), modNames.size());
        } catch (Throwable t) {
            LOGGER.error("Failed to build item catalogue from active registry.", t);
        }
    }

    private void cacheModNames() {
        modNames.put("minecraft", "Minecraft");
        try {
            if (FabricLoader.getInstance() != null) {
                for (ModContainer mod : FabricLoader.getInstance().getAllMods()) {
                    String id = mod.getMetadata().getId();
                    String name = mod.getMetadata().getName();
                    if (id != null && name != null) {
                        modNames.put(id, name);
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private String resolveModName(String modId) {
        if (modId == null || modId.isEmpty()) return "Unknown";
        if (modId.equals("minecraft")) return "Minecraft";
        String cached = modNames.get(modId);
        if (cached != null) return cached;
        return formatIdToName(modId);
    }

    private static String formatIdToName(String id) {
        if (id == null || id.isEmpty()) return "";
        String[] parts = id.replace('_', ' ').split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(Character.toUpperCase(part.charAt(0)));
                if (part.length() > 1) {
                    sb.append(part.substring(1).toLowerCase());
                }
            }
        }
        return sb.toString();
    }

    public List<ItemCatalogueEntry> getEntries() {
        ensureInitialized();
        return entries;
    }

    public ItemCatalogueEntry getEntry(String idString) {
        if (idString == null) return null;
        ensureInitialized();
        return entryMap.get(idString);
    }

    /**
     * Resolves an ItemStack for a registry ID string.
     * Handles modded items and missing/removed mod items safely without crashing.
     */
    public ItemStack getStack(String idString) {
        if (idString == null || idString.isEmpty()) {
            return ItemStack.EMPTY;
        }
        ItemCatalogueEntry entry = getEntry(idString);
        if (entry != null) {
            return entry.getStack();
        }

        // Try direct lookup in registry
        try {
            Identifier id = Identifier.tryParse(idString);
            if (id != null && Registries.ITEM != null && Registries.ITEM.containsId(id)) {
                Item item = Registries.ITEM.get(id);
                if (item != null && item != Items.AIR) {
                    return new ItemStack(item);
                }
            }
        } catch (Throwable ignored) {}

        return new ItemStack(Items.BARRIER);
    }

    /**
     * Resolves a readable display name for a registry ID string.
     * Preserves unknown/unregistered items safely so configuration is never lost.
     */
    public String getDisplayName(String idString) {
        if (idString == null || idString.isEmpty()) {
            return "Empty";
        }
        ItemCatalogueEntry entry = getEntry(idString);
        if (entry != null) {
            return entry.getDisplayName();
        }

        try {
            Identifier id = Identifier.tryParse(idString);
            if (id != null && Registries.ITEM != null && Registries.ITEM.containsId(id)) {
                Item item = Registries.ITEM.get(id);
                if (item != null && item != Items.AIR) {
                    return new ItemStack(item).getName().getString();
                }
            }
        } catch (Throwable ignored) {}

        // Fallback: format raw id safely
        return idString;
    }

    /**
     * Filters catalogue by search query and category.
     */
    public List<ItemCatalogueEntry> search(String query, ItemCategory category, Set<String> selectedIds) {
        ensureInitialized();

        String queryLower = query != null ? query.trim().toLowerCase() : "";
        boolean filterQuery = !queryLower.isEmpty();
        boolean filterCat = category != null && category != ItemCategory.ALL;

        List<ItemCatalogueEntry> results = new ArrayList<>();
        for (ItemCatalogueEntry entry : entries) {
            boolean isSelected = selectedIds != null && selectedIds.contains(entry.getIdString());

            if (filterCat && !entry.matchesCategory(category, isSelected)) {
                continue;
            }

            if (filterQuery && !entry.matchesSearch(queryLower)) {
                continue;
            }

            results.add(entry);
        }
        return results;
    }

    /**
     * Classifies an item into a suitable browsing category.
     */
    public static ItemCategory classify(Identifier id, Item item, ItemStack stack) {
        if (id == null) return ItemCategory.BUILDING;
        String path = id.getPath();

        // 1. Food
        if (path.contains("meat") || path.contains("beef") || path.contains("pork") || path.contains("chicken")
                || path.contains("mutton") || path.contains("fish") || path.contains("salmon") || path.contains("apple")
                || path.contains("bread") || path.contains("carrot") || path.contains("potato") || path.contains("stew")
                || path.contains("soup") || path.contains("cookie") || path.contains("pie") || path.contains("berry")
                || path.contains("berries") || path.contains("melon") || path.contains("cake") || path.contains("potion")) {
            return ItemCategory.FOOD;
        }

        // 2. Combat
        if (path.endsWith("_sword") || path.contains("bow") || path.contains("crossbow") || path.contains("arrow")
                || path.contains("shield") || path.contains("helmet") || path.contains("chestplate") || path.contains("leggings")
                || path.contains("boots") || path.contains("trident") || path.contains("mace")) {
            return ItemCategory.COMBAT;
        }

        // 3. Tools
        if (path.endsWith("_pickaxe") || path.endsWith("_axe") || path.endsWith("_shovel") || path.endsWith("_hoe")
                || path.contains("shears") || path.contains("fishing_rod") || path.contains("flint_and_steel")
                || path.contains("compass") || path.contains("clock") || path.contains("spyglass") || path.contains("lead")) {
            return ItemCategory.TOOLS;
        }

        // 4. Redstone
        if (path.contains("redstone") || path.contains("repeater") || path.contains("comparator") || path.contains("piston")
                || path.contains("observer") || path.contains("lever") || path.contains("button") || path.contains("pressure_plate")
                || path.contains("dispenser") || path.contains("dropper") || path.contains("hopper") || path.contains("rail")
                || path.contains("target") || path.contains("sensor") || path.contains("tripwire") || path.contains("tnt")) {
            return ItemCategory.REDSTONE;
        }

        // 5. Functional
        if (path.contains("chest") || path.contains("shulker") || path.contains("furnace") || path.contains("smoker")
                || path.contains("blast_furnace") || path.contains("barrel") || path.contains("crafting_table")
                || path.contains("anvil") || path.contains("enchanting_table") || path.contains("brewing_stand")
                || path.contains("bed") || path.contains("torch") || path.contains("lantern") || path.contains("campire")
                || path.contains("candle") || path.contains("spawner") || path.contains("door") || path.contains("trapdoor")
                || path.contains("ladder") || path.contains("scaffolding") || path.contains("sign")) {
            return ItemCategory.FUNCTIONAL;
        }

        // 6. Natural
        if (path.contains("ore") || path.contains("dirt") || path.contains("grass") || path.contains("sand")
                || path.contains("gravel") || path.contains("log") || path.contains("leaves") || path.contains("stone")
                || path.contains("deepslate") || path.contains("granite") || path.contains("diorite") || path.contains("andesite")
                || path.contains("tuff") || path.contains("calcite") || path.contains("dripstone") || path.contains("obsidian")
                || path.contains("ice") || path.contains("snow") || path.contains("flower") || path.contains("sapling")
                || path.contains("seed") || path.contains("coral") || path.contains("sponge") || path.contains("netherrack")
                || path.contains("basalt") || path.contains("blackstone") || path.contains("end_stone")) {
            return ItemCategory.NATURAL;
        }

        // 7. Ingredients
        if (path.contains("ingot") || path.contains("nugget") || path.contains("raw_") || path.contains("diamond")
                || path.contains("emerald") || path.contains("lapis") || path.contains("amethyst") || path.contains("coal")
                || path.contains("charcoal") || path.contains("stick") || path.contains("string") || path.contains("feather")
                || path.contains("leather") || path.contains("bone") || path.contains("dust") || path.contains("shard")
                || path.contains("scrap") || path.contains("dye") || path.contains("slime_ball") || path.contains("clay_ball")) {
            return ItemCategory.INGREDIENTS;
        }

        // 8. Building
        return ItemCategory.BUILDING;
    }
}

