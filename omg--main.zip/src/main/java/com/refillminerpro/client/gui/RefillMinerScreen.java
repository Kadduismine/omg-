package com.refillminerpro.client.gui;

import com.refillminerpro.client.RefillMinerClient;
import com.refillminerpro.client.gui.picker.ItemCatalogue;
import com.refillminerpro.client.gui.picker.ItemPickerScreen;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.RecoveryMode;
import com.refillminerpro.config.SavedAreaProfile;
import com.refillminerpro.config.ServerIdentifier;
import com.refillminerpro.client.gui.arc.ArcColorPreset;
import com.refillminerpro.client.gui.arc.PredictiveArcRenderer;
import com.refillminerpro.diagnostics.LocalDiagnosticsManager;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.MiningStatus;
import com.refillminerpro.region.BlockRegion;
import com.refillminerpro.region.SelectionManager;
import com.refillminerpro.storage.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Native Minecraft Settings & Area Management Screen for Refill Miner Pro.
 * Structured with a distinct three-level header:
 * - Row A: Application Title & Connection Status
 * - Row B: Environment Information (SERVER & DIMENSION)
 * - Row C: Persistent Navigation Tabs (Always visible, never clipped)
 *
 * Scissored content viewport with independent vertical scrolling,
 * and a fixed footer with [Done] and contextual [Reset].
 */
public class RefillMinerScreen extends Screen {

    // Palette Constants (Transparent Glass Styling with Luminous Accents)
    public static final int COLOR_GLASS_PANEL = 0x160D111A;  // ~9% dark glass tint allowing live world visibility
    public static final int COLOR_GLASS_CARD = 0x2211151D;   // ~13% dark glass tint for cards
    public static final int COLOR_GLASS_HOVER = 0x3E1E2430;  // ~24% hover tint
    public static final int COLOR_GLASS_BORDER = 0x388498FF; // Subtle accent glass outline
    public static final int COLOR_GLASS_LINE = 0x2E293141;   // Translucent divider line
    public static final int COLOR_BORDER = 0x388498FF;
    public static final int COLOR_ELEVATED = 0x26171C26;
    public static final int COLOR_HOVER = 0x441E2430;
    public static final int COLOR_PANEL = 0x1E11151D;
    public static final int COLOR_TEXT_MAIN = 0xFFF1F4FA;
    public static final int COLOR_TEXT_SEC = 0xFFA0A9B9;
    public static final int COLOR_TEXT_MUTED = 0xFF727D90;
    public static final int COLOR_ACCENT = 0xFF8498FF;
    public static final int COLOR_SUCCESS = 0xFF55B88A;
    public static final int COLOR_WARNING = 0xFFE8B567;
    public static final int COLOR_ERROR = 0xFFE5767F;

    public static final String[] TAB_NAMES = {
            "General",
            "Auto Store",
            "Vaults",
            "Selection",
            "Saved Areas",
            "Mining",
            "Item Rules",
            "Activity",
            "Settings"
    };

    private static int activeTab = 0;
    private static int tabScrollIndex = 0;

    private final Screen parent;
    private final RefillMinerClient clientInstance;
    private final ModConfig config;
    private final AutoStorageConfig storageConfig;
    private final SelectionManager selection;
    private final MiningEngine engine;
    private final AutoStorageEngine storageEngine;

    // Layout Calculations
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    // Header Levels
    private int headerRowAY;
    private int headerRowBY;
    private int headerRowCY;
    private int tabBarH = 20;

    // Content Viewport
    private int contentX;
    private int contentY;
    private int contentW;
    private int contentH;

    // Footer
    private int footerY;

    // Content Scrolling
    private int scrollY = 0;
    private int maxScroll = 0;

    // Tab hitboxes for mouse interaction
    private final List<TabHitbox> tabHitboxes = new ArrayList<>();
    private boolean hasTabOverflow = false;
    private int leftArrowX, rightArrowX;

    // Tracking content widgets
    private final List<PositionedWidget> contentWidgets = new ArrayList<>();
    private ButtonWidget doneButton;
    private ButtonWidget resetButton;

    // Interactive State
    private String confirmDeleteId = null;
    private TextFieldWidget newAreaNameField = null;
    private String statusMessage = null;
    private Formatting statusColor = Formatting.WHITE;
    private String serverHoverTooltip = null;

    // Vault fields
    private final List<TextFieldWidget> vaultCommandFields = new ArrayList<>();
    private final List<TextFieldWidget> vaultNameFields = new ArrayList<>();

    private record TabHitbox(int index, int x, int y, int width, int height) {}
    private record PositionedWidget(ClickableWidget widget, int relY) {}

    public RefillMinerScreen(Screen parent) {
        super(Text.literal("Refill Miner Pro"));
        this.parent = parent;
        this.clientInstance = RefillMinerClient.getInstance();
        this.config = clientInstance.getConfig();
        this.storageConfig = config.getAutoStorage();
        this.selection = clientInstance.getSelectionManager();
        this.engine = clientInstance.getMiningEngine();
        this.storageEngine = clientInstance.getAutoStorageEngine();
    }

    @Override
    protected void init() {
        super.init();
        computeLayout();
        buildUI();
    }

    private void computeLayout() {
        // Responsive panel bounds adapted to GUI scale and screen resolution
        this.panelWidth = MathHelper.clamp(this.width - 24, 400, 520);
        this.panelHeight = MathHelper.clamp(this.height - 18, 250, 330);

        this.panelX = (this.width - this.panelWidth) / 2;
        this.panelY = (this.height - this.panelHeight) / 2;

        // Distinct Three-Level Header Layout
        this.headerRowAY = panelY + 6;   // Row A: App Title & Connection Status (height 14)
        this.headerRowBY = panelY + 21;  // Row B: Environment Row: SERVER & DIMENSION (height 14)
        this.headerRowCY = panelY + 37;  // Row C: Persistent Navigation Tabs (height 20)

        // Content Viewport strictly below the navigation tab bar
        this.contentX = panelX + 8;
        this.contentY = headerRowCY + tabBarH + 3; // Starts at panelY + 60
        this.footerY = panelY + panelHeight - 22;  // Fixed footer at bottom
        this.contentW = panelWidth - 16;
        this.contentH = footerY - contentY - 3;
    }

    private void buildUI() {
        this.clearChildren();
        this.contentWidgets.clear();
        this.vaultCommandFields.clear();
        this.vaultNameFields.clear();
        this.tabHitboxes.clear();

        // 1. Calculate Tab Bar Hitboxes (Row C)
        int tabY = headerRowCY;
        int usableTabWidth = panelWidth - 16;

        int[] naturalWidths = new int[TAB_NAMES.length];
        int totalTabsWidth = 0;
        for (int i = 0; i < TAB_NAMES.length; i++) {
            naturalWidths[i] = this.textRenderer.getWidth(TAB_NAMES[i]) + 10;
            totalTabsWidth += naturalWidths[i];
        }

        this.hasTabOverflow = totalTabsWidth > usableTabWidth;
        int arrowW = 12;

        if (!hasTabOverflow) {
            // Distribute evenly across tab bar
            int tabW = usableTabWidth / TAB_NAMES.length;
            int rem = usableTabWidth % TAB_NAMES.length;
            int currentX = panelX + 8;
            for (int i = 0; i < TAB_NAMES.length; i++) {
                int w = tabW + (i < rem ? 1 : 0);
                tabHitboxes.add(new TabHitbox(i, currentX, tabY, w, tabBarH));
                currentX += w;
            }
        } else {
            // Tab Strip with < and > overflow navigation
            this.leftArrowX = panelX + 8;
            this.rightArrowX = panelX + panelWidth - 8 - arrowW;
            int currentX = leftArrowX + arrowW + 2;
            int availableW = rightArrowX - currentX - 2;

            int remaining = availableW;
            for (int i = tabScrollIndex; i < TAB_NAMES.length; i++) {
                int w = naturalWidths[i];
                if (remaining < w && i > tabScrollIndex) {
                    break;
                }
                tabHitboxes.add(new TabHitbox(i, currentX, tabY, w, tabBarH));
                currentX += w;
                remaining -= w;
            }
        }

        // 2. Build Content Widgets for the Active Tab (relative coordinates)
        int estimatedContentH = 0;
        switch (activeTab) {
            case 0 -> estimatedContentH = buildGeneralTab();
            case 1 -> estimatedContentH = buildAutoStoreTab();
            case 2 -> estimatedContentH = buildVaultsTab();
            case 3 -> estimatedContentH = buildSelectionTab();
            case 4 -> estimatedContentH = buildSavedAreasTab();
            case 5 -> estimatedContentH = buildMiningTab();
            case 6 -> estimatedContentH = buildItemRulesTab();
            case 7 -> estimatedContentH = buildActivityTab();
            case 8 -> estimatedContentH = buildSettingsTab();
        }

        this.maxScroll = Math.max(0, estimatedContentH - contentH + 8);
        this.scrollY = MathHelper.clamp(this.scrollY, 0, this.maxScroll);

        // Update positions and visibility of content widgets
        updateContentWidgetPositions();

        // 3. Fixed Footer Buttons
        int btnH = 16;
        doneButton = ButtonWidget.builder(
                Text.literal("Done"),
                btn -> this.close()
        ).dimensions(panelX + 8, footerY, 65, btnH).build();
        addDrawableChild(doneButton);

        String resetLabel = (activeTab == 3) ? "Reset Sel" : (activeTab == 1 || activeTab == 2) ? "Reset Store" : "Reset";
        resetButton = ButtonWidget.builder(
                Text.literal(resetLabel).formatted(Formatting.GRAY),
                btn -> handleContextualReset()
        ).dimensions(panelX + panelWidth - 73, footerY, 65, btnH).build();
        addDrawableChild(resetButton);
    }

    private void addContentWidget(ClickableWidget widget, int relY) {
        contentWidgets.add(new PositionedWidget(widget, relY));
        addDrawableChild(widget);
    }

    private void updateContentWidgetPositions() {
        for (PositionedWidget pw : contentWidgets) {
            int actualY = contentY + pw.relY - scrollY;
            pw.widget.setY(actualY);
            // Hide widget if it is outside content viewport to prevent click leaks
            boolean inViewport = (actualY + pw.widget.getHeight() >= contentY) && (actualY <= contentY + contentH);
            pw.widget.visible = inViewport;
        }
    }

    // =========================================================================
    // TAB 0: GENERAL
    // =========================================================================
    private int buildGeneralTab() {
        int relY = 4;
        int rowH = 18;
        int w = contentW - 14;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Auto Mine Active", config.isAutoMineEnabled(), val -> {
            clientInstance.setAutoMineEnabled(val);
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Enforce Area Boundary (Restricted to Selection)", config.isEnforceAreaBoundary(), val -> {
            config.setEnforceAreaBoundary(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Pause Mining Assistance", config.isPaused(), val -> {
            clientInstance.togglePause();
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Selection Mode (Punch C1, Use C2)", selection.isSelectionModeActive(), val -> {
            selection.setSelectionModeActive(val);
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Restore Last Area on Join", config.isRestoreLastAreaOnJoin(), val -> {
            config.setRestoreLastAreaOnJoin(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Show HUD Overlay", config.isHudVisible(), val -> {
            config.setHudVisible(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Render Area Wireframe", config.isOutlineVisible(), val -> {
            config.setOutlineVisible(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += rowH;

        addCompactCheckboxWidget(contentX + 4, relY, w, "Debug Diagnostic Mode", config.isDebugMode(), val -> {
            config.setDebugMode(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += rowH + 44; // Room for status card

        return relY;
    }

    // =========================================================================
    // TAB 1: AUTO STORE
    // =========================================================================
    private int buildAutoStoreTab() {
        int relY = 4;
        int btnH = 18;
        int w = contentW - 14;
        int halfW = (w - 6) / 2;

        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Auto Storage System", storageConfig.isEnabled(), val -> {
            storageConfig.setEnabled(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Auto Store Pause", storageConfig.isPaused(), val -> {
            storageConfig.setPaused(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 20;

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Trigger Capacity: %d%%", storageConfig.getCapacityThresholdPercent())),
                btn -> {
                    int cur = storageConfig.getCapacityThresholdPercent();
                    int next = (cur == 75) ? 85 : (cur == 85) ? 90 : (cur == 90) ? 95 : (cur == 95) ? 100 : 75;
                    storageConfig.setCapacityThresholdPercent(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(Text.literal(String.format("Trigger Capacity: %d%%", next)));
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Min Free Slots: %d", storageConfig.getMinFreeSlots())),
                btn -> {
                    int next = (storageConfig.getMinFreeSlots() + 1) % 6;
                    storageConfig.setMinFreeSlots(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(Text.literal(String.format("Min Free Slots: %d", next)));
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Trigger Delay: %.1fs", storageConfig.getTriggerDelayTicks() / 20.0)),
                btn -> {
                    int cur = storageConfig.getTriggerDelayTicks();
                    int next = (cur == 0) ? 10 : (cur == 10) ? 20 : (cur == 20) ? 40 : 0;
                    storageConfig.setTriggerDelayTicks(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(Text.literal(String.format("Trigger Delay: %.1fs", next / 20.0)));
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                getTransferSpeedButtonText(),
                btn -> {
                    int cur = storageConfig.getTransferDelayTicks();
                    int next = (cur <= 1) ? 2 : (cur == 2) ? 4 : 1;
                    storageConfig.setTransferDelayTicks(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(getTransferSpeedButtonText());
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Pause On Containers", storageConfig.isPauseOnContainers(), val -> {
            storageConfig.setPauseOnContainers(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Trigger At 100% Full", storageConfig.isTriggerOnCompletelyFull(), val -> {
            storageConfig.setTriggerOnCompletelyFull(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 20;

        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Resume Mining Auto", storageConfig.isResumeMiningAutomatically(), val -> {
            storageConfig.setResumeMiningAutomatically(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Completion Title/Msg", storageConfig.isCompletionNotification(), val -> {
            storageConfig.setCompletionNotification(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 20;

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("First Vault: Vault %d", storageConfig.getFirstVault())),
                btn -> {
                    int next = (storageConfig.getFirstVault() % 7) + 1;
                    storageConfig.setFirstVault(next);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Last Vault: Vault %d", storageConfig.getLastVault())),
                btn -> {
                    int first = storageConfig.getFirstVault();
                    int cur = storageConfig.getLastVault();
                    int next = (cur >= 7) ? first : (cur + 1);
                    storageConfig.setLastVault(next);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Eligible Stored Items (%d)", storageConfig.getStoredItems().size())).formatted(Formatting.AQUA),
                btn -> {
                    if (this.client != null) {
                        this.client.setScreen(new ItemPickerScreen(this, "Auto Store: Stored Items", storageConfig.getStoredItems(), items -> {
                            storageConfig.setStoredItems(items);
                            clientInstance.getConfigManager().save();
                            buildUI();
                        }));
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Protected Items (%d)", storageConfig.getProtectedItems().size())).formatted(Formatting.GOLD),
                btn -> {
                    if (this.client != null) {
                        this.client.setScreen(new ItemPickerScreen(this, "Auto Store: Protected Items", storageConfig.getProtectedItems(), items -> {
                            storageConfig.setProtectedItems(items);
                            clientInstance.getConfigManager().save();
                            buildUI();
                        }));
                    }
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        addContentWidget(ButtonWidget.builder(
                Text.literal("⚡ Instant Auto Store Now (Deposit Hotbar/Inv)").formatted(Formatting.GREEN),
                btn -> {
                    if (this.client != null) {
                        storageEngine.startStorageWorkflow(this.client);
                        statusMessage = "Started Auto Store workflow!";
                        statusColor = Formatting.GREEN;
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        relY += btnH + 4;

        addContentWidget(ButtonWidget.builder(
                Text.literal("🛑 Emergency Stop (Mining, Walk & Storage)").formatted(Formatting.RED),
                btn -> {
                    clientInstance.getConfig().setAutoMineEnabled(false);
                    clientInstance.getMiningEngine().cancelCurrentMining(this.client);
                    clientInstance.getMiningEngine().stopWalking(this.client);
                    clientInstance.getMiningEngine().stopAttacking(this.client);
                    clientInstance.getMiningEngine().getRotationController().clearTarget();
                    if (storageEngine != null) {
                        storageEngine.reset();
                    }
                    clientInstance.getConfigManager().save();
                    statusMessage = "Emergency stop activated!";
                    statusColor = Formatting.RED;
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        relY += btnH + 48; // Room for capacity progress bar card

        return relY;
    }

    // =========================================================================
    // TAB 2: VAULTS (All 7 Vault Slots)
    // =========================================================================
    private int buildVaultsTab() {
        int relY = 4;
        int btnH = 17;
        int w = contentW - 14;
        int halfW = (w - 6) / 2;

        addContentWidget(CyclingButtonWidget.<VaultRoutingMode>builder(VaultRoutingMode::getText, storageConfig::getRoutingMode)
                .values(VaultRoutingMode.values())
                .build(contentX + 4, contentY + relY, halfW, btnH,
                        Text.literal("Routing"),
                        (button, value) -> {
                            storageConfig.setRoutingMode(value);
                            clientInstance.getConfigManager().save();
                        }
                ), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Preferred: Vault %d", storageConfig.getPreferredVaultIndex() + 1)),
                btn -> {
                    int next = (storageConfig.getPreferredVaultIndex() + 1) % 7;
                    storageConfig.setPreferredVaultIndex(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(Text.literal(String.format("Preferred: Vault %d", next + 1)));
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("First Vault: Vault %d", storageConfig.getFirstVault())),
                btn -> {
                    int next = (storageConfig.getFirstVault() % 7) + 1;
                    storageConfig.setFirstVault(next);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Last Vault: Vault %d", storageConfig.getLastVault())),
                btn -> {
                    int first = storageConfig.getFirstVault();
                    int cur = storageConfig.getLastVault();
                    int next = (cur >= 7) ? first : (cur + 1);
                    storageConfig.setLastVault(next);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 16; // Room for column labels

        List<VaultSlotConfig> slots = storageConfig.getVaultSlots();
        for (int i = 0; i < Math.min(7, slots.size()); i++) {
            final int vaultIdx = i;
            VaultSlotConfig slot = slots.get(i);

            TextFieldWidget nameField = new TextFieldWidget(this.textRenderer, contentX + 4, contentY + relY, 76, 15, Text.literal("Name"));
            nameField.setText(slot.getDisplayName());
            nameField.setChangedListener(slot::setDisplayName);
            addContentWidget(nameField, relY);
            vaultNameFields.add(nameField);

            TextFieldWidget cmdField = new TextFieldWidget(this.textRenderer, contentX + 83, contentY + relY, 76, 15, Text.literal("Cmd"));
            cmdField.setText(slot.getCommand());
            cmdField.setChangedListener(slot::setCommand);
            addContentWidget(cmdField, relY);
            vaultCommandFields.add(cmdField);

            addContentWidget(ButtonWidget.builder(
                    Text.literal(slot.isEnabled() ? "ON" : "OFF").formatted(slot.isEnabled() ? Formatting.GREEN : Formatting.RED),
                    btn -> {
                        slot.setEnabled(!slot.isEnabled());
                        buildUI();
                    }
            ).dimensions(contentX + 162, contentY + relY, 28, 15).build(), relY);

            int count = slot.getAssignedItemIds() != null ? slot.getAssignedItemIds().size() : 0;
            addContentWidget(ButtonWidget.builder(
                    Text.literal(count > 0 ? ("Items (" + count + ")") : "Items").formatted(count > 0 ? Formatting.AQUA : Formatting.GRAY),
                    btn -> {
                        if (this.client != null) {
                            this.client.setScreen(new ItemPickerScreen(this, slot.getDisplayName() + " Items", slot.getAssignedItemIds(), items -> {
                                slot.setAssignedItemIds(items);
                                clientInstance.getConfigManager().save();
                                buildUI();
                            }));
                        }
                    }
            ).dimensions(contentX + 193, contentY + relY, 68, 15).build(), relY);

            boolean isPref = (storageConfig.getPreferredVaultIndex() == i);
            addContentWidget(ButtonWidget.builder(
                    Text.literal(isPref ? "★" : "☆").formatted(isPref ? Formatting.YELLOW : Formatting.GRAY),
                    btn -> {
                        storageConfig.setPreferredVaultIndex(vaultIdx);
                        buildUI();
                    }
            ).dimensions(contentX + 264, contentY + relY, 22, 15).build(), relY);

            addContentWidget(ButtonWidget.builder(
                    Text.literal("Test").formatted(Formatting.AQUA),
                    btn -> {
                        if (this.client != null) {
                            storageEngine.triggerManualTest(this.client, vaultIdx);
                            statusMessage = "Testing " + slot.getDisplayName() + "...";
                            statusColor = Formatting.AQUA;
                        }
                    }
            ).dimensions(contentX + 289, contentY + relY, 36, 15).build(), relY);

            relY += 18;
        }

        return relY;
    }

    // =========================================================================
    // TAB 3: SELECTION (Area Selection)
    // =========================================================================
    private int buildSelectionTab() {
        int relY = 4;
        int btnH = 17;
        int w = contentW - 14;
        int halfW = (w - 6) / 2;

        newAreaNameField = new TextFieldWidget(this.textRenderer, contentX + 4, contentY + relY, 160, btnH, Text.literal("Name"));
        newAreaNameField.setText("Main Quarry");
        newAreaNameField.setMaxLength(32);
        addContentWidget(newAreaNameField, relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal("Save Area").formatted(Formatting.AQUA),
                btn -> {
                    if (selection.isComplete()) {
                        String name = newAreaNameField.getText().trim();
                        if (name.isEmpty()) name = "Saved Area";
                        SavedAreaProfile saved = clientInstance.saveActiveSelectionAsNamedArea(name);
                        statusMessage = "Saved area: " + saved.getName();
                        statusColor = Formatting.GREEN;
                        buildUI();
                    } else {
                        statusMessage = "Error: Complete selection first!";
                        statusColor = Formatting.RED;
                    }
                }
        ).dimensions(contentX + 168, contentY + relY, 76, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal("Load Last"),
                btn -> {
                    clientInstance.restoreSavedAreaForCurrentEnvironment(this.client, true);
                    statusMessage = "Restored last area for world.";
                    statusColor = Formatting.AQUA;
                    buildUI();
                }
        ).dimensions(contentX + 248, contentY + relY, 70, btnH).build(), relY);
        relY += btnH + 6;

        addContentWidget(ButtonWidget.builder(
                Text.literal("Set Corner 1 Here"),
                btn -> {
                    if (this.client != null && this.client.player != null) {
                        selection.setCorner1(this.client.player.getBlockPos());
                        buildUI();
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal("Set Corner 2 Here"),
                btn -> {
                    if (this.client != null && this.client.player != null) {
                        selection.setCorner2(this.client.player.getBlockPos());
                        buildUI();
                    }
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 6;

        addContentWidget(ButtonWidget.builder(
                Text.literal(selection.isSelectionModeActive() ? "Selection Mode: ON" : "Selection Mode: OFF")
                        .formatted(selection.isSelectionModeActive() ? Formatting.GREEN : Formatting.GRAY),
                btn -> {
                    selection.toggleSelectionMode();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal("Clear Selection").formatted(Formatting.RED),
                btn -> {
                    clientInstance.resetSelection();
                    statusMessage = "Selection cleared.";
                    statusColor = Formatting.YELLOW;
                    buildUI();
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);

        relY += btnH + 68; // Room for coordinates details card

        return relY;
    }

    // =========================================================================
    // TAB 4: SAVED AREAS
    // =========================================================================
    private int buildSavedAreasTab() {
        int relY = 4;
        int btnH = 17;
        int w = contentW - 14;

        String server = clientInstance.getServerIdentifier(this.client);
        String dim = clientInstance.getDimensionIdentifier(this.client);
        List<SavedAreaProfile> areas = clientInstance.getConfigManager().getSavedAreasFor(server, dim);

        addContentWidget(ButtonWidget.builder(
                Text.literal("+ Save Active Selection as New Area").formatted(selection.isComplete() ? Formatting.AQUA : Formatting.GRAY),
                btn -> {
                    if (selection.isComplete()) {
                        String autoName = "Area #" + (areas.size() + 1);
                        clientInstance.saveActiveSelectionAsNamedArea(autoName);
                        buildUI();
                    } else {
                        statusMessage = "Select two corners before saving!";
                        statusColor = Formatting.RED;
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        relY += btnH + 6;

        if (areas.isEmpty()) {
            relY += 40;
            return relY;
        }

        for (SavedAreaProfile profile : areas) {
            final String pId = profile.getId();
            boolean isActive = profile.isActive() || Objects.equals(pId, config.getLastActiveAreaId());
            int rowH = 34;

            addContentWidget(ButtonWidget.builder(
                    Text.literal(isActive ? "Active" : "Load").formatted(isActive ? Formatting.GREEN : Formatting.AQUA),
                    btn -> {
                        clientInstance.loadSavedArea(profile);
                        buildUI();
                    }
            ).dimensions(contentX + contentW - 140, contentY + relY + 2, 44, btnH).build(), relY + 2);

            addContentWidget(ButtonWidget.builder(
                    Text.literal("Dup"),
                    btn -> {
                        clientInstance.getConfigManager().duplicateArea(pId);
                        buildUI();
                    }
            ).dimensions(contentX + contentW - 92, contentY + relY + 2, 34, btnH).build(), relY + 2);

            boolean isConfirming = Objects.equals(confirmDeleteId, pId);
            addContentWidget(ButtonWidget.builder(
                    Text.literal(isConfirming ? "Confirm?" : "Del").formatted(Formatting.RED),
                    btn -> {
                        if (isConfirming) {
                            clientInstance.getConfigManager().deleteArea(pId);
                            confirmDeleteId = null;
                            buildUI();
                        } else {
                            confirmDeleteId = pId;
                            buildUI();
                        }
                    }
            ).dimensions(contentX + contentW - 54, contentY + relY + 2, isConfirming ? 48 : 30, btnH).build(), relY + 2);

            if (selection.isComplete()) {
                addContentWidget(ButtonWidget.builder(
                        Text.literal("Update"),
                        btn -> {
                            clientInstance.getConfigManager().updateAreaCoordinates(pId, selection.getCurrentRegion());
                            statusMessage = "Updated coordinates for " + profile.getName();
                            statusColor = Formatting.GREEN;
                            buildUI();
                        }
                ).dimensions(contentX + contentW - 92, contentY + relY + 19, 48, 13).build(), relY + 19);
            }

            relY += rowH + 2;
        }

        return relY;
    }

    // =========================================================================
    // TAB 5: MINING (Continuous Auto Mining Engine)
    // =========================================================================
    private int buildMiningTab() {
        int relY = 4;
        int btnH = 17;
        int w = contentW - 14;
        int halfW = (w - 6) / 2;

        // Row 1: Primary Auto Mine Activation & Selection Reset
        addContentWidget(ButtonWidget.builder(
                getAutoMineButtonText(),
                btn -> {
                    boolean newState = !config.isAutoMineEnabled();
                    clientInstance.setAutoMineEnabled(newState);
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal("Reset Active Selection").formatted(Formatting.YELLOW),
                btn -> {
                    selection.reset();
                    clientInstance.getMiningEngine().setActiveRegion(null);
                    clientInstance.playClickFeedback();
                    buildUI();
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        // Row 2: Behavior Mode Preset & Target Order
        addContentWidget(CyclingButtonWidget.<com.refillminerpro.config.BehaviorMode>builder(
                mode -> Text.literal(mode.getDisplayName()),
                config::getBehaviorMode
        ).values(com.refillminerpro.config.BehaviorMode.values())
        .build(contentX + 4, contentY + relY, halfW, btnH,
                Text.literal("Preset"),
                (button, value) -> {
                    config.setBehaviorMode(value);
                    clientInstance.getConfigManager().save();
                    statusMessage = "Preset: " + value.getDisplayName();
                    statusColor = Formatting.AQUA;
                    buildUI();
                }
        ), relY);

        addContentWidget(CyclingButtonWidget.<com.refillminerpro.config.TargetPriority>builder(
                priority -> Text.literal(priority.getDisplayName()),
                config::getTargetPriority
        ).values(com.refillminerpro.config.TargetPriority.values())
        .build(contentX + 10 + halfW, contentY + relY, halfW, btnH,
                Text.literal("Order"),
                (button, value) -> {
                    config.setTargetPriority(value);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ), relY);
        relY += btnH + 4;

        // Row 3: Boundary restriction & Tool swapping toggles
        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Enforce Boundary", config.isEnforceAreaBoundary(), val -> {
            config.setEnforceAreaBoundary(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Auto Switch Tool", config.isAutoSwitchTool(), val -> {
            config.setAutoSwitchTool(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 19;

        // Row 4: Durability protection & Forward Scan Focus
        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Protect Durability", config.isProtectLowDurability(), val -> {
            config.setProtectLowDurability(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Forward Focus (No Backturns)", config.isForwardScanOnly(), val -> {
            config.setForwardScanOnly(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 19;

        // Row 5: Auto Walk & Manual Mode Toggle
        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Auto Walk To Blocks", config.isAutoWalk(), val -> {
            config.setAutoWalk(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Manual Crosshair Assist", config.isPlayerControlledMining(), val -> {
            config.setPlayerControlledMining(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 19;

        // Row 5b: Continuous Mining & Continuous Forward Movement
        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Continuous Mining", config.isContinuousMining(), val -> {
            config.setContinuousMining(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Forward Movement", config.isContinuousForwardMovement(), val -> {
            config.setContinuousForwardMovement(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 19;

        // Row 5c: Desired Mining Gap & Pathfinding
        double currentGap = config.getDesiredMiningGap();
        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Mining Gap: %.1fb", currentGap)).formatted(Formatting.AQUA),
                btn -> {
                    double nextGap = (config.getDesiredMiningGap() >= 2.0) ? 1.0 : (config.getDesiredMiningGap() + 0.5);
                    config.setDesiredMiningGap(nextGap);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Pathfinding (A*)", config.isAutoNavigate(), val -> {
            config.setAutoNavigate(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += btnH + 4;

        // Row 5d: Target Search Radius & Pathfinding Search Limit
        int currentScanDist = config.getScanDistance();
        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Search Rad: %db", currentScanDist)).formatted(Formatting.GREEN),
                btn -> {
                    int nextDist = (currentScanDist <= 4) ? 6 : (currentScanDist <= 6) ? 8 : (currentScanDist <= 8) ? 10 : 4;
                    config.setScanDistance(nextDist);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        int currentLimit = config.getPathfindingSearchLimit();
        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Path Limit: %d", currentLimit)).formatted(Formatting.AQUA),
                btn -> {
                    int nextLimit = (currentLimit <= 500) ? 1000 : (currentLimit <= 1000) ? 1500 : (currentLimit <= 1500) ? 2500 : 500;
                    config.setPathfindingSearchLimit(nextLimit);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        // Row 5e: Stuck Detection Threshold & Recovery Mode
        int currentStuckThresh = config.getStuckDetectionThreshold();
        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Stuck Limit: %dt", currentStuckThresh)).formatted(Formatting.LIGHT_PURPLE),
                btn -> {
                    int nextThresh = (currentStuckThresh <= 15) ? 20 : (currentStuckThresh <= 20) ? 30 : (currentStuckThresh <= 30) ? 40 : 15;
                    config.setStuckDetectionThreshold(nextThresh);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(CyclingButtonWidget.<RecoveryMode>builder(
                mode -> mode.getText(),
                config::getRecoveryMode
        ).values(RecoveryMode.values())
        .build(contentX + 10 + halfW, contentY + relY, halfW, btnH,
                Text.literal("Recovery"),
                (button, value) -> {
                    config.setRecoveryMode(value);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ), relY);
        relY += btnH + 4;

        // Row 5f: Movement Speed Preset & Protection Cooldown
        addContentWidget(CyclingButtonWidget.<com.refillminerpro.config.MovementSmoothness>builder(
                smooth -> Text.literal(smooth.getDisplayName()),
                config::getMovementSmoothness
        ).values(com.refillminerpro.config.MovementSmoothness.values())
        .build(contentX + 4, contentY + relY, halfW, btnH,
                Text.literal("Speed"),
                (button, value) -> {
                    config.setMovementSmoothness(value);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ), relY);

        int currentProtCd = config.getProtectionCooldownSeconds();
        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Prot. CD: %ds", currentProtCd)).formatted(Formatting.GOLD),
                btn -> {
                    int nextCd;
                    if (currentProtCd <= 10) nextCd = 20;
                    else if (currentProtCd <= 20) nextCd = 30;
                    else if (currentProtCd <= 30) nextCd = 60;
                    else nextCd = 10;
                    config.setProtectionCooldownSeconds(nextCd);
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 4;

        // Row 6: Whitelist & Blacklist filter dialog buttons
        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Mining Whitelist (%d)", config.getWhitelist().size())).formatted(Formatting.GREEN),
                btn -> {
                    if (this.client != null) {
                        this.client.setScreen(new ItemPickerScreen(this, "Mining Whitelist", config.getWhitelist(), items -> {
                            config.setWhitelist(items);
                            if (clientInstance.getBlockFilter() != null) clientInstance.getBlockFilter().updateCache();
                            clientInstance.getConfigManager().save();
                            buildUI();
                        }));
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Mining Blacklist (%d)", config.getBlacklist().size())).formatted(Formatting.RED),
                btn -> {
                    if (this.client != null) {
                        this.client.setScreen(new ItemPickerScreen(this, "Mining Blacklist", config.getBlacklist(), items -> {
                            config.setBlacklist(items);
                            if (clientInstance.getBlockFilter() != null) clientInstance.getBlockFilter().updateCache();
                            clientInstance.getConfigManager().save();
                            buildUI();
                        }));
                    }
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 72; // Reserve room for live crosshair target & boundary inspection card

        return relY;
    }

    // =========================================================================
    // TAB 6: ITEM RULES
    // =========================================================================
    private int buildItemRulesTab() {
        int relY = 4;
        int btnH = 17;
        int w = contentW - 14;
        int halfW = (w - 6) / 2;

        addContentWidget(CyclingButtonWidget.<ItemFilterMode>builder(ItemFilterMode::getText, storageConfig::getItemFilterMode)
                .values(ItemFilterMode.values())
                .build(contentX + 4, contentY + relY, w, btnH,
                        Text.literal("Rule Mode"),
                        (button, value) -> {
                            storageConfig.setItemFilterMode(value);
                            clientInstance.getConfigManager().save();
                        }
                ), relY);
        relY += btnH + 4;

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Stored Items (%d)", storageConfig.getStoredItems().size())).formatted(Formatting.AQUA),
                btn -> {
                    if (this.client != null) {
                        this.client.setScreen(new ItemPickerScreen(this, "Eligible Stored Items", storageConfig.getStoredItems(), items -> {
                            storageConfig.setStoredItems(items);
                            clientInstance.getConfigManager().save();
                            buildUI();
                        }));
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        addContentWidget(ButtonWidget.builder(
                Text.literal(String.format("Protected Items (%d)", storageConfig.getProtectedItems().size())).formatted(Formatting.GOLD),
                btn -> {
                    if (this.client != null) {
                        this.client.setScreen(new ItemPickerScreen(this, "Protected Items (Never Deposit)", storageConfig.getProtectedItems(), items -> {
                            storageConfig.setProtectedItems(items);
                            clientInstance.getConfigManager().save();
                            buildUI();
                        }));
                    }
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 6;

        int pW = (w - 9) / 4;
        addContentWidget(ButtonWidget.builder(Text.literal("+Ores").formatted(Formatting.GREEN), btn -> {
            addItemsToStored(List.of("minecraft:raw_iron", "minecraft:raw_gold", "minecraft:raw_copper", "minecraft:coal", "minecraft:diamond", "minecraft:emerald", "minecraft:redstone", "minecraft:lapis_lazuli", "minecraft:ancient_debris"));
            clientInstance.getConfigManager().save();
            buildUI();
        }).dimensions(contentX + 4, contentY + relY, pW, 15).build(), relY);

        addContentWidget(ButtonWidget.builder(Text.literal("+Blocks").formatted(Formatting.AQUA), btn -> {
            addItemsToStored(List.of("minecraft:cobblestone", "minecraft:stone", "minecraft:deepslate", "minecraft:granite", "minecraft:diorite", "minecraft:andesite", "minecraft:tuff"));
            clientInstance.getConfigManager().save();
            buildUI();
        }).dimensions(contentX + 4 + pW + 3, contentY + relY, pW, 15).build(), relY);

        addContentWidget(ButtonWidget.builder(Text.literal("+Ingots").formatted(Formatting.YELLOW), btn -> {
            addItemsToStored(List.of("minecraft:iron_ingot", "minecraft:gold_ingot", "minecraft:copper_ingot", "minecraft:netherite_ingot", "minecraft:amethyst_shard", "minecraft:quartz"));
            clientInstance.getConfigManager().save();
            buildUI();
        }).dimensions(contentX + 4 + (pW + 3) * 2, contentY + relY, pW, 15).build(), relY);

        addContentWidget(ButtonWidget.builder(Text.literal("Clear").formatted(Formatting.RED), btn -> {
            storageConfig.getStoredItems().clear();
            clientInstance.getConfigManager().save();
            buildUI();
        }).dimensions(contentX + 4 + (pW + 3) * 3, contentY + relY, pW, 15).build(), relY);

        relY += 20 + 65; // Room for real item icons preview grid

        return relY;
    }

    private void addItemsToStored(List<String> items) {
        List<String> current = storageConfig.getStoredItems();
        for (String id : items) {
            if (!current.contains(id)) current.add(id);
        }
    }

    // =========================================================================
    // TAB 7: ACTIVITY
    // =========================================================================
    private int buildActivityTab() {
        int relY = 4;
        addContentWidget(ButtonWidget.builder(
                Text.literal("Clear Activity Log").formatted(Formatting.RED),
                btn -> {
                    if (storageEngine != null) storageEngine.getActivityLogger().clear();
                }
        ).dimensions(contentX + 4, contentY + relY, 120, 16).build(), relY);

        relY += 24 + 110;
        return relY;
    }

    // =========================================================================
    // TAB 8: SETTINGS & VISUALS
    // =========================================================================
    private int buildSettingsTab() {
        int relY = 4;
        int btnH = 17;
        int w = contentW - 14;
        int halfW = (w - 6) / 2;

        // Predictive Arc Animation Controls
        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Predictive Arc FX", config.isArcAnimationEnabled(), val -> {
            config.setArcAnimationEnabled(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        addCompactCheckboxWidget(contentX + 10 + halfW, relY, halfW, "Mouse Reactivity", config.isArcMouseReactive(), val -> {
            config.setArcMouseReactive(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });
        relY += 19;

        addCompactCheckboxWidget(contentX + 4, relY, halfW, "Reduced Motion", config.isArcReducedMotion(), val -> {
            config.setArcReducedMotion(val);
            clientInstance.getConfigManager().save();
            buildUI();
        });

        // Color Preset Cycling Button
        addContentWidget(CyclingButtonWidget.<ArcColorPreset>builder(ArcColorPreset::getText, config::getArcColorPreset)
                .values(ArcColorPreset.values())
                .build(contentX + 10 + halfW, contentY + relY, halfW, btnH,
                        Text.literal("Theme"),
                        (button, value) -> {
                            config.setArcColorPreset(value);
                            clientInstance.getConfigManager().save();
                        }
                ), relY);
        relY += btnH + 4;

        // Arc Speed Button
        addContentWidget(ButtonWidget.builder(
                getArcSpeedButtonText(),
                btn -> {
                    double cur = config.getArcSpeed();
                    double next = (cur < 0.8) ? 1.0 : (cur < 1.3) ? 1.5 : 0.5;
                    config.setArcSpeed(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(getArcSpeedButtonText());
                }
        ).dimensions(contentX + 4, contentY + relY, halfW, btnH).build(), relY);

        // Arc Intensity Button
        addContentWidget(ButtonWidget.builder(
                getArcIntensityButtonText(),
                btn -> {
                    double cur = config.getArcIntensity();
                    double next = (cur < 0.8) ? 1.0 : (cur < 1.3) ? 1.4 : 0.6;
                    config.setArcIntensity(next);
                    clientInstance.getConfigManager().save();
                    btn.setMessage(getArcIntensityButtonText());
                }
        ).dimensions(contentX + 10 + halfW, contentY + relY, halfW, btnH).build(), relY);
        relY += btnH + 6;

        String currentServer = clientInstance.getServerIdentifier(this.client);
        boolean isSingleplayer = currentServer == null || currentServer.startsWith("singleplayer");

        if (isSingleplayer) {
            addContentWidget(ButtonWidget.builder(
                    Text.literal("Environment: Singleplayer (Full Authorization)").formatted(Formatting.GREEN),
                    btn -> {}
            ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        } else {
            boolean authorized = config.isEnvironmentAuthorized(currentServer);
            addContentWidget(ButtonWidget.builder(
                    Text.literal("Server Auth: ").append(Text.literal(authorized ? "AUTHORIZED" : "RESTRICTED").formatted(authorized ? Formatting.AQUA : Formatting.RED)),
                    btn -> {
                        boolean newState = !config.isEnvironmentAuthorized(currentServer);
                        config.setEnvironmentAuthorized(currentServer, newState);
                        clientInstance.getConfigManager().save();
                        buildUI();
                    }
            ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        }
        relY += btnH + 6;

        addContentWidget(ButtonWidget.builder(
                Text.literal("Generate Diagnostics Report").formatted(Formatting.YELLOW),
                btn -> {
                    File report = LocalDiagnosticsManager.generateDiagnosticReport();
                    if (report != null && this.client != null && this.client.player != null) {
                        this.client.player.sendMessage(Text.literal("Report saved: " + report.getName()).formatted(Formatting.GREEN), false);
                    }
                }
        ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        relY += btnH + 6;

        addContentWidget(ButtonWidget.builder(
                Text.literal("Reset Auto Storage Defaults").formatted(Formatting.GOLD),
                btn -> {
                    storageConfig.initDefaults();
                    clientInstance.getConfigManager().save();
                    buildUI();
                }
        ).dimensions(contentX + 4, contentY + relY, w, btnH).build(), relY);
        relY += btnH + 30;

        return relY;
    }

    private Text getArcSpeedButtonText() {
        double s = config.getArcSpeed();
        String lbl = (s < 0.8) ? "Slow (0.5x)" : (s < 1.3) ? "Normal (1.0x)" : "Fast (1.5x)";
        return Text.literal("Arc Speed: " + lbl);
    }

    private Text getArcIntensityButtonText() {
        double i = config.getArcIntensity();
        String lbl = (i < 0.8) ? "Subtle (0.6x)" : (i < 1.3) ? "Normal (1.0x)" : "Vivid (1.4x)";
        return Text.literal("Arc Glow: " + lbl);
    }

    private void addCompactCheckboxWidget(int x, int relY, int w, String label, boolean checked, java.util.function.Consumer<Boolean> onToggle) {
        ClickableWidget btn = ButtonWidget.builder(
                Text.literal((checked ? "[✓] " : "[  ] ") + label).formatted(checked ? Formatting.WHITE : Formatting.GRAY),
                b -> onToggle.accept(!checked)
        ).dimensions(x, contentY + relY, w, 16).build();
        addContentWidget(btn, relY);
    }

    // =========================================================================
    // RENDERING (Transparent Live World + Predictive Arc Animated Background)
    // =========================================================================
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Fully transparent background: do not draw solid blur or dimming
        // so the live Minecraft world stays 100% visible behind the GUI!
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.serverHoverTooltip = null;

        // 1. Interactive Predictive Arc Animated Background (Transparent layer over live game world)
        PredictiveArcRenderer.getInstance().render(
                context, mouseX, mouseY, delta, this.width, this.height, config);

        // 2. Transparent Glass Panel Container Outline (Live world visible behind)
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, COLOR_GLASS_PANEL);
        drawBorder(context, panelX, panelY, panelWidth, panelHeight, COLOR_GLASS_BORDER);

        // 3. ROW A — APPLICATION HEADER
        renderRowA(context);

        // 4. ROW B — ENVIRONMENT INFORMATION (SERVER & DIMENSION)
        renderRowB(context, mouseX, mouseY);

        // Subtle divider between Row B and Row C
        context.fill(panelX + 4, headerRowCY - 2, panelX + panelWidth - 4, headerRowCY - 1, COLOR_GLASS_LINE);

        // 5. ROW C — PERSISTENT NAVIGATION TABS (Never Scissored)
        renderRowC(context, mouseX, mouseY);

        // Bottom divider below tab bar
        context.fill(panelX + 4, headerRowCY + tabBarH, panelX + panelWidth - 4, headerRowCY + tabBarH + 1, COLOR_GLASS_LINE);

        // 6. CONTENT VIEWPORT (Scissored independently)
        updateContentWidgetPositions();

        context.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);

        int textY = contentY + 4 - scrollY;
        switch (activeTab) {
            case 0 -> renderGeneralTabCards(context, textY);
            case 1 -> renderAutoStoreCards(context, textY);
            case 2 -> renderVaultsLabels(context, textY);
            case 3 -> renderSelectionDetailsCard(context, textY);
            case 4 -> renderSavedAreasList(context, textY);
            case 5 -> renderMiningInspectorCard(context, textY);
            case 6 -> renderItemRulesPreview(context, textY);
            case 7 -> renderActivityLog(context, textY);
            case 8 -> renderSettingsInfo(context, textY);
        }

        // Render content widgets (Minecraft-native buttons and toggles)
        for (PositionedWidget pw : contentWidgets) {
            if (pw.widget.visible) {
                pw.widget.render(context, mouseX, mouseY, delta);
            }
        }

        context.disableScissor();

        // 7. Transparent Scrollbar (if content overflows viewport)
        if (maxScroll > 0) {
            int sbX = contentX + contentW - 4;
            int sbY = contentY;
            int sbH = contentH;
            context.fill(sbX, sbY, sbX + 3, sbY + sbH, 0x1E171C26);

            int thumbH = Math.max(16, (int) ((float) contentH / (contentH + maxScroll) * sbH));
            int thumbY = sbY + (int) ((float) scrollY / maxScroll * (sbH - thumbH));
            context.fill(sbX, thumbY, sbX + 3, thumbY + thumbH, 0x558498FF);
        }

        // 8. Fixed Footer (Never Scissored)
        context.fill(panelX + 4, footerY - 2, panelX + panelWidth - 4, footerY - 1, COLOR_GLASS_LINE);
        doneButton.render(context, mouseX, mouseY, delta);
        resetButton.render(context, mouseX, mouseY, delta);

        if (statusMessage != null) {
            context.drawTextWithShadow(this.textRenderer, Text.literal(statusMessage).formatted(statusColor),
                    panelX + 78, footerY + 4, 0xFFFFFFFF);
        }

        // 9. Tooltip for long server address if hovered
        if (serverHoverTooltip != null) {
            context.drawTooltip(this.textRenderer, Text.literal(serverHoverTooltip), mouseX, mouseY);
        }
    }

    // Row A: App Title & Connection Status
    private void renderRowA(DrawContext context) {
        // App Title on Left
        context.drawTextWithShadow(this.textRenderer, Text.literal("Refill Miner Pro").formatted(Formatting.BOLD),
                panelX + 8, headerRowAY + 2, COLOR_TEXT_MAIN);

        // Connection Status Indicator on Right
        String connText;
        int connColor;
        if (client != null && client.isInSingleplayer()) {
            connText = "● Singleplayer";
            connColor = COLOR_SUCCESS;
        } else if (client != null && client.getCurrentServerEntry() != null) {
            connText = "● Connected";
            connColor = COLOR_SUCCESS;
        } else {
            connText = "○ Offline";
            connColor = COLOR_TEXT_MUTED;
        }

        int connW = this.textRenderer.getWidth(connText);
        context.drawTextWithShadow(this.textRenderer, Text.literal(connText),
                panelX + panelWidth - 8 - connW, headerRowAY + 2, connColor);
    }

    // Row B: Environment Row (SERVER & DIMENSION)
    private void renderRowB(DrawContext context, int mouseX, int mouseY) {
        String rawServer = clientInstance.getServerIdentifier(this.client);
        String displayServer = ServerIdentifier.getHostOnly(rawServer);
        String rawDim = clientInstance.getDimensionIdentifier(this.client);
        String displayDim = formatDimension(rawDim);
        int dimColor = getDimensionColor(rawDim);

        // Right side: DIMENSION label & value
        String dimLabel = "DIMENSION ";
        int dimLabelW = textRenderer.getWidth(dimLabel);
        int dimValW = textRenderer.getWidth(displayDim);
        int dimTotalW = dimLabelW + dimValW;
        int dimX = panelX + panelWidth - 8 - dimTotalW;

        context.drawTextWithShadow(textRenderer, Text.literal(dimLabel), dimX, headerRowBY + 2, COLOR_TEXT_MUTED);
        context.drawTextWithShadow(textRenderer, Text.literal(displayDim), dimX + dimLabelW, headerRowBY + 2, dimColor);

        // Left side: SERVER label & value
        String serverLabel = "SERVER ";
        int sLabelW = textRenderer.getWidth(serverLabel);
        int serverStartX = panelX + 8;
        int maxServerW = dimX - serverStartX - sLabelW - 12;

        context.drawTextWithShadow(textRenderer, Text.literal(serverLabel), serverStartX, headerRowBY + 2, COLOR_TEXT_MUTED);

        String trimmedServer = displayServer;
        boolean wasTrimmed = false;
        if (textRenderer.getWidth(displayServer) > maxServerW) {
            trimmedServer = textRenderer.trimToWidth(displayServer, maxServerW - 6) + "…";
            wasTrimmed = true;
        }

        int serverTextX = serverStartX + sLabelW;
        context.drawTextWithShadow(textRenderer, Text.literal(trimmedServer), serverTextX, headerRowBY + 2, COLOR_ACCENT);

        // Hover detection for server tooltip
        if (wasTrimmed && mouseX >= serverTextX && mouseX <= serverTextX + maxServerW && mouseY >= headerRowBY && mouseY <= headerRowBY + 12) {
            this.serverHoverTooltip = "Server: " + rawServer;
        }
    }

    // Row C: Persistent Navigation Tabs
    private void renderRowC(DrawContext context, int mouseX, int mouseY) {
        // Tab background bar (Transparent)
        context.fill(panelX + 4, headerRowCY, panelX + panelWidth - 4, headerRowCY + tabBarH, 0x14171C26);

        // Overflow Arrow Buttons if needed
        if (hasTabOverflow) {
            boolean leftHover = mouseX >= leftArrowX && mouseX < leftArrowX + 12 && mouseY >= headerRowCY && mouseY < headerRowCY + tabBarH;
            context.fill(leftArrowX, headerRowCY, leftArrowX + 12, headerRowCY + tabBarH, leftHover ? COLOR_GLASS_HOVER : 0x2A171C26);
            drawBorder(context, leftArrowX, headerRowCY, 12, tabBarH, COLOR_GLASS_BORDER);
            context.drawTextWithShadow(textRenderer, Text.literal("<"), leftArrowX + 3, headerRowCY + 6, leftHover ? COLOR_TEXT_MAIN : COLOR_TEXT_SEC);

            boolean rightHover = mouseX >= rightArrowX && mouseX < rightArrowX + 12 && mouseY >= headerRowCY && mouseY < headerRowCY + tabBarH;
            context.fill(rightArrowX, headerRowCY, rightArrowX + 12, headerRowCY + tabBarH, rightHover ? COLOR_GLASS_HOVER : 0x2A171C26);
            drawBorder(context, rightArrowX, headerRowCY, 12, tabBarH, COLOR_GLASS_BORDER);
            context.drawTextWithShadow(textRenderer, Text.literal(">"), rightArrowX + 4, headerRowCY + 6, rightHover ? COLOR_TEXT_MAIN : COLOR_TEXT_SEC);
        }

        // Render each tab button
        for (TabHitbox th : tabHitboxes) {
            boolean isActive = (th.index == activeTab);
            boolean isHovered = (mouseX >= th.x && mouseX < th.x + th.width && mouseY >= th.y && mouseY < th.y + th.height);

            int tabBg = isActive ? 0x44171C26 : isHovered ? COLOR_GLASS_HOVER : 0x22171C26;
            context.fill(th.x, th.y, th.x + th.width, th.y + th.height, tabBg);

            // Tab borders
            context.fill(th.x, th.y, th.x + th.width, th.y + 1, COLOR_GLASS_BORDER);
            context.fill(th.x + th.width - 1, th.y, th.x + th.width, th.y + th.height, COLOR_GLASS_BORDER);

            if (isActive) {
                // Clear accent indicator at bottom of active tab
                context.fill(th.x, th.y + th.height - 2, th.x + th.width, th.y + th.height, COLOR_ACCENT);
            }

            // Tab label text
            String label = TAB_NAMES[th.index];
            int textW = textRenderer.getWidth(label);
            int textX = th.x + (th.width - textW) / 2;
            int textY = th.y + (th.height - 8) / 2;

            int textColor = isActive ? COLOR_TEXT_MAIN : isHovered ? COLOR_ACCENT : COLOR_TEXT_SEC;
            context.drawTextWithShadow(textRenderer, Text.literal(label).formatted(isActive ? Formatting.BOLD : Formatting.RESET),
                    textX, textY, textColor);
        }
    }

    private void renderGeneralTabCards(DrawContext context, int startY) {
        int y = startY + (7 * 18) + 4;
        drawCard(context, contentX + 4, y, contentW - 14, 38, "MINER RUNTIME STATUS");
        MiningStatus status = engine.getStatus();
        String summary = engine.getStatusSummary();
        context.drawTextWithShadow(this.textRenderer, Text.literal(summary).formatted(status.getFormatting(), Formatting.BOLD),
                contentX + 10, y + 13, 0xFFFFFFFF);
        context.drawTextWithShadow(this.textRenderer, Text.literal(String.format("Session Mined: §f%d blocks §7| Hold L-Click to mine",
                        engine.getSessionMinedBlocks())),
                contentX + 10, y + 24, COLOR_TEXT_SEC);
    }

    private void renderMiningInspectorCard(DrawContext context, int startY) {
        int y = startY + (17 * 3) + 44;
        int cardW = contentW - 14;
        drawCard(context, contentX + 4, y, cardW, 64, "LIVE CROSSHAIR TARGET & BOUNDARY GUARD");

        String targetName = com.refillminerpro.engine.MiningDebugInfo.crosshairBlockName;
        net.minecraft.util.math.BlockPos cp = com.refillminerpro.engine.MiningDebugInfo.crosshairPos;
        String posStr = (cp != null) ? String.format("[%d, %d, %d]", cp.getX(), cp.getY(), cp.getZ()) : "No Block (Air/Entity)";
        context.drawTextWithShadow(this.textRenderer,
                Text.literal("Crosshair: ").formatted(Formatting.GRAY)
                        .append(Text.literal(targetName + " " + posStr).formatted(cp != null ? Formatting.AQUA : Formatting.DARK_GRAY)),
                contentX + 10, y + 14, COLOR_TEXT_MAIN);

        boolean hasReg = selection.getCurrentRegion() != null;
        boolean inside = com.refillminerpro.engine.MiningDebugInfo.crosshairInsideBoundary;
        boolean filterMatch = com.refillminerpro.engine.MiningDebugInfo.crosshairFilterEligible;

        Text boundaryText = !hasReg ? Text.literal("No Area Selected (Unbounded)").formatted(Formatting.GRAY)
                : (inside ? Text.literal("YES (Inside Boundary)").formatted(Formatting.GREEN)
                : Text.literal("NO (Outside Boundary)").formatted(Formatting.RED));

        Text filterText = (cp == null) ? Text.literal("N/A").formatted(Formatting.GRAY)
                : (filterMatch ? Text.literal("Eligible").formatted(Formatting.GREEN)
                : Text.literal("Filtered Out").formatted(Formatting.RED));

        context.drawTextWithShadow(this.textRenderer,
                Text.literal("Boundary: ").formatted(Formatting.GRAY).append(boundaryText)
                        .append(Text.literal(" | Filter: ").formatted(Formatting.GRAY)).append(filterText),
                contentX + 10, y + 27, COLOR_TEXT_MAIN);

        boolean holding = com.refillminerpro.engine.MiningDebugInfo.isHoldingAttack;
        Text actionText;
        if (!config.isAutoMineEnabled()) {
            actionText = Text.literal("Mining Disabled — Click button above to enable").formatted(Formatting.RED);
        } else if (holding) {
            if (hasReg && config.isEnforceAreaBoundary() && !inside) {
                actionText = Text.literal("Blocked: Crosshair target is outside boundary").formatted(Formatting.RED);
            } else if (!filterMatch && cp != null) {
                actionText = Text.literal("Blocked: Block is excluded by filter").formatted(Formatting.GOLD);
            } else {
                actionText = Text.literal("● Holding Left-Click — Mining Active").formatted(Formatting.AQUA);
            }
        } else {
            actionText = Text.literal("Ready: Aim crosshair at block and hold Left-Click").formatted(Formatting.GREEN);
        }

        context.drawTextWithShadow(this.textRenderer,
                Text.literal("Action: ").formatted(Formatting.GRAY).append(actionText),
                contentX + 10, y + 40, COLOR_TEXT_MAIN);

        context.drawTextWithShadow(this.textRenderer,
                Text.literal(String.format("Session Mined: §f%d blocks §7| Auto Tool: %s §7| Durability Guard: %s",
                        engine.getSessionMinedBlocks(),
                        config.isAutoSwitchTool() ? "§aON" : "§7OFF",
                        config.isProtectLowDurability() ? "§aON" : "§7OFF")),
                contentX + 10, y + 51, COLOR_TEXT_SEC);
    }

    private void renderAutoStoreCards(DrawContext context, int startY) {
        int y = startY + 120;
        int cardW = contentW - 14;
        drawCard(context, contentX + 4, y, cardW, 46, "INVENTORY CAPACITY & STATUS");

        PlayerInventory inv = (this.client != null && this.client.player != null) ? this.client.player.getInventory() : null;
        int capacity = inv != null ? InventoryHelper.getCapacityPercentage(inv) : 0;
        int occupied = inv != null ? InventoryHelper.getOccupiedStorageSlots(inv) : 0;
        int free = inv != null ? InventoryHelper.getFreeStorageSlots(inv) : 36;

        int barX = contentX + 10;
        int barY = y + 14;
        int barW = cardW - 12;
        int barH = 8;
        context.fill(barX, barY, barX + barW, barY + barH, COLOR_ELEVATED);
        drawBorder(context, barX, barY, barW, barH, COLOR_BORDER);

        int barFillW = (int) ((capacity / 100.0) * (barW - 2));
        int fillColor = (capacity >= 90) ? COLOR_ERROR : (capacity >= 75) ? COLOR_WARNING : COLOR_ACCENT;
        if (barFillW > 0) {
            context.fill(barX + 1, barY + 1, barX + 1 + barFillW, barY + barH - 1, fillColor);
        }

        String capText = String.format("Occupied: %d/36 slots (%d%%) | Free: %d slots | Auto Store: %s",
                occupied, capacity, free, storageConfig.isEnabled() ? "§aACTIVE" : "§cOFF");
        context.drawTextWithShadow(this.textRenderer, Text.literal(capText), barX, y + 25, COLOR_TEXT_MAIN);

        String resultText = "Last Action: §7" + storageConfig.getLastResult();
        context.drawTextWithShadow(this.textRenderer, Text.literal(resultText), barX, y + 35, COLOR_TEXT_SEC);
    }

    private void renderVaultsLabels(DrawContext context, int startY) {
        int y = startY + 23;
        context.drawTextWithShadow(this.textRenderer, Text.literal("NAME").formatted(Formatting.GRAY), contentX + 4, y, COLOR_TEXT_MUTED);
        context.drawTextWithShadow(this.textRenderer, Text.literal("COMMAND").formatted(Formatting.GRAY), contentX + 83, y, COLOR_TEXT_MUTED);
        context.drawTextWithShadow(this.textRenderer, Text.literal("STATE").formatted(Formatting.GRAY), contentX + 162, y, COLOR_TEXT_MUTED);
        context.drawTextWithShadow(this.textRenderer, Text.literal("ITEMS").formatted(Formatting.GRAY), contentX + 193, y, COLOR_TEXT_MUTED);
        context.drawTextWithShadow(this.textRenderer, Text.literal("PREF").formatted(Formatting.GRAY), contentX + 264, y, COLOR_TEXT_MUTED);
        context.drawTextWithShadow(this.textRenderer, Text.literal("TEST").formatted(Formatting.GRAY), contentX + 289, y, COLOR_TEXT_MUTED);
    }

    private void renderSelectionDetailsCard(DrawContext context, int startY) {
        int y = startY + 70;
        drawCard(context, contentX + 4, y, contentW - 14, 58, "SELECTION COORDINATES & BOUNDS");

        BlockPos c1 = selection.getCorner1();
        BlockPos c2 = selection.getCorner2();
        BlockRegion reg = selection.getCurrentRegion();

        String c1Str = (c1 != null) ? String.format("[%d, %d, %d]", c1.getX(), c1.getY(), c1.getZ()) : "Not Set";
        String c2Str = (c2 != null) ? String.format("[%d, %d, %d]", c2.getX(), c2.getY(), c2.getZ()) : "Not Set";
        context.drawTextWithShadow(this.textRenderer, Text.literal(String.format("Corner 1: §e%s §7| Corner 2: §e%s", c1Str, c2Str)),
                contentX + 10, y + 14, COLOR_TEXT_MAIN);

        if (reg != null) {
            String boundsStr = String.format("Bounds: [%d,%d,%d] -> [%d,%d,%d]", reg.getMinX(), reg.getMinY(), reg.getMinZ(), reg.getMaxX(), reg.getMaxY(), reg.getMaxZ());
            String sizeStr = String.format("Size: §b%dx%dx%d §7| Volume: §a%,d blocks", reg.getWidthX(), reg.getHeightY(), reg.getLengthZ(), reg.getVolume());
            context.drawTextWithShadow(this.textRenderer, Text.literal(boundsStr), contentX + 10, y + 26, COLOR_TEXT_SEC);
            context.drawTextWithShadow(this.textRenderer, Text.literal(sizeStr), contentX + 10, y + 38, COLOR_TEXT_MAIN);
        } else {
            context.drawTextWithShadow(this.textRenderer, Text.literal("Status: Incomplete Selection (Set both corners)").formatted(Formatting.YELLOW),
                    contentX + 10, y + 26, COLOR_TEXT_SEC);
            context.drawTextWithShadow(this.textRenderer, Text.literal("Tip: Use [Set Corner Here] or left/right click in Selection Mode"),
                    contentX + 10, y + 38, COLOR_TEXT_MUTED);
        }
    }

    private void renderSavedAreasList(DrawContext context, int startY) {
        String server = clientInstance.getServerIdentifier(this.client);
        String dim = clientInstance.getDimensionIdentifier(this.client);
        List<SavedAreaProfile> areas = clientInstance.getConfigManager().getSavedAreasFor(server, dim);

        if (areas.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("No saved areas found for this world/dimension.").formatted(Formatting.YELLOW),
                    contentX + 8, startY + 36, COLOR_TEXT_SEC);
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("Complete an area selection and click 'Save Active Selection' above."),
                    contentX + 8, startY + 50, COLOR_TEXT_MUTED);
            return;
        }

        int y = startY + 23;
        for (SavedAreaProfile profile : areas) {
            boolean isActive = profile.isActive() || Objects.equals(profile.getId(), config.getLastActiveAreaId());

            context.fill(contentX + 4, y, contentX + contentW - 10, y + 32, COLOR_GLASS_CARD);
            drawBorder(context, contentX + 4, y, contentW - 14, 32, isActive ? COLOR_ACCENT : COLOR_GLASS_BORDER);

            String nameText = profile.getName() + (isActive ? " §a[ACTIVE]" : "");
            context.drawTextWithShadow(this.textRenderer, Text.literal(nameText).formatted(Formatting.BOLD),
                    contentX + 8, y + 4, COLOR_TEXT_MAIN);

            String details = String.format("§7[%d,%d,%d]->[%d,%d,%d] §8| §b%dx%dx%d §8(§7%,d blks§8)",
                    profile.getMinX(), profile.getMinY(), profile.getMinZ(),
                    profile.getMaxX(), profile.getMaxY(), profile.getMaxZ(),
                    profile.getWidth(), profile.getHeight(), profile.getDepth(),
                    profile.getVolume());
            context.drawTextWithShadow(this.textRenderer, Text.literal(details),
                    contentX + 8, y + 17, COLOR_TEXT_SEC);

            y += 36;
        }
    }

    private void renderItemRulesPreview(DrawContext context, int startY) {
        int y = startY + 68;
        context.drawTextWithShadow(this.textRenderer, Text.literal("STORED ITEMS PREVIEW:").formatted(Formatting.BOLD),
                contentX + 4, y, COLOR_TEXT_SEC);

        List<String> stored = storageConfig.getStoredItems();
        int displayX = contentX + 4;
        int displayY = y + 12;
        int rendered = 0;
        for (int i = 0; i < stored.size() && rendered < 16; i++) {
            ItemStack stack = ItemCatalogue.getInstance().getStack(stored.get(i));
            if (!stack.isEmpty()) {
                context.fill(displayX - 1, displayY - 1, displayX + 17, displayY + 17, 0x40142E1F);
                context.drawItem(stack, displayX, displayY);
                displayX += 19;
                rendered++;
            }
        }
        if (stored.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, Text.literal("None configured. Click 'Stored Items' to select.").formatted(Formatting.GRAY),
                    contentX + 4, displayY + 4, COLOR_TEXT_MUTED);
        }
    }

    private void renderActivityLog(DrawContext context, int startY) {
        int y = startY + 24;
        List<StorageActivityLogger.StorageEvent> events = storageEngine != null ? storageEngine.getActivityLogger().getEvents() : List.of();
        int count = 0;
        for (StorageActivityLogger.StorageEvent ev : events) {
            if (count >= 7) break;
            int col = ev.severity().getColor();
            String line = String.format("§7[%s] %s: %s", ev.timestamp(), ev.title(), ev.details());
            if (line.length() > 58) line = line.substring(0, 55) + "...";
            context.drawTextWithShadow(this.textRenderer, Text.literal(line), contentX + 6, y, col);
            y += 12;
            count++;
        }
        if (events.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, Text.literal("No activity logged yet.").formatted(Formatting.GRAY),
                    contentX + 6, y, COLOR_TEXT_MUTED);
        }
    }

    private void renderSettingsInfo(DrawContext context, int startY) {
        int y = startY + 70;
        drawCard(context, contentX + 4, y, contentW - 14, 45, "CONTROLS & SHORTCUTS");
        context.drawTextWithShadow(this.textRenderer, Text.literal("Auto Mine: [B] | Pause: [N] | Select: [V]"),
                contentX + 10, y + 14, COLOR_TEXT_SEC);
        context.drawTextWithShadow(this.textRenderer, Text.literal("Reset: [K] | Outline: [H] | Settings: [M]"),
                contentX + 10, y + 26, COLOR_TEXT_MUTED);
    }

    private void drawCard(DrawContext context, int x, int y, int w, int h, String title) {
        context.fill(x, y, x + w, y + h, COLOR_GLASS_CARD);
        drawBorder(context, x, y, w, h, COLOR_GLASS_BORDER);
        if (title != null && !title.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, Text.literal(title).formatted(Formatting.BOLD),
                    x + 6, y + 4, COLOR_TEXT_SEC);
        }
    }

    private void drawBorder(DrawContext context, int x, int y, int w, int h, int color) {
        context.fill(x, y, x + w, y + 1, color);
        context.fill(x, y + h - 1, x + w, y + h, color);
        context.fill(x, y, x + 1, y + h, color);
        context.fill(x + w - 1, y, x + w, y + h, color);
    }

    private String formatDimension(String rawDim) {
        if (rawDim == null) return "Overworld";
        if (rawDim.contains("the_nether") || rawDim.contains("nether")) return "The Nether";
        if (rawDim.contains("the_end") || rawDim.contains("end")) return "The End";
        return "Overworld";
    }

    private int getDimensionColor(String rawDim) {
        if (rawDim == null) return COLOR_SUCCESS;
        if (rawDim.contains("the_nether") || rawDim.contains("nether")) return COLOR_WARNING;
        if (rawDim.contains("the_end") || rawDim.contains("end")) return COLOR_ERROR;
        return COLOR_SUCCESS;
    }

    private Text getAutoMineButtonText() {
        boolean en = config.isAutoMineEnabled();
        return Text.literal("Auto Mine: ").append(Text.literal(en ? "ACTIVE" : "INACTIVE").formatted(en ? Formatting.GREEN : Formatting.RED));
    }

    private Text getPauseButtonText() {
        boolean paused = config.isPaused();
        return Text.literal("State: ").append(Text.literal(paused ? "PAUSED" : "ACTIVE").formatted(paused ? Formatting.YELLOW : Formatting.AQUA));
    }

    private Text getTransferSpeedButtonText() {
        int ticks = storageConfig.getTransferDelayTicks();
        String label = (ticks <= 1) ? "Fast (50ms)" : (ticks == 2) ? "Normal (100ms)" : "Safe (200ms)";
        return Text.literal("Transfer Speed: " + label);
    }

    private Text getRotationSpeedText() {
        double speed = config.getMaxAngularVelocity();
        String label = (speed <= 130.0) ? "Slow (Human)" : (speed <= 220.0) ? "Normal (Smooth)" : "Fast";
        return Text.literal("Head Tracking: " + label);
    }

    private void handleContextualReset() {
        if (activeTab == 3) {
            clientInstance.resetSelection();
            statusMessage = "Selection reset.";
            statusColor = Formatting.YELLOW;
            buildUI();
        } else if (activeTab == 1 || activeTab == 2) {
            storageConfig.initDefaults();
            clientInstance.getConfigManager().save();
            statusMessage = "Auto storage reset to defaults.";
            statusColor = Formatting.YELLOW;
            buildUI();
        } else {
            statusMessage = "Page settings saved.";
            statusColor = Formatting.AQUA;
        }
    }

    private void saveTextFields() {
        List<VaultSlotConfig> slots = storageConfig.getVaultSlots();
        for (int i = 0; i < vaultCommandFields.size() && i < slots.size(); i++) {
            slots.get(i).setCommand(vaultCommandFields.get(i).getText());
        }
        for (int i = 0; i < vaultNameFields.size() && i < slots.size(); i++) {
            slots.get(i).setDisplayName(vaultNameFields.get(i).getText());
        }
        clientInstance.getConfigManager().save();
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.gui.Click click, boolean bl) {
        if (click.button() == 0) {
            double mouseX = click.x();
            double mouseY = click.y();
            // Check Tab Click
            for (TabHitbox th : tabHitboxes) {
                if (mouseX >= th.x && mouseX < th.x + th.width && mouseY >= th.y && mouseY < th.y + th.height) {
                    saveTextFields();
                    activeTab = th.index;
                    scrollY = 0;
                    confirmDeleteId = null;
                    clientInstance.playClickFeedback();
                    buildUI();
                    return true;
                }
            }

            // Check Overflow Arrow Clicks
            if (hasTabOverflow && mouseY >= headerRowCY && mouseY < headerRowCY + tabBarH) {
                if (mouseX >= leftArrowX && mouseX < leftArrowX + 12) {
                    if (tabScrollIndex > 0) {
                        tabScrollIndex--;
                        clientInstance.playClickFeedback();
                        buildUI();
                        return true;
                    }
                } else if (mouseX >= rightArrowX && mouseX < rightArrowX + 12) {
                    if (tabScrollIndex < TAB_NAMES.length - 1) {
                        tabScrollIndex++;
                        clientInstance.playClickFeedback();
                        buildUI();
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(click, bl);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (maxScroll > 0 && mouseX >= contentX && mouseX <= contentX + contentW && mouseY >= contentY && mouseY <= contentY + contentH) {
            scrollY = MathHelper.clamp(scrollY - (int) (verticalAmount * 18), 0, maxScroll);
            updateContentWidgetPositions();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void resize(int width, int height) {
        super.resize(width, height);
        computeLayout();
        buildUI();
    }

    @Override
    public void close() {
        saveTextFields();
        PredictiveArcRenderer.getInstance().reset();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}

