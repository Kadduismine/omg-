package com.refillminerpro.client.gui.arc;

import net.minecraft.text.Text;

/**
 * Visual color palette presets for the transparent Predictive Arc background.
 */
public enum ArcColorPreset {
    COSMIC_ARC("Cosmic Arc", 0x8498FF, 0xB18AFF, 0xD6D4FF),
    EMERALD_WAVE("Emerald Wave", 0x38EF7D, 0x11998E, 0xA8FF78),
    AMBER_GOLD("Amber Gold", 0xFFA000, 0xFF6D00, 0xFFD54F),
    CYAN_PULSE("Cyan Pulse", 0x00E5FF, 0x0091EA, 0x80D8FF);

    private final String displayName;
    private final int colorStart;
    private final int colorMid;
    private final int colorHighlight;

    ArcColorPreset(String displayName, int colorStart, int colorMid, int colorHighlight) {
        this.displayName = displayName;
        this.colorStart = colorStart;
        this.colorMid = colorMid;
        this.colorHighlight = colorHighlight;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Text getText() {
        return Text.literal(displayName);
    }

    public int getColorStart() {
        return colorStart;
    }

    public int getColorMid() {
        return colorMid;
    }

    public int getColorHighlight() {
        return colorHighlight;
    }

    public ArcColorPreset next() {
        ArcColorPreset[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}

