package com.refillminerpro.client.gui.picker;

import net.minecraft.text.Text;

/**
 * Filter categories for the visual item picker.
 */
public enum ItemCategory {
    ALL("All"),
    BUILDING("Building"),
    NATURAL("Natural"),
    FUNCTIONAL("Functional"),
    REDSTONE("Redstone"),
    TOOLS("Tools"),
    COMBAT("Combat"),
    FOOD("Food"),
    INGREDIENTS("Ingredients"),
    MODDED("Modded"),
    SELECTED("Selected");

    private final String displayName;

    ItemCategory(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Text getText() {
        return Text.literal(displayName);
    }
}

