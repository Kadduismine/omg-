package com.refillminerpro.client.gui;

import com.refillminerpro.client.RefillMinerClient;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.MiningStatus;
import com.refillminerpro.pathfinding.NavigationState;
import com.refillminerpro.region.BlockRegion;
import com.refillminerpro.region.SelectionManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

/**
 * Lightweight in-game HUD displaying automation status, navigation state,
 * area mining footprint, queue size, and session statistics.
 */
public class RefillMinerHud {
    public static void render(DrawContext drawContext, RenderTickCounter tickCounter) {
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance == null) return;

        ModConfig config = clientInstance.getConfig();
        if (config == null || !config.isHudVisible()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        TextRenderer textRenderer = mc.textRenderer;
        SelectionManager selection = clientInstance.getSelectionManager();
        MiningEngine engine = clientInstance.getMiningEngine();
        BlockRegion region = selection.getCurrentRegion();

        int x = config.getHudPosX();
        int y = config.getHudPosY();
        int width = 250;
        int height = config.isDebugMode() ? 112 : 86;

        // Semi-transparent native background
        drawContext.fill(x - 2, y - 2, x + width, y + height, 0x88000000);
        drawContext.fill(x - 2, y - 2, x + width, y - 1, 0xFFFFAA00); // Amber top border

        // Title & Mode
        String title = "§6§lRefill Miner Pro";
        com.refillminerpro.config.OperatingMode opMode = clientInstance.getCurrentOperatingMode();
        title += " " + opMode.getColor() + "[" + opMode.name() + "]";

        if (config.isAreaMiningEnabled()) {
            title += String.format(" §b[%dx%d]", config.getAreaMiningWidth(), config.getAreaMiningHeight());
        }
        if (selection.isSelectionModeActive()) {
            title += " §e[SEL]";
        }
        drawContext.drawTextWithShadow(textRenderer, title, x + 2, y + 2, 0xFFFFFFFF);

        // Status & Navigation State Line
        MiningStatus status = engine.getStatus();
        NavigationState navState = engine.getNavigationState();
        String summary = engine.getStatusSummary();
        String statusLine = String.format("Status: %s", summary);
        if (clientInstance.getAutoStorageEngine() != null && clientInstance.getAutoStorageEngine().isAllVaultsCompleted()) {
            statusLine = "Status: §6§lKiiuwt Da Work Is Complete";
        } else if (clientInstance.getAutoStorageEngine() != null && clientInstance.getAutoStorageEngine().isBusy()) {
            statusLine = "Status: §bAuto Storing §7| " + clientInstance.getAutoStorageEngine().getState().getFormattedText().getString();
        } else if (status == MiningStatus.MINING) {
            statusLine += String.format(" §7| Nav: %s", navState.getText().getString());
        }
        drawContext.drawTextWithShadow(textRenderer, statusLine, x + 2, y + 14, 0xFFE0E0E0);

        // Region / Selection info
        String regionLine;
        String activeAreaName = null;
        if (config.getLastActiveAreaId() != null) {
            for (com.refillminerpro.config.SavedAreaProfile p : config.getSavedAreas()) {
                if (p.getId().equals(config.getLastActiveAreaId())) {
                    activeAreaName = p.getName();
                    break;
                }
            }
        }
        if (region != null) {
            String nameTag = (activeAreaName != null) ? " §e(" + activeAreaName + ")" : "";
            regionLine = String.format("Region: §b%dx%dx%d%s §7(%d blks)",
                    region.getWidthX(), region.getHeightY(), region.getLengthZ(), nameTag, region.getVolume());
        } else if (selection.getCorner1() != null) {
            BlockPos c1 = selection.getCorner1();
            regionLine = String.format("Corner 1: §e[%d, %d, %d] §7(R-click C2)", c1.getX(), c1.getY(), c1.getZ());
        } else {
            regionLine = "Region: §cNo area selected (Press 'V')";
        }
        drawContext.drawTextWithShadow(textRenderer, regionLine, x + 2, y + 26, 0xFFCCCCCC);

        // Target Info
        String targetLine;
        if (engine.getCurrentTarget() != null && mc.world != null && mc.world.isChunkLoaded(engine.getCurrentTarget())) {
            BlockPos target = engine.getCurrentTarget();
            String blockName = mc.world.getBlockState(target).getBlock().getName().getString();
            targetLine = String.format("Auto Target: §a%s §7[%d,%d,%d]", blockName, target.getX(), target.getY(), target.getZ());
        } else if (com.refillminerpro.engine.MiningDebugInfo.crosshairPos != null) {
            BlockPos cp = com.refillminerpro.engine.MiningDebugInfo.crosshairPos;
            String bName = com.refillminerpro.engine.MiningDebugInfo.crosshairBlockName;
            boolean inside = com.refillminerpro.engine.MiningDebugInfo.crosshairInsideBoundary;
            String boundaryTag = (region != null) ? (inside ? " §a[INSIDE]" : " §c[OUTSIDE]") : "";
            targetLine = String.format("Crosshair: §a%s §7[%d,%d,%d]%s", bName, cp.getX(), cp.getY(), cp.getZ(), boundaryTag);
        } else {
            targetLine = "Target: §7" + summary;
        }
        drawContext.drawTextWithShadow(textRenderer, targetLine, x + 2, y + 38, 0xFFCCCCCC);

        // Boundary & Tool Guard Line
        String guardLine = String.format("Boundary Guard: %s §7| Tool Swap: %s §7| Durability: %s",
                config.isEnforceAreaBoundary() ? "§aON" : "§cOFF",
                config.isAutoSwitchTool() ? "§aON" : "§7OFF",
                config.isProtectLowDurability() ? "§aON" : "§7OFF");
        drawContext.drawTextWithShadow(textRenderer, guardLine, x + 2, y + 50, 0xFFCCCCCC);

        // Statistics
        String statsMode = config.isPlayerControlledMining() ? " §7| Hold L-Click" : " §b| Auto Mine";
        String statsLine = String.format("Mined This Session: §f%d blocks%s", engine.getSessionMinedBlocks(), statsMode);
        drawContext.drawTextWithShadow(textRenderer, statsLine, x + 2, y + 62, 0xFF55FF55);

        // Optional Live Debug Overlay
        if (config.isDebugMode()) {
            int dy = y + 86;
            com.refillminerpro.engine.MiningState ms = engine.getMiningState();
            BlockPos dbgTarget = com.refillminerpro.engine.MiningDebugInfo.crosshairPos != null
                    ? com.refillminerpro.engine.MiningDebugInfo.crosshairPos : engine.getCurrentTarget();
            String targetPosStr = dbgTarget != null ? String.format("[%d, %d, %d]", dbgTarget.getX(), dbgTarget.getY(), dbgTarget.getZ()) : "None";
            drawContext.drawTextWithShadow(textRenderer, String.format("Debug State: §b%s §7| Target: §e%s", ms != null ? ms.getLabel() : "IDLE", targetPosStr), x + 2, dy, 0xFFFFAA00);
            dy += 12;

            int prog = com.refillminerpro.engine.MiningDebugInfo.miningProgressPercent;
            String reachStr = com.refillminerpro.engine.MiningDebugInfo.withinReach ? "§aIN REACH" : "§cOUT OF REACH";
            String losStr = com.refillminerpro.engine.MiningDebugInfo.lineOfSightValid ? "§aVALID" : "§cOBSTRUCTED";
            drawContext.drawTextWithShadow(textRenderer, String.format("Progress: §e%d%% §7| Reach: %s §7| LOS: %s", prog, reachStr, losStr), x + 2, dy, 0xFFCCCCCC);
            dy += 12;

            String confirmedStr = com.refillminerpro.engine.MiningDebugInfo.blockConfirmedRemoved ? "§aCONFIRMED" : "§7PENDING";
            String rejStr = com.refillminerpro.engine.MiningDebugInfo.wasRejected ? "§cYES" : "§aNO";
            String skipReason = com.refillminerpro.engine.MiningDebugInfo.whySkippedReason;
            drawContext.drawTextWithShadow(textRenderer, String.format("Confirmed: %s §7| Rejected: %s §7| Skip: §e%s", confirmedStr, rejStr, skipReason), x + 2, dy, 0xFFCCCCCC);
            dy += 12;

            drawContext.drawTextWithShadow(textRenderer, String.format("Pending: §e%d §7| Completed: §a%d §7| Failed: §c%d",
                    engine.getQueuedTargetsCount(), engine.getSessionMinedBlocks(), engine.getFailedTargetsCount()), x + 2, dy, 0xFFDDDDDD);
        }
    }
}
