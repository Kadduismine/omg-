package com.refillminerpro.client.gui.arc;

import com.refillminerpro.config.ModConfig;
import net.minecraft.client.gui.DrawContext;

/**
 * Interactive Predictive Arc Animated Background Renderer for Refill Miner Pro.
 * Recreates the luminous dotted arch from the Predictive Arc WebGL architecture
 * within Minecraft 1.21.11's rendering environment.
 *
 * Features:
 * - Mathematical catenary / parabolic curved arch spanning the viewport.
 * - Dynamic traveling sine/cosine wave pulsations.
 * - Smooth mouse-reactive gravitational curve deformation with Gaussian influence falloff.
 * - Interpolated pointer tracking with gentle relaxation when cursor rests.
 * - Dotted / pixel-grid ribbon with multi-row radial thickness and edge fading.
 * - Transparent alpha compositing preserving the live Minecraft 3D world underneath.
 * - Zero object allocation in per-frame render loop for 144+ FPS performance.
 * - Configurable intensity, speed, color presets, mouse reactivity, and reduced motion.
 */
public class PredictiveArcRenderer {
    private static final PredictiveArcRenderer INSTANCE = new PredictiveArcRenderer();

    public static PredictiveArcRenderer getInstance() {
        return INSTANCE;
    }

    private float smoothMouseX = -1.0f;
    private float smoothMouseY = -1.0f;
    private float targetMouseX = -1.0f;
    private float targetMouseY = -1.0f;
    private long lastFrameNanos = 0;
    private float accumulatedTime = 0.0f;
    private long lastMouseMoveTime = 0;

    // Dotted ribbon resolution constants
    private static final int COLUMNS = 88;
    private static final float ROW_SPACING = 4.2f;

    public void updateMouse(int mouseX, int mouseY) {
        this.targetMouseX = mouseX;
        this.targetMouseY = mouseY;
        this.lastMouseMoveTime = System.currentTimeMillis();
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta, int screenWidth, int screenHeight, ModConfig config) {
        if (config != null && !config.isArcAnimationEnabled()) {
            return;
        }

        long now = System.nanoTime();
        if (lastFrameNanos == 0) {
            lastFrameNanos = now;
            smoothMouseX = mouseX;
            smoothMouseY = mouseY;
            targetMouseX = mouseX;
            targetMouseY = mouseY;
            return;
        }

        float dt = (now - lastFrameNanos) / 1_000_000_000.0f;
        lastFrameNanos = now;
        if (dt > 0.1f) dt = 0.1f;
        if (dt <= 0.0001f) dt = 0.016f;

        // Configurable animation parameters
        float speed = config != null ? (float) config.getArcSpeed() : 1.0f;
        float intensity = config != null ? (float) config.getArcIntensity() : 1.0f;
        boolean mouseReactive = config == null || config.isArcMouseReactive();
        boolean reducedMotion = config != null && config.isArcReducedMotion();
        ArcColorPreset preset = (config != null && config.getArcColorPreset() != null)
                ? config.getArcColorPreset() : ArcColorPreset.COSMIC_ARC;

        if (!reducedMotion) {
            accumulatedTime += dt * speed;
        } else {
            accumulatedTime = 0.0f;
        }

        // Pointer updates and smooth interpolation
        updateMouse(mouseX, mouseY);

        // Relax toward resting center when cursor is inactive or leaves the window
        boolean cursorOutside = mouseX < 0 || mouseX > screenWidth || mouseY < 0 || mouseY > screenHeight;
        if (cursorOutside || System.currentTimeMillis() - lastMouseMoveTime > 1800) {
            targetMouseX = screenWidth * 0.5f;
            targetMouseY = screenHeight * 0.40f;
        }

        float lerpSpeed = Math.min(1.0f, dt * 8.0f);
        if (smoothMouseX < 0) {
            smoothMouseX = targetMouseX;
            smoothMouseY = targetMouseY;
        } else {
            smoothMouseX += (targetMouseX - smoothMouseX) * lerpSpeed;
            smoothMouseY += (targetMouseY - smoothMouseY) * lerpSpeed;
        }

        float baseArchHeight = screenHeight * 0.26f;
        float baseArchCenterY = screenHeight * 0.48f;
        float sigma = 0.22f; // Influence spread across ~22% screen width
        float twoSigmaSq = 2.0f * sigma * sigma;

        for (int i = 0; i < COLUMNS; i++) {
            float u = (float) i / (COLUMNS - 1);
            float x = u * screenWidth;

            // Parabolic curved arch equation
            float centerDist = u - 0.5f;
            float parabola = 1.0f - 4.0f * (centerDist * centerDist);
            if (parabola < 0.0f) parabola = 0.0f;
            float yBase = baseArchCenterY - baseArchHeight * parabola;

            // Continuous harmonic traveling waves
            float yWave = 0.0f;
            if (!reducedMotion) {
                float w1 = (float) Math.sin(u * 6.28318f * 1.5f + accumulatedTime * 1.25f) * (screenHeight * 0.020f * speed);
                float w2 = (float) Math.cos(u * 6.28318f * 2.8f - accumulatedTime * 0.85f) * (screenHeight * 0.010f * speed);
                yWave = w1 + w2;
            }

            // Mouse-reactive deformation
            float yMouse = 0.0f;
            float influence = 0.0f;
            if (mouseReactive && !reducedMotion) {
                float dx = (x - smoothMouseX) / (float) screenWidth;
                influence = (float) Math.exp(-(dx * dx) / twoSigmaSq);
                float dy = (smoothMouseY - yBase);
                yMouse = dy * 0.38f * influence;
            }

            float yCenter = yBase + yWave + yMouse;

            // Edge fading so ends dissolve seamlessly
            float edgeFade = (float) Math.sin(u * Math.PI);
            if (edgeFade < 0.0f) edgeFade = 0.0f;

            // Pulsing luminescence
            float pulse = 0.82f + 0.18f * (float) Math.sin(u * 7.5f - accumulatedTime * 2.0f);
            float mouseGlow = 1.0f + 0.55f * influence;

            // Dynamic color interpolation
            int dotColor = calculateArcColor(u, influence, preset);

            // Render ribbon of dots (-3 to +3 rows)
            for (int k = -3; k <= 3; k++) {
                float yDot = yCenter + k * ROW_SPACING;

                // Radial falloff from ribbon center
                float rowFalloff = (float) Math.exp(-(k * k) / 3.2f);

                // Alpha blending: transparent overlay on live game world
                float alphaFloat = 0.44f * intensity * edgeFade * rowFalloff * pulse * mouseGlow;
                if (alphaFloat > 0.60f) alphaFloat = 0.60f;
                if (alphaFloat < 0.02f) continue;

                int alphaInt = (int) (alphaFloat * 255.0f);
                int argb = (alphaInt << 24) | (dotColor & 0x00FFFFFF);

                int dotSize = (k == 0) ? 2 : 1;
                context.fill((int) (x - dotSize), (int) (yDot - dotSize), (int) (x + dotSize + 1), (int) (yDot + dotSize + 1), argb);
            }
        }
    }

    private int calculateArcColor(float u, float influence, ArcColorPreset preset) {
        int c1 = preset.getColorStart();
        int c2 = preset.getColorMid();
        int c3 = preset.getColorHighlight();

        float centerT = 1.0f - Math.abs(u - 0.5f) * 2.0f;
        if (centerT < 0.0f) centerT = 0.0f;

        int baseR = (int) (getR(c1) + (getR(c2) - getR(c1)) * centerT);
        int baseG = (int) (getG(c1) + (getG(c2) - getG(c1)) * centerT);
        int baseB = (int) (getB(c1) + (getB(c2) - getB(c1)) * centerT);

        if (influence > 0.01f) {
            float infT = Math.min(1.0f, influence * 1.25f);
            baseR = (int) (baseR + (getR(c3) - baseR) * infT);
            baseG = (int) (baseG + (getG(c3) - baseG) * infT);
            baseB = (int) (baseB + (getB(c3) - baseB) * infT);
        }

        return (baseR << 16) | (baseG << 8) | baseB;
    }

    private static int getR(int c) { return (c >> 16) & 0xFF; }
    private static int getG(int c) { return (c >> 8) & 0xFF; }
    private static int getB(int c) { return c & 0xFF; }

    public void reset() {
        lastFrameNanos = 0;
        smoothMouseX = -1.0f;
        smoothMouseY = -1.0f;
    }
}

