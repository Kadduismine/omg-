package com.refillminerpro.region;

import com.refillminerpro.config.ModConfig;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

/**
 * Manages interactive region corner selection, validation, and coordinate normalization.
 */
public class SelectionManager {
    private boolean selectionModeActive = false;
    private BlockPos corner1 = null;
    private BlockPos corner2 = null;
    private BlockRegion currentRegion = null;

    public boolean isSelectionModeActive() {
        return selectionModeActive;
    }

    public void setSelectionModeActive(boolean active) {
        this.selectionModeActive = active;
    }

    public void toggleSelectionMode() {
        this.selectionModeActive = !this.selectionModeActive;
    }

    public void setCorner1(BlockPos pos) {
        this.corner1 = pos != null ? pos.toImmutable() : null;
        updateRegion();
    }

    public void setCorner2(BlockPos pos) {
        this.corner2 = pos != null ? pos.toImmutable() : null;
        updateRegion();
    }

    public BlockPos getCorner1() {
        return corner1;
    }

    public BlockPos getCorner2() {
        return corner2;
    }

    public BlockRegion getCurrentRegion() {
        return currentRegion;
    }

    public void setRegion(BlockRegion region) {
        if (region != null) {
            this.corner1 = region.getCorner1();
            this.corner2 = region.getCorner2();
            this.currentRegion = region;
        } else {
            reset();
        }
    }

    public void reset() {
        this.corner1 = null;
        this.corner2 = null;
        this.currentRegion = null;
    }

    private void updateRegion() {
        if (corner1 != null && corner2 != null) {
            this.currentRegion = new BlockRegion(corner1, corner2);
        } else {
            this.currentRegion = null;
        }
    }

    public boolean isComplete() {
        return corner1 != null && corner2 != null && currentRegion != null;
    }

    public ValidationResult validate(ModConfig config) {
        if (!isComplete()) {
            if (corner1 == null && corner2 == null) {
                return new ValidationResult(false, Text.literal("No region selected. Select Corner 1 and Corner 2.").formatted(Formatting.RED));
            } else if (corner1 == null) {
                return new ValidationResult(false, Text.literal("Corner 1 not set. Left-click a block to select it.").formatted(Formatting.YELLOW));
            } else {
                return new ValidationResult(false, Text.literal("Corner 2 not set. Right-click a block to select it.").formatted(Formatting.YELLOW));
            }
        }

        long volume = currentRegion.getVolume();
        if (volume <= 0) {
            return new ValidationResult(false, Text.literal("Invalid region volume.").formatted(Formatting.RED));
        }

        int maxVol = config != null ? config.getMaxRegionVolume() : ModConfig.DEFAULT_MAX_VOLUME;
        if (volume > maxVol) {
            return new ValidationResult(false, Text.literal(
                    String.format("Region volume (%d) exceeds configured safety limit (%d).", volume, maxVol)
            ).formatted(Formatting.RED));
        }

        return new ValidationResult(true, Text.literal(
                String.format("Region valid: %dx%dx%d (%d blocks)",
                        currentRegion.getWidthX(), currentRegion.getHeightY(), currentRegion.getLengthZ(), volume)
        ).formatted(Formatting.GREEN));
    }

    public record ValidationResult(boolean isValid, Text message) {}
}

