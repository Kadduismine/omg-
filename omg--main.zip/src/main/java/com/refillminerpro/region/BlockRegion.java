package com.refillminerpro.region;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.Objects;

/**
 * Immutable representation of a normalized three-dimensional cuboid selection.
 */
public final class BlockRegion {
    private final BlockPos corner1;
    private final BlockPos corner2;

    private final int minX;
    private final int minY;
    private final int minZ;
    private final int maxX;
    private final int maxY;
    private final int maxZ;

    public BlockRegion(BlockPos corner1, BlockPos corner2) {
        this.corner1 = Objects.requireNonNull(corner1, "corner1 must not be null");
        this.corner2 = Objects.requireNonNull(corner2, "corner2 must not be null");

        this.minX = Math.min(corner1.getX(), corner2.getX());
        this.minY = Math.min(corner1.getY(), corner2.getY());
        this.minZ = Math.min(corner1.getZ(), corner2.getZ());

        this.maxX = Math.max(corner1.getX(), corner2.getX());
        this.maxY = Math.max(corner1.getY(), corner2.getY());
        this.maxZ = Math.max(corner1.getZ(), corner2.getZ());
    }

    public BlockPos getCorner1() {
        return corner1;
    }

    public BlockPos getCorner2() {
        return corner2;
    }

    public int getMinX() {
        return minX;
    }

    public int getMinY() {
        return minY;
    }

    public int getMinZ() {
        return minZ;
    }

    public int getMaxX() {
        return maxX;
    }

    public int getMaxY() {
        return maxY;
    }

    public int getMaxZ() {
        return maxZ;
    }

    public int getWidthX() {
        return maxX - minX + 1;
    }

    public int getHeightY() {
        return maxY - minY + 1;
    }

    public int getLengthZ() {
        return maxZ - minZ + 1;
    }

    public long getVolume() {
        return (long) getWidthX() * (long) getHeightY() * (long) getLengthZ();
    }

    public boolean contains(BlockPos pos) {
        if (pos == null) return false;
        return contains(pos.getX(), pos.getY(), pos.getZ());
    }

    public boolean contains(int x, int y, int z) {
        return x >= minX && x <= maxX &&
               y >= minY && y <= maxY &&
               z >= minZ && z <= maxZ;
    }

    /**
     * Converts the discrete block boundary into an inclusive 3D bounding box for rendering and intersection tests.
     */
    public Box toBox() {
        return new Box(minX, minY, minZ, maxX + 1.0, maxY + 1.0, maxZ + 1.0);
    }

    public BlockPos getMinPos() {
        return new BlockPos(minX, minY, minZ);
    }

    public BlockPos getMaxPos() {
        return new BlockPos(maxX, maxY, maxZ);
    }

    public BlockPos getCenterPos() {
        return new BlockPos((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BlockRegion that)) return false;
        return minX == that.minX && minY == that.minY && minZ == that.minZ &&
               maxX == that.maxX && maxY == that.maxY && maxZ == that.maxZ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(minX, minY, minZ, maxX, maxY, maxZ);
    }

    @Override
    public String toString() {
        return String.format("[%d, %d, %d] to [%d, %d, %d] (%dx%dx%d, vol=%d)",
                minX, minY, minZ, maxX, maxY, maxZ, getWidthX(), getHeightY(), getLengthZ(), getVolume());
    }
}

