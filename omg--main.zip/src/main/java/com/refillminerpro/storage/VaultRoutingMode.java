package com.refillminerpro.storage;

import net.minecraft.text.Text;

/**
 * Routing strategy for selecting player vault destinations.
 */
public enum VaultRoutingMode {
    SEQUENTIAL_ROTATION("Sequential (1 → 7)"),
    PREFERRED_VAULT("Preferred Vault"),
    ROUND_ROBIN("Round Robin"),
    RULE_BASED("Rule-Based Routing");

    private final String displayName;

    VaultRoutingMode(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Text getText() {
        return Text.literal(displayName);
    }
}
