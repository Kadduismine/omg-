package com.refillminerpro.storage;

import java.util.ArrayList;
import java.util.List;

/**
 * Configuration for a single player vault slot (e.g. Vault 1 to 7).
 */
public class VaultSlotConfig {
    private int id; // 1 to 7
    private String command; // e.g. "/pv 1"
    private String displayName; // e.g. "Vault 1 (Ores)"
    private boolean enabled = true;
    private List<String> assignedItemIds = new ArrayList<>();

    public VaultSlotConfig() {}

    public VaultSlotConfig(int id, String command, String displayName, boolean enabled) {
        this.id = id;
        this.command = command;
        this.displayName = displayName;
        this.enabled = enabled;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCommand() {
        if (command == null || command.trim().isEmpty()) {
            return "/pv " + id;
        }
        return command.trim();
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String getDisplayName() {
        if (displayName == null || displayName.trim().isEmpty()) {
            return "Vault " + id;
        }
        return displayName.trim();
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public List<String> getAssignedItemIds() {
        if (assignedItemIds == null) {
            assignedItemIds = new ArrayList<>();
        }
        return assignedItemIds;
    }

    public void setAssignedItemIds(List<String> assignedItemIds) {
        this.assignedItemIds = assignedItemIds;
    }
}

