package com.refillminerpro.storage;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Thread-safe in-memory activity logger recording recent Auto Storage events.
 */
public class StorageActivityLogger {
    private static final int MAX_ENTRIES = 60;
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public record StorageEvent(
            String timestamp,
            String title,
            String details,
            EventSeverity severity
    ) {}

    public enum EventSeverity {
        INFO(0xFFA0A9B9),
        SUCCESS(0xFF55B88A),
        WARNING(0xFFE8B567),
        ERROR(0xFFE5767F);

        private final int color;

        EventSeverity(int color) {
            this.color = color;
        }

        public int getColor() {
            return color;
        }
    }

    private final LinkedList<StorageEvent> events = new LinkedList<>();

    public synchronized void log(String title, String details, EventSeverity severity) {
        String timestamp = LocalTime.now().format(TIME_FORMAT);
        events.addFirst(new StorageEvent(timestamp, title, details, severity));
        while (events.size() > MAX_ENTRIES) {
            events.removeLast();
        }
    }

    public synchronized List<StorageEvent> getEvents() {
        return new ArrayList<>(events);
    }

    public synchronized void clear() {
        events.clear();
    }
}

