package com.refillminerpro.storage;

import net.minecraft.text.Text;

/**
 * Filter mode for evaluating eligible inventory items for automatic storage.
 */
public enum ItemFilterMode {
    INCLUDE_ONLY("Include Selected Items Only"),
    EXCLUDE_PROTECTED("Store All Except Protected");

    private final String displayName;

    ItemFilterMode(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Text getText() {
        return Text.literal(displayName);
    }
}

