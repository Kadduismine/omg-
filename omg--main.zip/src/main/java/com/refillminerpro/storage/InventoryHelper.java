package com.refillminerpro.storage;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.*;

/**
 * Calculates inventory capacity, free slots, and item eligibility for auto storage.
 */
public class InventoryHelper {
    public static final int MAIN_STORAGE_SLOTS = 36; // Slots 0..35 (Hotbar 0..8 + Main 9..35)

    /**
     * Counts how many main storage slots (0..35) are occupied with an item stack.
     */
    public static int getOccupiedStorageSlots(PlayerInventory inventory) {
        if (inventory == null) return 0;
        int occupied = 0;
        for (int i = 0; i < MAIN_STORAGE_SLOTS; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty()) {
                occupied++;
            }
        }
        return occupied;
    }

    /**
     * Counts free slots in player main storage (0..35).
     */
    public static int getFreeStorageSlots(PlayerInventory inventory) {
        return MAIN_STORAGE_SLOTS - getOccupiedStorageSlots(inventory);
    }

    /**
     * Calculates the occupied capacity percentage of the player's main inventory (0 to 100%).
     */
    public static int getCapacityPercentage(PlayerInventory inventory) {
        int occupied = getOccupiedStorageSlots(inventory);
        return (int) Math.round((occupied / (double) MAIN_STORAGE_SLOTS) * 100.0);
    }

    /**
     * Checks if the inventory capacity or free-slot count has met the configured trigger conditions.
     */
    public static boolean isThresholdReached(PlayerInventory inventory, AutoStorageConfig config) {
        if (inventory == null || config == null || !config.isEnabled()) return false;

        int freeSlots = getFreeStorageSlots(inventory);
        if (config.isTriggerOnCompletelyFull() && freeSlots == 0) {
            return true;
        }

        int capacity = getCapacityPercentage(inventory);
        if (capacity >= config.getCapacityThresholdPercent()) {
            return true;
        }

        return freeSlots <= config.getMinFreeSlots();
    }

    /**
     * Checks if an item stack is considered protected from automatic transfer.
     */
    public static boolean isItemProtected(ItemStack stack, AutoStorageConfig config) {
        if (stack == null || stack.isEmpty()) return true;
        if (config == null) return true;

        Identifier id = Registries.ITEM.getId(stack.getItem());
        if (id == null) return true;
        String idStr = id.toString().toLowerCase();

        // Check explicit protected items list
        for (String prot : config.getProtectedItems()) {
            if (prot != null && normalizeId(prot).equalsIgnoreCase(idStr)) {
                return true;
            }
        }

        // Damageable equipment (weapons, tools, armor) is protected by default unless explicitly in storedItems
        if (stack.isDamageable()) {
            boolean explicitlyStored = false;
            for (String stored : config.getStoredItems()) {
                if (stored != null && normalizeId(stored).equalsIgnoreCase(idStr)) {
                    explicitlyStored = true;
                    break;
                }
            }
            if (!explicitlyStored) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determines whether an item stack in the player's inventory is eligible to be transferred to a vault.
     */
    public static boolean isItemEligibleToStore(ItemStack stack, AutoStorageConfig config, int totalItemCountInInventory) {
        if (stack == null || stack.isEmpty()) return false;
        if (config == null || isItemProtected(stack, config)) return false;

        if (stack.getCount() < config.getMinStackSize()) {
            return false;
        }

        Identifier id = Registries.ITEM.getId(stack.getItem());
        if (id == null) return false;
        String idStr = id.toString().toLowerCase();

        // Retain quantity check: player wants to keep at least N of this item
        int retainQty = config.getRetainQuantities().getOrDefault(idStr, 0);
        if (retainQty <= 0) {
            retainQty = config.getRetainQuantities().getOrDefault(id.getPath().toLowerCase(), 0);
        }
        if (retainQty > 0 && totalItemCountInInventory <= retainQty) {
            return false;
        }

        // Mode evaluation
        if (config.getItemFilterMode() == ItemFilterMode.INCLUDE_ONLY) {
            for (String stored : config.getStoredItems()) {
                if (stored != null && normalizeId(stored).equalsIgnoreCase(idStr)) {
                    return true;
                }
            }
            return false;
        } else {
            // EXCLUDE_PROTECTED: already verified not protected
            return true;
        }
    }

    /**
     * Returns a list of player main storage slot indices (0..35) that are eligible for storage.
     */
    public static List<Integer> getEligibleSlotIndices(PlayerInventory inventory, AutoStorageConfig config) {
        List<Integer> result = new ArrayList<>();
        if (inventory == null || config == null) return result;

        // Tally totals per item id
        Map<String, Integer> itemTotals = new HashMap<>();
        for (int i = 0; i < MAIN_STORAGE_SLOTS; i++) {
            ItemStack s = inventory.getStack(i);
            if (!s.isEmpty()) {
                Identifier id = Registries.ITEM.getId(s.getItem());
                if (id != null) {
                    itemTotals.merge(id.toString().toLowerCase(), s.getCount(), Integer::sum);
                }
            }
        }

        for (int i = 0; i < MAIN_STORAGE_SLOTS; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty()) {
                Identifier id = Registries.ITEM.getId(stack.getItem());
                int total = id != null ? itemTotals.getOrDefault(id.toString().toLowerCase(), 0) : 0;
                if (isItemEligibleToStore(stack, config, total)) {
                    result.add(i);
                }
            }
        }

        return result;
    }

    private static String normalizeId(String id) {
        if (!id.contains(":")) {
            return "minecraft:" + id.toLowerCase().trim();
        }
        return id.toLowerCase().trim();
    }
}

