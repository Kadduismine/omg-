package com.refillminerpro.storage;

import com.refillminerpro.client.RefillMinerClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Controller for automatic player-vault storage with ordered vault rotation (/pv 1 -> /pv 7),
 * capacity detection, auto-resume, and completion notification.
 *
 * State Machine Lifecycle:
 * MINING -> INVENTORY_CHECK -> MINING_PAUSED -> OPEN_VAULT -> WAITING_FOR_SCREEN -> DEPOSIT_SELECTED_ITEMS
 * -> VERIFY_STORAGE -> CHECK_INVENTORY
 * If more space needed: CHECK_INVENTORY -> OPEN_NEXT_VAULT -> OPEN_VAULT -> DEPOSIT_SELECTED_ITEMS
 * If sufficient space freed: CHECK_INVENTORY -> CLOSING -> RESUME_MINING
 * If all 7 vaults full: CHECK_INVENTORY -> COMPLETED_ALL_VAULTS ("Kiiuwt Da Work Is Complete")
 */
public class AutoStorageEngine {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/AutoStorage");

    private final AutoStorageConfig config;
    private final StorageActivityLogger activityLogger;

    private StorageState state = StorageState.IDLE;
    private Text statusDetail = Text.literal("Auto Storage idle.").formatted(Formatting.GRAY);

    private int stateTicks = 0;
    private int cooldownTicks = 0;
    private int transferDelayCountdown = 0;
    private int screenWaitCountdown = 0;
    private int verifyCountdown = 0;

    private int consecutiveFailures = 0;
    private static final int MAX_CONSECUTIVE_FAILURES = 2;

    private int currentVaultNumber = 1; // 1 to 7
    private final Set<Integer> vaultsFullInCurrentRun = new HashSet<>();
    private final Set<Integer> attemptedPlayerSlotsInCurrentVault = new HashSet<>();

    private ScreenHandler currentScreenHandler = null;
    private int lastTransferredSlotIndex = -1;
    private ItemStack lastTransferredStackBefore = null;
    private int totalItemsTransferredInRun = 0;

    private boolean allVaultsCompleted = false;

    public AutoStorageEngine(AutoStorageConfig config, StorageActivityLogger activityLogger) {
        this.config = config;
        this.activityLogger = activityLogger;
    }

    public StorageState getState() {
        return state;
    }

    public Text getStatusDetail() {
        return statusDetail;
    }

    public StorageActivityLogger getActivityLogger() {
        return activityLogger;
    }

    public boolean isBusy() {
        return state != StorageState.IDLE
                && state != StorageState.PAUSED
                && state != StorageState.COMPLETE
                && state != StorageState.COMPLETED_ALL_VAULTS
                && state != StorageState.ERROR;
    }

    public boolean isAllVaultsCompleted() {
        return allVaultsCompleted;
    }

    public void resetAllVaultsCompleted() {
        this.allVaultsCompleted = false;
    }

    public int getCurrentVaultNumber() {
        return currentVaultNumber;
    }

    public int getTotalItemsTransferredInRun() {
        return totalItemsTransferredInRun;
    }

    /**
     * Manual trigger from GUI button "Instant Auto Store Now".
     */
    public void triggerManualTest(MinecraftClient client, int vaultIndex) {
        startStorageWorkflow(client);
    }

    /**
     * Entry point to begin the automatic storage process when inventory is full.
     */
    public void startStorageWorkflow(MinecraftClient client) {
        if (client == null || client.player == null) return;
        if (!config.isEnabled() || config.isPaused()) return;
        if (isBusy()) return;

        List<Integer> eligibleSlots = InventoryHelper.getEligibleSlotIndices(client.player.getInventory(), config);
        if (eligibleSlots.isEmpty()) {
            cooldownTicks = 60;
            statusDetail = Text.literal("Inventory full but no selected items to store.").formatted(Formatting.YELLOW);
            activityLogger.log("Threshold Reached", "Inventory full but no selected items to store.", StorageActivityLogger.EventSeverity.WARNING);

            // Notify player and safely pause mining so items are not dropped
            RefillMinerClient clientInstance = RefillMinerClient.getInstance();
            if (clientInstance != null && clientInstance.getConfig().isAutoMineEnabled()) {
                clientInstance.getConfig().setAutoMineEnabled(false);
                clientInstance.getMiningEngine().cancelCurrentMining(client);
                client.player.sendMessage(Text.literal("§c[Refill Miner Pro] Auto Mine Paused: Inventory reached full threshold, but contains no items eligible for Auto Store. Clear unselected items to continue."), false);
            }
            return;
        }

        int capacity = InventoryHelper.getCapacityPercentage(client.player.getInventory());
        int free = InventoryHelper.getFreeStorageSlots(client.player.getInventory());
        activityLogger.log("Threshold Reached", String.format("Capacity: %d%% (%d free slots), %d eligible stacks detected.", capacity, free, eligibleSlots.size()), StorageActivityLogger.EventSeverity.INFO);

        totalItemsTransferredInRun = 0;
        vaultsFullInCurrentRun.clear();
        attemptedPlayerSlotsInCurrentVault.clear();
        currentVaultNumber = config.getFirstVault();
        allVaultsCompleted = false;
        stateTicks = 0;

        // Pause mining immediately
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance != null) {
            clientInstance.getMiningEngine().cancelCurrentMining(client);
            clientInstance.getMiningEngine().stopWalking(client);
            clientInstance.getMiningEngine().stopAttacking(client);
            clientInstance.getMiningEngine().getRotationController().clearTarget();
        }

        if (config.getTriggerDelayTicks() > 0) {
            state = StorageState.MINING_PAUSED;
            statusDetail = Text.literal(String.format("Storage triggering in %d ticks...", config.getTriggerDelayTicks())).formatted(Formatting.YELLOW);
        } else {
            openVault(client, currentVaultNumber);
        }
    }

    public void tick(MinecraftClient client) {
        if (client == null || client.world == null || client.player == null) {
            return;
        }

        if (!config.isEnabled()) {
            if (state != StorageState.IDLE) {
                reset();
            }
            return;
        }

        if (config.isPaused()) {
            if (state != StorageState.PAUSED) {
                state = StorageState.PAUSED;
                statusDetail = Text.literal("Auto Storage paused.").formatted(Formatting.YELLOW);
            }
            return;
        } else if (state == StorageState.PAUSED) {
            state = StorageState.IDLE;
        }

        if (cooldownTicks > 0) {
            cooldownTicks--;
            return;
        }

        stateTicks++;
        ClientPlayerEntity player = client.player;
        ClientPlayerInteractionManager interactionManager = client.interactionManager;

        switch (state) {
            case IDLE -> handleIdle(client, player);
            case INVENTORY_CHECK -> handleInventoryCheck(client, player);
            case MINING_PAUSED -> handleMiningPaused(client, player);
            case OPEN_VAULT, SELECTING_VAULT -> openVault(client, currentVaultNumber);
            case WAITING_FOR_SCREEN -> handleWaitingForScreen(client, player);
            case DEPOSIT_SELECTED_ITEMS, TRANSFERRING -> handleDepositSelectedItems(client, player, interactionManager);
            case VERIFY_STORAGE, VERIFYING -> handleVerifyStorage(client, player);
            case CHECK_INVENTORY -> handleCheckInventory(client, player);
            case OPEN_NEXT_VAULT -> handleOpenNextVault(client, player);
            case CLOSING -> handleClosing(client, player);
            case RESUME_MINING -> handleResumeMining(client, player);
            case COMPLETED_ALL_VAULTS -> handleCompletedAllVaults(client, player);
            case COMPLETE -> handleComplete();
            case ERROR -> handleError(client, player);
        }
    }

    private void handleIdle(MinecraftClient client, ClientPlayerEntity player) {
        // Pause if player is in non-handled screen (like settings, pause, chat)
        if (client.currentScreen != null && !(client.currentScreen instanceof HandledScreen)) {
            return;
        }

        // Pause if player is viewing another container
        if (config.isPauseOnContainers() && client.currentScreen instanceof HandledScreen) {
            return;
        }

        // Check if capacity trigger threshold is reached
        boolean triggered = InventoryHelper.isThresholdReached(player.getInventory(), config);
        if (!triggered) {
            return;
        }

        if (allVaultsCompleted) {
            return;
        }

        startStorageWorkflow(client);
    }

    private void handleMiningPaused(MinecraftClient client, ClientPlayerEntity player) {
        if (stateTicks >= config.getTriggerDelayTicks()) {
            openVault(client, currentVaultNumber);
            stateTicks = 0;
        }
    }

    private void handleInventoryCheck(MinecraftClient client, ClientPlayerEntity player) {
        if (stateTicks >= config.getTriggerDelayTicks()) {
            openVault(client, currentVaultNumber);
            stateTicks = 0;
        }
    }

    private void openVault(MinecraftClient client, int vaultNum) {
        if (client == null || client.player == null) return;
        currentVaultNumber = Math.max(1, Math.min(7, vaultNum));
        attemptedPlayerSlotsInCurrentVault.clear();

        // Resolve command for current vault
        String cmd = "/pv " + currentVaultNumber;
        List<VaultSlotConfig> slots = config.getVaultSlots();
        if (slots != null) {
            for (VaultSlotConfig vsc : slots) {
                if (vsc.getId() == currentVaultNumber) {
                    cmd = vsc.getCommand();
                    break;
                }
            }
        }

        String cleanCmd = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        activityLogger.log("Requesting Vault", String.format("Opening Vault %d: /%s", currentVaultNumber, cleanCmd), StorageActivityLogger.EventSeverity.INFO);
        statusDetail = Text.literal(String.format("Opening Vault %d (/%s)...", currentVaultNumber, cleanCmd)).formatted(Formatting.AQUA);

        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendChatCommand(cleanCmd);
        }

        screenWaitCountdown = 60; // 3 seconds timeout
        state = StorageState.WAITING_FOR_SCREEN;
        stateTicks = 0;
    }

    private void handleWaitingForScreen(MinecraftClient client, ClientPlayerEntity player) {
        if (client.currentScreen instanceof HandledScreen<?> handled) {
            ScreenHandler handler = handled.getScreenHandler();
            // Container screens have more than the player's 36 slots
            if (handler != null && handler.slots.size() > 36) {
                currentScreenHandler = handler;
                consecutiveFailures = 0;
                activityLogger.log("Vault Connected", String.format("Vault %d (%s) opened successfully.", currentVaultNumber, handled.getTitle().getString()), StorageActivityLogger.EventSeverity.SUCCESS);
                statusDetail = Text.literal(String.format("Vault %d open. Storing items...", currentVaultNumber)).formatted(Formatting.BLUE);
                transferDelayCountdown = config.getTransferDelayTicks();
                state = StorageState.DEPOSIT_SELECTED_ITEMS;
                stateTicks = 0;
                return;
            }
        }

        screenWaitCountdown--;
        if (screenWaitCountdown <= 0) {
            consecutiveFailures++;
            activityLogger.log("Timeout", "Vault " + currentVaultNumber + " failed to open.", StorageActivityLogger.EventSeverity.ERROR);
            config.setLastResult("Failed: Vault " + currentVaultNumber + " did not open.");
            config.setLastOperationSuccess(false);
            config.setLastResultTimestamp(System.currentTimeMillis());

            if (player != null && client.currentScreen instanceof HandledScreen) {
                player.closeHandledScreen();
            }

            if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                config.setPaused(true);
                statusDetail = Text.literal("Auto Storage paused: Vault command timed out.").formatted(Formatting.RED);
                activityLogger.log("Storage Paused", "Vault commands failed to open container. Pausing to prevent kicks.", StorageActivityLogger.EventSeverity.ERROR);
                if (player != null) {
                    player.sendMessage(Text.literal("§c[Refill Miner Pro] Auto Store: Vault " + currentVaultNumber + " failed to open. Auto Storage paused."), false);
                }
                state = StorageState.ERROR;
                cooldownTicks = 200;
            } else {
                state = StorageState.ERROR;
                statusDetail = Text.literal("Failed: Vault " + currentVaultNumber + " did not open.").formatted(Formatting.RED);
                if (player != null) {
                    player.sendMessage(Text.literal("§c[Refill Miner Pro] Auto Store: Vault " + currentVaultNumber + " did not open."), false);
                }
                cooldownTicks = 100;
            }
        }
    }

    private void handleDepositSelectedItems(MinecraftClient client, ClientPlayerEntity player, ClientPlayerInteractionManager interactionManager) {
        if (client.currentScreen == null || client.player == null || client.player.currentScreenHandler != currentScreenHandler) {
            activityLogger.log("Screen Closed", "Vault screen closed during deposit.", StorageActivityLogger.EventSeverity.WARNING);
            state = StorageState.CLOSING;
            return;
        }

        if (transferDelayCountdown > 0) {
            transferDelayCountdown--;
            return;
        }

        int totalSlots = currentScreenHandler.slots.size();
        int playerStartSlot = totalSlots - 36; // slots 0 .. playerStartSlot-1 are vault slots

        // Count empty slots in the active vault screen
        int emptyVaultSlots = 0;
        for (int i = 0; i < playerStartSlot; i++) {
            Slot s = currentScreenHandler.getSlot(i);
            if (s == null || !s.hasStack() || s.getStack().isEmpty()) {
                emptyVaultSlots++;
            }
        }

        // Tally totals in player inventory
        Map<String, Integer> itemTotals = new HashMap<>();
        for (int i = playerStartSlot; i < totalSlots; i++) {
            Slot s = currentScreenHandler.getSlot(i);
            if (s != null && s.hasStack()) {
                net.minecraft.util.Identifier id = net.minecraft.registry.Registries.ITEM.getId(s.getStack().getItem());
                if (id != null) {
                    itemTotals.merge(id.toString().toLowerCase(), s.getStack().getCount(), Integer::sum);
                }
            }
        }

        int targetSlot = -1;
        ItemStack targetStack = null;

        // Search player slots for next eligible item stack
        for (int i = playerStartSlot; i < totalSlots; i++) {
            int playerInvIndex = i - playerStartSlot;
            if (attemptedPlayerSlotsInCurrentVault.contains(playerInvIndex)) {
                continue;
            }

            Slot slot = currentScreenHandler.getSlot(i);
            if (slot != null && slot.hasStack()) {
                ItemStack stack = slot.getStack();
                net.minecraft.util.Identifier id = net.minecraft.registry.Registries.ITEM.getId(stack.getItem());
                int totalCount = id != null ? itemTotals.getOrDefault(id.toString().toLowerCase(), 0) : 0;

                if (InventoryHelper.isItemEligibleToStore(stack, config, totalCount)) {
                    // Check if vault can accept this stack
                    boolean canFit = (emptyVaultSlots > 0);
                    if (!canFit) {
                        // Check if compatible partial stack exists in vault slots
                        for (int j = 0; j < playerStartSlot; j++) {
                            Slot vaultSlot = currentScreenHandler.getSlot(j);
                            if (vaultSlot != null && vaultSlot.hasStack()) {
                                ItemStack vStack = vaultSlot.getStack();
                                if (ItemStack.areItemsAndComponentsEqual(vStack, stack) && vStack.getCount() < vStack.getMaxCount()) {
                                    canFit = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (canFit) {
                        targetSlot = i;
                        targetStack = stack.copy();
                        break;
                    } else {
                        // This vault cannot accommodate this stack; mark attempted
                        attemptedPlayerSlotsInCurrentVault.add(playerInvIndex);
                    }
                }
            }
        }

        if (targetSlot != -1) {
            lastTransferredSlotIndex = targetSlot;
            lastTransferredStackBefore = targetStack;

            // Perform shift-click quick move transfer into the vault
            interactionManager.clickSlot(currentScreenHandler.syncId, targetSlot, 0, SlotActionType.QUICK_MOVE, player);

            verifyCountdown = Math.max(2, config.getTransferDelayTicks());
            state = StorageState.VERIFY_STORAGE;
        } else {
            // No more eligible items can fit into this vault
            state = StorageState.CHECK_INVENTORY;
        }
    }

    private void handleVerifyStorage(MinecraftClient client, ClientPlayerEntity player) {
        if (verifyCountdown > 0) {
            verifyCountdown--;
            return;
        }

        if (currentScreenHandler == null || lastTransferredSlotIndex < 0 || lastTransferredSlotIndex >= currentScreenHandler.slots.size()) {
            state = StorageState.CHECK_INVENTORY;
            return;
        }

        Slot slot = currentScreenHandler.getSlot(lastTransferredSlotIndex);
        ItemStack currentStack = slot != null ? slot.getStack() : null;

        boolean stackChanged = (currentStack == null || currentStack.isEmpty())
                || (lastTransferredStackBefore != null && (currentStack.getCount() < lastTransferredStackBefore.getCount() || !ItemStack.areItemsEqual(currentStack, lastTransferredStackBefore)));

        int playerInvIndex = lastTransferredSlotIndex - (currentScreenHandler.slots.size() - 36);

        if (stackChanged) {
            int moved = lastTransferredStackBefore.getCount() - (currentStack.isEmpty() ? 0 : currentStack.getCount());
            int transferred = moved > 0 ? moved : lastTransferredStackBefore.getCount();
            totalItemsTransferredInRun += transferred;

            activityLogger.log("Item Stored", String.format("Transferred %dx %s to Vault %d", transferred, lastTransferredStackBefore.getName().getString(), currentVaultNumber), StorageActivityLogger.EventSeverity.INFO);
            statusDetail = Text.literal(String.format("Vault %d: Stored %dx %s", currentVaultNumber, transferred, lastTransferredStackBefore.getName().getString())).formatted(Formatting.GREEN);

            transferDelayCountdown = config.getTransferDelayTicks();
            state = StorageState.DEPOSIT_SELECTED_ITEMS;
        } else {
            // Item did not move: current vault rejected or full for this item
            attemptedPlayerSlotsInCurrentVault.add(playerInvIndex);
            activityLogger.log("Vault Slot Skipped", String.format("Vault %d could not accept %s at slot %d.", currentVaultNumber, lastTransferredStackBefore.getName().getString(), playerInvIndex), StorageActivityLogger.EventSeverity.WARNING);
            statusDetail = Text.literal(String.format("Vault %d cannot fit %s.", currentVaultNumber, lastTransferredStackBefore.getName().getString())).formatted(Formatting.YELLOW);

            transferDelayCountdown = 1;
            state = StorageState.DEPOSIT_SELECTED_ITEMS;
        }
    }

    private void handleCheckInventory(MinecraftClient client, ClientPlayerEntity player) {
        if (player == null) {
            state = StorageState.CLOSING;
            return;
        }

        int freeSlots = InventoryHelper.getFreeStorageSlots(player.getInventory());
        List<Integer> remainingEligible = InventoryHelper.getEligibleSlotIndices(player.getInventory(), config);

        // Check if any eligible slots have not yet been attempted in current vault
        int unattemptedInCurrent = 0;
        for (int slotIdx : remainingEligible) {
            if (!attemptedPlayerSlotsInCurrentVault.contains(slotIdx)) {
                unattemptedInCurrent++;
            }
        }

        if (unattemptedInCurrent > 0) {
            // More items can be attempted in current vault
            state = StorageState.DEPOSIT_SELECTED_ITEMS;
            return;
        }

        // Current vault is exhausted for the player's remaining selected items
        vaultsFullInCurrentRun.add(currentVaultNumber);
        activityLogger.log("Vault Capacity Reached", String.format("Vault %d cannot accommodate any more remaining selected items.", currentVaultNumber), StorageActivityLogger.EventSeverity.INFO);

        // If there are still remaining eligible items to store:
        if (!remainingEligible.isEmpty()) {
            if (currentVaultNumber < config.getLastVault()) {
                // Advance sequentially to next vault: pv 1 -> pv 2 -> ... -> pv 7
                activityLogger.log("Advancing Vault", String.format("Vault %d full/exhausted. Advancing to Vault %d.", currentVaultNumber, currentVaultNumber + 1), StorageActivityLogger.EventSeverity.INFO);
                statusDetail = Text.literal(String.format("Vault %d full. Switching to Vault %d...", currentVaultNumber, currentVaultNumber + 1)).formatted(Formatting.AQUA);
                state = StorageState.OPEN_NEXT_VAULT;
                return;
            } else {
                // All vaults through last vault (7) have been checked and cannot fit remaining selected items!
                activityLogger.log("All Vaults Full", String.format("All vaults (%d through %d) checked and full.", config.getFirstVault(), config.getLastVault()), StorageActivityLogger.EventSeverity.WARNING);
                state = StorageState.COMPLETED_ALL_VAULTS;
                return;
            }
        }

        // All selected items were stored! Check if enough space is freed:
        if (freeSlots > config.getMinFreeSlots()) {
            state = StorageState.CLOSING;
        } else {
            // Inventory still full of unselected items
            activityLogger.log("Inventory Full", "All selected items stored, but inventory is still full of unselected items.", StorageActivityLogger.EventSeverity.WARNING);
            RefillMinerClient clientInstance = RefillMinerClient.getInstance();
            if (clientInstance != null && clientInstance.getConfig().isAutoMineEnabled()) {
                clientInstance.getConfig().setAutoMineEnabled(false);
                clientInstance.getMiningEngine().cancelCurrentMining(client);
                player.sendMessage(Text.literal("§c[Refill Miner Pro] Auto Mine Paused: Inventory still full of unselected items. Clear space manually."), false);
            }
            state = StorageState.CLOSING;
        }
    }

    private void handleOpenNextVault(MinecraftClient client, ClientPlayerEntity player) {
        if (player != null && client.currentScreen instanceof HandledScreen) {
            player.closeHandledScreen();
        }
        currentVaultNumber++;
        attemptedPlayerSlotsInCurrentVault.clear();
        currentScreenHandler = null;
        cooldownTicks = 10; // 0.5s pause between container screens for clean network sync
        state = StorageState.OPEN_VAULT;
    }

    private void handleClosing(MinecraftClient client, ClientPlayerEntity player) {
        if (player != null && client.currentScreen instanceof HandledScreen) {
            player.closeHandledScreen();
        }
        currentScreenHandler = null;

        String summary = String.format("Stored %d items across vaults.", totalItemsTransferredInRun);
        activityLogger.log("Storage Complete", summary, StorageActivityLogger.EventSeverity.SUCCESS);
        config.setLastResult(summary);
        config.setLastOperationSuccess(true);
        config.setLastResultTimestamp(System.currentTimeMillis());

        cooldownTicks = 6; // Brief sync delay
        if (config.isResumeMiningAutomatically()) {
            state = StorageState.RESUME_MINING;
            statusDetail = Text.literal("Synchronizing inventory...").formatted(Formatting.AQUA);
        } else {
            statusDetail = Text.literal(summary).formatted(Formatting.GREEN);
            state = StorageState.COMPLETE;
        }
    }

    private void handleResumeMining(MinecraftClient client, ClientPlayerEntity player) {
        if (client.currentScreen instanceof HandledScreen) {
            return; // Wait until screen is closed
        }

        int free = InventoryHelper.getFreeStorageSlots(player.getInventory());
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();

        if (free > config.getMinFreeSlots() && clientInstance != null && clientInstance.getConfig().isAutoMineEnabled()) {
            clientInstance.getMiningEngine().resumeFromAutoStorage(client);
            statusDetail = Text.literal(String.format("Resumed mining (%d free slots).", free)).formatted(Formatting.GREEN);
            player.sendMessage(Text.literal(String.format("§a[Refill Miner Pro] Auto Store complete (%d items deposited). Resumed auto-mining.", totalItemsTransferredInRun)), false);
        } else {
            statusDetail = Text.literal(String.format("Storage complete (%d free slots).", free)).formatted(Formatting.GREEN);
        }

        reset();
    }

    private void handleCompletedAllVaults(MinecraftClient client, ClientPlayerEntity player) {
        if (player != null && client.currentScreen instanceof HandledScreen) {
            player.closeHandledScreen();
        }
        currentScreenHandler = null;

        // Permanently stop auto-mining
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance != null) {
            clientInstance.getConfig().setAutoMineEnabled(false);
            clientInstance.getMiningEngine().cancelCurrentMining(client);
            clientInstance.getMiningEngine().stopWalking(client);
            clientInstance.getMiningEngine().stopAttacking(client);
            clientInstance.getMiningEngine().getRotationController().clearTarget();
            clientInstance.getConfigManager().save();
        }

        allVaultsCompleted = true;
        statusDetail = Text.literal("Kiiuwt Da Work Is Complete").formatted(Formatting.GOLD, Formatting.BOLD);
        activityLogger.log("All Vaults Full", "Kiiuwt Da Work Is Complete", StorageActivityLogger.EventSeverity.SUCCESS);

        if (config.isCompletionNotification()) {
            Text completionTitle = Text.literal("Kiiuwt Da Work Is Complete").formatted(Formatting.GOLD, Formatting.BOLD);
            if (client.inGameHud != null) {
                client.inGameHud.setTitle(completionTitle);
                client.inGameHud.setTitleTicks(10, 80, 20);
                client.inGameHud.setOverlayMessage(completionTitle, false);
            }
            if (player != null) {
                player.sendMessage(Text.literal("§6§l[Refill Miner Pro] §eKiiuwt Da Work Is Complete"), false);
                if (clientInstance != null) {
                    clientInstance.playCompletionSound();
                }
            }
        }

        state = StorageState.COMPLETE;
        cooldownTicks = 100;
    }

    private void handleComplete() {
        reset();
    }

    private void handleError(MinecraftClient client, ClientPlayerEntity player) {
        if (player != null && client.currentScreen instanceof HandledScreen) {
            player.closeHandledScreen();
        }
        reset();
    }

    public void reset() {
        state = StorageState.IDLE;
        statusDetail = Text.literal("Auto Storage idle.").formatted(Formatting.GRAY);
        currentScreenHandler = null;
        lastTransferredSlotIndex = -1;
        lastTransferredStackBefore = null;
        stateTicks = 0;
        screenWaitCountdown = 0;
        transferDelayCountdown = 0;
        verifyCountdown = 0;
        vaultsFullInCurrentRun.clear();
        attemptedPlayerSlotsInCurrentVault.clear();
    }

    public void fullReset() {
        reset();
        consecutiveFailures = 0;
        cooldownTicks = 0;
        allVaultsCompleted = false;
        totalItemsTransferredInRun = 0;
    }
}
