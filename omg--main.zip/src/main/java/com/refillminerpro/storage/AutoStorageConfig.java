package com.refillminerpro.storage;

import java.util.*;

/**
 * Complete configuration data for Refill Miner Pro Auto Storage.
 */
public class AutoStorageConfig {
    private boolean enabled = false;
    private boolean paused = false;

    // Trigger & Thresholds
    private int capacityThresholdPercent = 90; // Default 90%
    private int minFreeSlots = 1;
    private boolean triggerOnCompletelyFull = true;
    private int triggerDelayTicks = 10; // 0.5s delay before running
    private int transferDelayTicks = 2; // ~100ms human delay between slot moves
    private boolean pauseOnContainers = true;

    // Vault Rotation (Default: /pv 1 -> /pv 2 -> ... -> /pv 7)
    private int firstVault = 1;
    private int lastVault = 7;
    private boolean resumeMiningAutomatically = true;
    private boolean completionNotification = true;

    // Item Selection
    private ItemFilterMode itemFilterMode = ItemFilterMode.INCLUDE_ONLY;
    private List<String> storedItems = new ArrayList<>();
    private List<String> protectedItems = new ArrayList<>();
    private int minStackSize = 1;
    private Map<String, Integer> retainQuantities = new HashMap<>();

    // Vaults
    private VaultRoutingMode routingMode = VaultRoutingMode.SEQUENTIAL_ROTATION;
    private int preferredVaultIndex = 0; // 0..6
    private List<VaultSlotConfig> vaultSlots = new ArrayList<>();

    // Last status result
    private String lastResult = "No storage operation executed yet.";
    private long lastResultTimestamp = 0;
    private boolean lastOperationSuccess = false;

    public AutoStorageConfig() {
        initDefaults();
    }

    public void initDefaults() {
        if (vaultSlots == null || vaultSlots.isEmpty()) {
            vaultSlots = new ArrayList<>();
            vaultSlots.add(new VaultSlotConfig(1, "/pv 1", "Vault 1 (Main)", true));
            vaultSlots.add(new VaultSlotConfig(2, "/pv 2", "Vault 2 (Ores)", true));
            vaultSlots.add(new VaultSlotConfig(3, "/pv 3", "Vault 3 (Blocks)", true));
            vaultSlots.add(new VaultSlotConfig(4, "/pv 4", "Vault 4", true));
            vaultSlots.add(new VaultSlotConfig(5, "/pv 5", "Vault 5", true));
            vaultSlots.add(new VaultSlotConfig(6, "/pv 6", "Vault 6", true));
            vaultSlots.add(new VaultSlotConfig(7, "/pv 7", "Vault 7", true));
        }

        if (protectedItems == null || protectedItems.isEmpty()) {
            protectedItems = new ArrayList<>(List.of(
                    "minecraft:diamond_pickaxe",
                    "minecraft:netherite_pickaxe",
                    "minecraft:iron_pickaxe",
                    "minecraft:golden_pickaxe",
                    "minecraft:stone_pickaxe",
                    "minecraft:wooden_pickaxe",
                    "minecraft:diamond_sword",
                    "minecraft:netherite_sword",
                    "minecraft:iron_sword",
                    "minecraft:diamond_axe",
                    "minecraft:netherite_axe",
                    "minecraft:iron_axe",
                    "minecraft:diamond_shovel",
                    "minecraft:netherite_shovel",
                    "minecraft:iron_shovel",
                    "minecraft:bread",
                    "minecraft:cooked_beef",
                    "minecraft:cooked_porkchop",
                    "minecraft:golden_carrot",
                    "minecraft:totem_of_undying",
                    "minecraft:water_bucket",
                    "minecraft:torch"
            ));
        }

        if (storedItems == null || storedItems.isEmpty()) {
            storedItems = new ArrayList<>(List.of(
                    "minecraft:cobblestone",
                    "minecraft:stone",
                    "minecraft:deepslate",
                    "minecraft:cobbled_deepslate",
                    "minecraft:granite",
                    "minecraft:diorite",
                    "minecraft:andesite",
                    "minecraft:tuff",
                    "minecraft:gravel",
                    "minecraft:dirt",
                    "minecraft:sand",
                    "minecraft:raw_iron",
                    "minecraft:raw_gold",
                    "minecraft:raw_copper",
                    "minecraft:coal",
                    "minecraft:diamond",
                    "minecraft:emerald",
                    "minecraft:redstone",
                    "minecraft:lapis_lazuli"
            ));
        }

        if (retainQuantities == null) {
            retainQuantities = new HashMap<>();
        }

        if (firstVault < 1) firstVault = 1;
        if (firstVault > 7) firstVault = 7;
        if (lastVault < firstVault) lastVault = firstVault;
        if (lastVault > 7) lastVault = 7;
    }

    public void validate() {
        if (capacityThresholdPercent < 50) capacityThresholdPercent = 50;
        if (capacityThresholdPercent > 100) capacityThresholdPercent = 100;
        if (minFreeSlots < 0) minFreeSlots = 0;
        if (minFreeSlots > 10) minFreeSlots = 10;
        if (triggerDelayTicks < 0) triggerDelayTicks = 0;
        if (triggerDelayTicks > 100) triggerDelayTicks = 100;
        if (transferDelayTicks < 1) transferDelayTicks = 1;
        if (transferDelayTicks > 20) transferDelayTicks = 20;
        if (minStackSize < 1) minStackSize = 1;

        if (firstVault < 1) firstVault = 1;
        if (firstVault > 7) firstVault = 7;
        if (lastVault < firstVault) lastVault = firstVault;
        if (lastVault > 7) lastVault = 7;

        if (vaultSlots == null || vaultSlots.size() < 7) {
            initDefaults();
        }

        if (preferredVaultIndex < 0 || preferredVaultIndex >= vaultSlots.size()) {
            preferredVaultIndex = 0;
        }

        if (itemFilterMode == null) {
            itemFilterMode = ItemFilterMode.INCLUDE_ONLY;
        }

        if (routingMode == null) {
            routingMode = VaultRoutingMode.SEQUENTIAL_ROTATION;
        }
    }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public boolean isPaused() { return paused; }
    public void setPaused(boolean paused) { this.paused = paused; }

    public int getCapacityThresholdPercent() { return capacityThresholdPercent; }
    public void setCapacityThresholdPercent(int capacityThresholdPercent) { this.capacityThresholdPercent = capacityThresholdPercent; }

    public int getMinFreeSlots() { return minFreeSlots; }
    public void setMinFreeSlots(int minFreeSlots) { this.minFreeSlots = minFreeSlots; }

    public boolean isTriggerOnCompletelyFull() { return triggerOnCompletelyFull; }
    public void setTriggerOnCompletelyFull(boolean triggerOnCompletelyFull) { this.triggerOnCompletelyFull = triggerOnCompletelyFull; }

    public int getFirstVault() { return firstVault; }
    public void setFirstVault(int firstVault) {
        this.firstVault = Math.max(1, Math.min(7, firstVault));
        if (this.lastVault < this.firstVault) {
            this.lastVault = this.firstVault;
        }
    }

    public int getLastVault() { return lastVault; }
    public void setLastVault(int lastVault) {
        this.lastVault = Math.max(this.firstVault, Math.min(7, lastVault));
    }

    public boolean isResumeMiningAutomatically() { return resumeMiningAutomatically; }
    public void setResumeMiningAutomatically(boolean resumeMiningAutomatically) { this.resumeMiningAutomatically = resumeMiningAutomatically; }

    public boolean isCompletionNotification() { return completionNotification; }
    public void setCompletionNotification(boolean completionNotification) { this.completionNotification = completionNotification; }

    public int getTriggerDelayTicks() { return triggerDelayTicks; }
    public void setTriggerDelayTicks(int triggerDelayTicks) { this.triggerDelayTicks = triggerDelayTicks; }

    public int getTransferDelayTicks() { return transferDelayTicks; }
    public void setTransferDelayTicks(int transferDelayTicks) { this.transferDelayTicks = transferDelayTicks; }

    public boolean isPauseOnContainers() { return pauseOnContainers; }
    public void setPauseOnContainers(boolean pauseOnContainers) { this.pauseOnContainers = pauseOnContainers; }

    public ItemFilterMode getItemFilterMode() { return itemFilterMode != null ? itemFilterMode : ItemFilterMode.INCLUDE_ONLY; }
    public void setItemFilterMode(ItemFilterMode itemFilterMode) { this.itemFilterMode = itemFilterMode; }

    public List<String> getStoredItems() {
        if (storedItems == null) storedItems = new ArrayList<>();
        return storedItems;
    }
    public void setStoredItems(List<String> storedItems) { this.storedItems = storedItems; }

    public List<String> getProtectedItems() {
        if (protectedItems == null) protectedItems = new ArrayList<>();
        return protectedItems;
    }
    public void setProtectedItems(List<String> protectedItems) { this.protectedItems = protectedItems; }

    public int getMinStackSize() { return minStackSize; }
    public void setMinStackSize(int minStackSize) { this.minStackSize = minStackSize; }

    public Map<String, Integer> getRetainQuantities() {
        if (retainQuantities == null) retainQuantities = new HashMap<>();
        return retainQuantities;
    }
    public void setRetainQuantities(Map<String, Integer> retainQuantities) { this.retainQuantities = retainQuantities; }

    public VaultRoutingMode getRoutingMode() { return routingMode != null ? routingMode : VaultRoutingMode.SEQUENTIAL_ROTATION; }
    public void setRoutingMode(VaultRoutingMode routingMode) { this.routingMode = routingMode; }

    public int getPreferredVaultIndex() { return preferredVaultIndex; }
    public void setPreferredVaultIndex(int preferredVaultIndex) { this.preferredVaultIndex = preferredVaultIndex; }

    public List<VaultSlotConfig> getVaultSlots() {
        if (vaultSlots == null || vaultSlots.isEmpty()) initDefaults();
        return vaultSlots;
    }
    public void setVaultSlots(List<VaultSlotConfig> vaultSlots) { this.vaultSlots = vaultSlots; }

    public String getLastResult() { return lastResult != null ? lastResult : "None"; }
    public void setLastResult(String lastResult) { this.lastResult = lastResult; }

    public long getLastResultTimestamp() { return lastResultTimestamp; }
    public void setLastResultTimestamp(long lastResultTimestamp) { this.lastResultTimestamp = lastResultTimestamp; }

    public boolean isLastOperationSuccess() { return lastOperationSuccess; }
    public void setLastOperationSuccess(boolean lastOperationSuccess) { this.lastOperationSuccess = lastOperationSuccess; }
}
