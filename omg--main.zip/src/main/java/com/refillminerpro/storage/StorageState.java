package com.refillminerpro.storage;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * State machine states for the Auto Storage lifecycle.
 * MINING -> INVENTORY_CHECK -> MINING_PAUSED -> OPEN_VAULT -> DEPOSIT_SELECTED_ITEMS -> VERIFY_STORAGE -> CHECK_INVENTORY
 * If more space needed: CHECK_INVENTORY -> OPEN_NEXT_VAULT -> DEPOSIT_SELECTED_ITEMS
 * If sufficient space freed: CHECK_INVENTORY -> CLOSING -> RESUME_MINING
 * If all 7 vaults full: CHECK_ALL_VAULTS -> COMPLETED_ALL_VAULTS
 */
public enum StorageState {
    IDLE("Idle", Formatting.GRAY),
    INVENTORY_CHECK("Checking Inventory", Formatting.YELLOW),
    MINING_PAUSED("Mining Paused", Formatting.GOLD),
    OPEN_VAULT("Opening Vault", Formatting.AQUA),
    WAITING_FOR_SCREEN("Opening Vault Screen", Formatting.GOLD),
    DEPOSIT_SELECTED_ITEMS("Depositing Items", Formatting.BLUE),
    VERIFY_STORAGE("Verifying Deposit", Formatting.LIGHT_PURPLE),
    CHECK_INVENTORY("Checking Capacity", Formatting.AQUA),
    OPEN_NEXT_VAULT("Switching Vault", Formatting.AQUA),
    CLOSING("Closing Vault", Formatting.YELLOW),
    RESUME_MINING("Resuming Mining", Formatting.GREEN),
    COMPLETED_ALL_VAULTS("All Vaults Full", Formatting.GREEN),
    PAUSED("Paused", Formatting.YELLOW),
    ERROR("Storage Error", Formatting.RED),

    // Backward-compatible aliases
    SELECTING_VAULT("Selecting Vault", Formatting.AQUA),
    TRANSFERRING("Depositing Items", Formatting.BLUE),
    VERIFYING("Verifying Deposit", Formatting.LIGHT_PURPLE),
    COMPLETE("Storage Complete", Formatting.GREEN);

    private final String label;
    private final Formatting formatting;

    StorageState(String label, Formatting formatting) {
        this.label = label;
        this.formatting = formatting;
    }

    public String getLabel() {
        return label;
    }

    public Formatting getFormatting() {
        return formatting;
    }

    public Text getFormattedText() {
        return Text.literal(label).formatted(formatting);
    }
}
