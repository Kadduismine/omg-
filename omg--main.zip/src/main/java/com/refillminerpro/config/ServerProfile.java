package com.refillminerpro.config;

/**
 * Dedicated server authorization and compliance policy profile.
 * Records the environment, permission status, notes, review date, and policy reference.
 */
public class ServerProfile {
    private String serverIdentifier;
    private boolean singleplayer;
    private boolean autoMiningPermitted;
    private boolean autoMovementPermitted;
    private boolean targetAssistancePermitted;
    private String policyNotes;
    private String lastReviewedDate;
    private String policyRuleReference;

    public ServerProfile() {}

    public ServerProfile(String serverIdentifier, boolean singleplayer, boolean autoMiningPermitted,
                         boolean autoMovementPermitted, boolean targetAssistancePermitted,
                         String policyNotes, String lastReviewedDate, String policyRuleReference) {
        this.serverIdentifier = serverIdentifier;
        this.singleplayer = singleplayer;
        this.autoMiningPermitted = autoMiningPermitted;
        this.autoMovementPermitted = autoMovementPermitted;
        this.targetAssistancePermitted = targetAssistancePermitted;
        this.policyNotes = policyNotes;
        this.lastReviewedDate = lastReviewedDate;
        this.policyRuleReference = policyRuleReference;
    }

    public static ServerProfile createSingleplayerDefault() {
        return new ServerProfile(
                "singleplayer",
                true,
                true,
                true,
                true,
                "Local singleplayer world; full automation permitted by player.",
                "2026-10-21",
                "Singleplayer Owner Control"
        );
    }

    public static ServerProfile createRestrictedDefault(String rawServerIdentifier) {
        String normalized = ServerIdentifier.normalize(rawServerIdentifier);

        if (ServerIdentifier.isStrayNetwork(normalized)) {
            return new ServerProfile(
                    normalized,
                    false,
                    false,
                    false,
                    false,
                    "Stray network (stray.gg); automated mining, pathfinding, and automated rotation are prohibited by default unless explicitly authorized by server staff.",
                    "2026-10-21",
                    "https://stray.gg/rules (Unfair Advantage / Automation Policy)"
            );
        }

        if (ServerIdentifier.isSpaceMCNetwork(normalized)) {
            return new ServerProfile(
                    normalized,
                    false,
                    false,
                    false,
                    false,
                    "SpaceMC network (spacemc.lol); automated features disabled until server rules or staff confirm permission.",
                    "2026-10-21",
                    "SpaceMC Fair Play Policy"
            );
        }

        return new ServerProfile(
                normalized,
                false,
                false,
                false,
                false,
                "Unverified multiplayer server; automation disabled by default for anti-cheat and rule compliance.",
                "2026-10-21",
                "Server Rule / Fair Play Policy"
        );
    }

    public String getServerIdentifier() { return serverIdentifier; }
    public void setServerIdentifier(String serverIdentifier) { this.serverIdentifier = serverIdentifier; }

    public boolean isSingleplayer() { return singleplayer; }
    public void setSingleplayer(boolean singleplayer) { this.singleplayer = singleplayer; }

    public boolean isAutoMiningPermitted() { return autoMiningPermitted; }
    public void setAutoMiningPermitted(boolean autoMiningPermitted) { this.autoMiningPermitted = autoMiningPermitted; }

    public boolean isAutoMovementPermitted() { return autoMovementPermitted; }
    public void setAutoMovementPermitted(boolean autoMovementPermitted) { this.autoMovementPermitted = autoMovementPermitted; }

    public boolean isTargetAssistancePermitted() { return targetAssistancePermitted; }
    public void setTargetAssistancePermitted(boolean targetAssistancePermitted) { this.targetAssistancePermitted = targetAssistancePermitted; }

    public String getPolicyNotes() { return policyNotes; }
    public void setPolicyNotes(String policyNotes) { this.policyNotes = policyNotes; }

    public String getLastReviewedDate() { return lastReviewedDate; }
    public void setLastReviewedDate(String lastReviewedDate) { this.lastReviewedDate = lastReviewedDate; }

    public String getPolicyRuleReference() { return policyRuleReference; }
    public void setPolicyRuleReference(String policyRuleReference) { this.policyRuleReference = policyRuleReference; }
}
