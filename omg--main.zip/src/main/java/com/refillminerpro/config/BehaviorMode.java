package com.refillminerpro.config;

import net.minecraft.text.Text;

/**
 * Behavior modes for Refill Miner Pro:
 * - FAST: High throughput, minimal idle time, prompt target progression.
 * - BALANCED: Balanced responsiveness, predictable targeting, and smooth transitions.
 * - SMOOTH: Gradual, continuous camera transitions, preventing overshoot or visual jitter.
 * - MANUAL_ASSIST: Highlights and points to eligible targets, lets player confirm/initiate mining.
 */
public enum BehaviorMode {
    FAST("Fast", "High throughput, minimal rotation delay, prompt target progression"),
    BALANCED("Balanced", "Balanced responsiveness, predictable targeting, and smooth transitions"),
    SMOOTH("Smooth", "Gradual camera transitions, stable tracking, zero abrupt snaps"),
    MANUAL_ASSIST("Manual Assist", "Detects and assists aiming; player controls attacks");

    // Aliases for compatibility
    public static final BehaviorMode MIXED = BALANCED;
    public static final BehaviorMode HUMANIZED = SMOOTH;
    public static final BehaviorMode SMOOTH_FAST = FAST;

    private final String displayName;
    private final String description;

    BehaviorMode(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public Text getText() {
        return Text.literal(displayName);
    }

    public BehaviorMode next() {
        BehaviorMode[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}

