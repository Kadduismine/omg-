package com.refillminerpro.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Validated persistent configuration data for Refill Miner Pro.
 */
public class ModConfig {
    public static final int DEFAULT_MAX_VOLUME = 50_000;
    public static final int ABSOLUTE_MAX_VOLUME = 500_000;

    // Schema version
    private int configVersion = 2;

    // Automation & Scanning (Runtime state strictly initialized to false)
    private boolean autoMineEnabled = false;
    private boolean paused = false;
    private boolean autoAdvance = true; // Automatically advances forward to reach next blocks
    private double desiredMiningGap = 1.5; // Desired distance in blocks (1.0 to 2.0) to maintain from mining face
    private MovementSmoothness movementSmoothness = MovementSmoothness.NORMAL; // Slow / Normal / Fast forward movement
    private boolean stuckRecoveryEnabled = true; // Automatically re-evaluates targets if forward progress stalls
    private int stuckDetectionThreshold = 20; // Ticks with zero displacement before triggering stuck recovery (default 20 ticks / 1.0s)
    private RecoveryMode recoveryMode = RecoveryMode.RESCAN; // Recovery policy: Rescan / Replan / Pause Safely
    private boolean continuousMining = true; // Keep mining flow uninterrupted between adjacent targets
    private int scanIntervalTicks = 10; // Fallback periodic scan interval in ticks (0.5s)
    private int scanBatchSize = 500; // Blocks processed per tick during periodic background scanning
    private int maxRegionVolume = DEFAULT_MAX_VOLUME;
    private int maxQueuedTargets = 2048;
    private int retryCooldownTicks = 20; // 1 second cooldown before retrying a failed/interrupted position
    private int maxRetriesPerTarget = 3;
    private int maxMiningTimeoutTicks = 160; // 8 seconds maximum mining time before considering interaction rejected
    private int protectionCooldownSeconds = 30; // Cooldown (in seconds) before retrying a server-protected block/area

    // Player-Controlled Manual Mining & Area Boundary Restriction
    private boolean playerControlledMining = false; // Default: False (Full Auto continuous mining). Set true for manual crosshair assist.
    private boolean enforceAreaBoundary = true; // Selected region acts as an explicit boundary guard

    // Target Selection Strategy & Behavior Preset
    private BehaviorMode behaviorMode = BehaviorMode.HUMANIZED;
    private TargetPriority targetPriority = TargetPriority.NEAREST_FIRST;
    private boolean forwardScanOnly = false;
    private double forwardScanFov = 110.0; // degrees field-of-view for forward scanning
    private int scanDistance = 5;
    private int scanWidth = 7;
    private int scanHeight = 5;

    private boolean mineExistingBlocks = true;
    private boolean autoSwitchTool = true;
    private boolean autoWalk = true;
    private boolean protectLowDurability = true;
    private int minDurabilityThreshold = 5;
    private boolean checkLineOfSight = true;

    // 6x3 Area Mining Mode
    private boolean areaMiningEnabled = false;
    private int areaMiningWidth = 6;
    private int areaMiningHeight = 3;

    // A* Navigation & Pathfinding
    private boolean autoNavigate = true;
    private int pathfindingSearchLimit = 1500;
    private boolean hazardAvoidance = true;
    private int recalculateCooldownTicks = 8;
    private double targetReachPreference = 4.4;

    // Rotation & Camera Dynamics
    private boolean rotationSmoothing = true;
    private double rotationResponse = 12.0;
    private double maxAngularVelocity = 210.0; // degrees per second (smooth, natural human tracking)
    private int visualUpdateTarget = 200; // updates per second target
    private boolean manualOverrideEnabled = true;
    private long manualOverrideCooldownMs = 1000L;

    // Filters
    private boolean filterExcludeAir = true;
    private boolean filterExcludeFluids = true;
    private boolean filterExcludeUnbreakable = true;
    private boolean filterExcludeBlockEntities = true;
    private List<String> whitelist = new ArrayList<>();
    private List<String> blacklist = new ArrayList<>();

    // Visualization & HUD
    private boolean hudVisible = true;
    private boolean outlineVisible = true;
    private boolean debugMode = false;
    private int hudPosX = 6;
    private int hudPosY = 6;

    // Predictive Arc Animated Background Configuration
    private boolean arcAnimationEnabled = true;
    private double arcIntensity = 1.0;
    private double arcSpeed = 1.0;
    private boolean arcMouseReactive = true;
    private boolean arcReducedMotion = false;
    private com.refillminerpro.client.gui.arc.ArcColorPreset arcColorPreset = com.refillminerpro.client.gui.arc.ArcColorPreset.COSMIC_ARC;

    // Associated world / server selections: key = server IP or singleplayer world name
    private Map<String, SavedSelection> savedSelections = new HashMap<>();

    // Multi-area named profiles for servers and dimensions
    private List<SavedAreaProfile> savedAreas = new ArrayList<>();
    private String lastActiveAreaId = null;
    private boolean restoreLastAreaOnJoin = true;

    // Server authorization profiles: server address -> ServerProfile
    private Map<String, ServerProfile> serverProfiles = new HashMap<>();

    // Automatic Inventory Storage Configuration
    private com.refillminerpro.storage.AutoStorageConfig autoStorage = new com.refillminerpro.storage.AutoStorageConfig();

    public static class SavedSelection {
        public int x1, y1, z1;
        public int x2, y2, z2;

        public SavedSelection() {}

        public SavedSelection(int x1, int y1, int z1, int x2, int y2, int z2) {
            this.x1 = x1;
            this.y1 = y1;
            this.z1 = z1;
            this.x2 = x2;
            this.y2 = y2;
            this.z2 = z2;
        }
    }

    /**
     * Sanitizes and validates configuration bounds.
     */
    public void validate() {
        this.configVersion = 2;

        // Strict runtime-only constraints: automation must never initialize active from disk
        this.autoMineEnabled = false;
        this.paused = false;

        if (this.savedSelections == null) {
            this.savedSelections = new HashMap<>();
        }

        if (this.savedAreas == null) {
            this.savedAreas = new ArrayList<>();
        } else {
            // Validate each saved area profile
            for (SavedAreaProfile profile : this.savedAreas) {
                if (profile != null) {
                    if (profile.getId() == null || profile.getId().trim().isEmpty()) {
                        profile.setId(java.util.UUID.randomUUID().toString());
                    }
                    profile.recalculateBounds();
                }
            }
        }

        // Migration from legacy savedSelections to savedAreas if needed
        if (!this.savedSelections.isEmpty() && this.savedAreas.isEmpty()) {
            for (Map.Entry<String, SavedSelection> entry : this.savedSelections.entrySet()) {
                SavedSelection sel = entry.getValue();
                if (sel != null && entry.getKey() != null) {
                    SavedAreaProfile profile = new SavedAreaProfile(
                            "Saved Area",
                            entry.getKey(),
                            "minecraft:overworld",
                            sel.x1, sel.y1, sel.z1,
                            sel.x2, sel.y2, sel.z2
                    );
                    profile.setActive(true);
                    this.savedAreas.add(profile);
                }
            }
        }

        if (scanIntervalTicks < 1) scanIntervalTicks = 1;
        if (scanIntervalTicks > 200) scanIntervalTicks = 200;

        if (scanBatchSize < 50) scanBatchSize = 50;
        if (scanBatchSize > 5000) scanBatchSize = 5000;

        if (maxRegionVolume < 1) maxRegionVolume = 1;
        if (maxRegionVolume > ABSOLUTE_MAX_VOLUME) maxRegionVolume = ABSOLUTE_MAX_VOLUME;

        if (maxQueuedTargets < 16) maxQueuedTargets = 16;
        if (maxQueuedTargets > 4096) maxQueuedTargets = 4096;

        if (retryCooldownTicks < 1) retryCooldownTicks = 1;
        if (retryCooldownTicks > 200) retryCooldownTicks = 200;

        if (maxRetriesPerTarget < 1) maxRetriesPerTarget = 1;
        if (maxRetriesPerTarget > 10) maxRetriesPerTarget = 10;

        if (maxMiningTimeoutTicks < 20) maxMiningTimeoutTicks = 20;
        if (maxMiningTimeoutTicks > 600) maxMiningTimeoutTicks = 600;

        if (minDurabilityThreshold < 1) minDurabilityThreshold = 1;
        if (minDurabilityThreshold > 100) minDurabilityThreshold = 100;

        if (areaMiningWidth < 1) areaMiningWidth = 1;
        if (areaMiningWidth > 16) areaMiningWidth = 16;

        if (areaMiningHeight < 1) areaMiningHeight = 1;
        if (areaMiningHeight > 16) areaMiningHeight = 16;

        if (pathfindingSearchLimit < 100) pathfindingSearchLimit = 100;
        if (pathfindingSearchLimit > 5000) pathfindingSearchLimit = 5000;

        if (recalculateCooldownTicks < 5) recalculateCooldownTicks = 5;
        if (recalculateCooldownTicks > 200) recalculateCooldownTicks = 200;

        if (targetReachPreference < 1.5) targetReachPreference = 1.5;
        if (targetReachPreference > 4.5) targetReachPreference = 4.5;

        if (desiredMiningGap < 1.0) desiredMiningGap = 1.0;
        if (desiredMiningGap > 2.0) desiredMiningGap = 2.0;
        if (stuckDetectionThreshold < 5) stuckDetectionThreshold = 5;
        if (stuckDetectionThreshold > 100) stuckDetectionThreshold = 100;
        if (recoveryMode == null) recoveryMode = RecoveryMode.RESCAN;
        if (movementSmoothness == null) movementSmoothness = MovementSmoothness.NORMAL;
        if (protectionCooldownSeconds < 5) protectionCooldownSeconds = 5;
        if (protectionCooldownSeconds > 300) protectionCooldownSeconds = 300;

        if (rotationResponse < 1.0) rotationResponse = 1.0;
        if (rotationResponse > 50.0) rotationResponse = 50.0;

        if (maxAngularVelocity < 30.0) maxAngularVelocity = 30.0;
        if (maxAngularVelocity > 720.0) maxAngularVelocity = 720.0;

        if (visualUpdateTarget < 30) visualUpdateTarget = 30;
        if (visualUpdateTarget > 500) visualUpdateTarget = 500;

        if (manualOverrideCooldownMs < 100L) manualOverrideCooldownMs = 100L;
        if (manualOverrideCooldownMs > 5000L) manualOverrideCooldownMs = 5000L;

        if (behaviorMode == null) behaviorMode = BehaviorMode.BALANCED;
        if (targetPriority == null) targetPriority = TargetPriority.NEAREST_FIRST;
        if (scanDistance < 2) scanDistance = 2;
        if (scanDistance > 8) scanDistance = 8;
        if (scanWidth < 3) scanWidth = 3;
        if (scanWidth > 15) scanWidth = 15;
        if (scanHeight < 2) scanHeight = 2;
        if (scanHeight > 10) scanHeight = 10;
        if (forwardScanFov < 45.0) forwardScanFov = 45.0;
        if (forwardScanFov > 160.0) forwardScanFov = 160.0;
        if (whitelist == null) whitelist = new ArrayList<>();
        if (blacklist == null) blacklist = new ArrayList<>();
        if (savedSelections == null) savedSelections = new HashMap<>();
        if (serverProfiles == null) serverProfiles = new HashMap<>();
        if (autoStorage == null) {
            autoStorage = new com.refillminerpro.storage.AutoStorageConfig();
        }
        autoStorage.validate();
    }

    // Getters and Setters
    public int getConfigVersion() { return configVersion; }
    public void setConfigVersion(int configVersion) { this.configVersion = configVersion; }

    public void clearSavedSelections() {
        if (this.savedSelections != null) {
            this.savedSelections.clear();
        }
    }

    public boolean isAutoMineEnabled() { return autoMineEnabled; }
    public void setAutoMineEnabled(boolean autoMineEnabled) { this.autoMineEnabled = autoMineEnabled; }

    public boolean isPaused() { return paused; }
    public void setPaused(boolean paused) { this.paused = paused; }

    public int getScanIntervalTicks() { return scanIntervalTicks; }
    public void setScanIntervalTicks(int scanIntervalTicks) { this.scanIntervalTicks = scanIntervalTicks; }

    public int getScanBatchSize() { return scanBatchSize; }
    public void setScanBatchSize(int scanBatchSize) { this.scanBatchSize = scanBatchSize; }

    public int getMaxRegionVolume() { return maxRegionVolume; }
    public void setMaxRegionVolume(int maxRegionVolume) { this.maxRegionVolume = maxRegionVolume; }

    public int getMaxQueuedTargets() { return maxQueuedTargets; }
    public void setMaxQueuedTargets(int maxQueuedTargets) { this.maxQueuedTargets = maxQueuedTargets; }

    public int getRetryCooldownTicks() { return retryCooldownTicks; }
    public void setRetryCooldownTicks(int retryCooldownTicks) { this.retryCooldownTicks = retryCooldownTicks; }

    public int getMaxRetriesPerTarget() { return maxRetriesPerTarget; }
    public void setMaxRetriesPerTarget(int maxRetriesPerTarget) { this.maxRetriesPerTarget = maxRetriesPerTarget; }

    public int getMaxMiningTimeoutTicks() { return maxMiningTimeoutTicks; }
    public void setMaxMiningTimeoutTicks(int maxMiningTimeoutTicks) { this.maxMiningTimeoutTicks = maxMiningTimeoutTicks; }

    public int getProtectionCooldownSeconds() { return protectionCooldownSeconds; }
    public void setProtectionCooldownSeconds(int protectionCooldownSeconds) {
        this.protectionCooldownSeconds = Math.max(5, Math.min(300, protectionCooldownSeconds));
    }

    public boolean isPlayerControlledMining() { return playerControlledMining; }
    public void setPlayerControlledMining(boolean playerControlledMining) { this.playerControlledMining = playerControlledMining; }

    public boolean isEnforceAreaBoundary() { return enforceAreaBoundary; }
    public void setEnforceAreaBoundary(boolean enforceAreaBoundary) { this.enforceAreaBoundary = enforceAreaBoundary; }

    public TargetPriority getTargetPriority() { return targetPriority != null ? targetPriority : TargetPriority.BOTTOM_TO_TOP; }
    public void setTargetPriority(TargetPriority targetPriority) { this.targetPriority = targetPriority; }

    public boolean isMineExistingBlocks() { return mineExistingBlocks; }
    public void setMineExistingBlocks(boolean mineExistingBlocks) { this.mineExistingBlocks = mineExistingBlocks; }

    public boolean isAutoSwitchTool() { return autoSwitchTool; }
    public void setAutoSwitchTool(boolean autoSwitchTool) { this.autoSwitchTool = autoSwitchTool; }

    public boolean isAutoWalk() { return autoWalk; }
    public void setAutoWalk(boolean autoWalk) { this.autoWalk = autoWalk; }

    public boolean isProtectLowDurability() { return protectLowDurability; }
    public void setProtectLowDurability(boolean protectLowDurability) { this.protectLowDurability = protectLowDurability; }

    public int getMinDurabilityThreshold() { return minDurabilityThreshold; }
    public void setMinDurabilityThreshold(int minDurabilityThreshold) { this.minDurabilityThreshold = minDurabilityThreshold; }

    public boolean isCheckLineOfSight() { return checkLineOfSight; }
    public void setCheckLineOfSight(boolean checkLineOfSight) { this.checkLineOfSight = checkLineOfSight; }

    public boolean isAreaMiningEnabled() { return areaMiningEnabled; }
    public void setAreaMiningEnabled(boolean areaMiningEnabled) { this.areaMiningEnabled = areaMiningEnabled; }

    public int getAreaMiningWidth() { return areaMiningWidth; }
    public void setAreaMiningWidth(int areaMiningWidth) { this.areaMiningWidth = areaMiningWidth; }

    public int getAreaMiningHeight() { return areaMiningHeight; }
    public void setAreaMiningHeight(int areaMiningHeight) { this.areaMiningHeight = areaMiningHeight; }

    public boolean isAutoNavigate() { return autoNavigate; }
    public void setAutoNavigate(boolean autoNavigate) { this.autoNavigate = autoNavigate; }

    public int getPathfindingSearchLimit() { return pathfindingSearchLimit; }
    public void setPathfindingSearchLimit(int pathfindingSearchLimit) { this.pathfindingSearchLimit = pathfindingSearchLimit; }

    public boolean isHazardAvoidance() { return hazardAvoidance; }
    public void setHazardAvoidance(boolean hazardAvoidance) { this.hazardAvoidance = hazardAvoidance; }

    public int getRecalculateCooldownTicks() { return recalculateCooldownTicks; }
    public void setRecalculateCooldownTicks(int recalculateCooldownTicks) { this.recalculateCooldownTicks = recalculateCooldownTicks; }

    public double getTargetReachPreference() { return targetReachPreference; }
    public void setTargetReachPreference(double targetReachPreference) { this.targetReachPreference = targetReachPreference; }

    public boolean isRotationSmoothing() { return rotationSmoothing; }
    public void setRotationSmoothing(boolean rotationSmoothing) { this.rotationSmoothing = rotationSmoothing; }

    public double getRotationResponse() { return rotationResponse; }
    public void setRotationResponse(double rotationResponse) { this.rotationResponse = rotationResponse; }

    public double getMaxAngularVelocity() { return maxAngularVelocity; }
    public void setMaxAngularVelocity(double maxAngularVelocity) { this.maxAngularVelocity = maxAngularVelocity; }

    public int getVisualUpdateTarget() { return visualUpdateTarget; }
    public void setVisualUpdateTarget(int visualUpdateTarget) { this.visualUpdateTarget = visualUpdateTarget; }

    public boolean isManualOverrideEnabled() { return manualOverrideEnabled; }
    public void setManualOverrideEnabled(boolean manualOverrideEnabled) { this.manualOverrideEnabled = manualOverrideEnabled; }

    public long getManualOverrideCooldownMs() { return manualOverrideCooldownMs; }
    public void setManualOverrideCooldownMs(long manualOverrideCooldownMs) { this.manualOverrideCooldownMs = manualOverrideCooldownMs; }

    public boolean isFilterExcludeAir() { return filterExcludeAir; }
    public void setFilterExcludeAir(boolean filterExcludeAir) { this.filterExcludeAir = filterExcludeAir; }

    public boolean isFilterExcludeFluids() { return filterExcludeFluids; }
    public void setFilterExcludeFluids(boolean filterExcludeFluids) { this.filterExcludeFluids = filterExcludeFluids; }

    public boolean isFilterExcludeUnbreakable() { return filterExcludeUnbreakable; }
    public void setFilterExcludeUnbreakable(boolean filterExcludeUnbreakable) { this.filterExcludeUnbreakable = filterExcludeUnbreakable; }

    public boolean isFilterExcludeBlockEntities() { return filterExcludeBlockEntities; }
    public void setFilterExcludeBlockEntities(boolean filterExcludeBlockEntities) { this.filterExcludeBlockEntities = filterExcludeBlockEntities; }

    public List<String> getWhitelist() { return whitelist; }
    public void setWhitelist(List<String> whitelist) { this.whitelist = whitelist; }

    public List<String> getBlacklist() { return blacklist; }
    public void setBlacklist(List<String> blacklist) { this.blacklist = blacklist; }

    public boolean isHudVisible() { return hudVisible; }
    public void setHudVisible(boolean hudVisible) { this.hudVisible = hudVisible; }

    public boolean isOutlineVisible() { return outlineVisible; }
    public void setOutlineVisible(boolean outlineVisible) { this.outlineVisible = outlineVisible; }

    public boolean isDebugMode() { return debugMode; }
    public void setDebugMode(boolean debugMode) { this.debugMode = debugMode; }

    public int getHudPosX() { return hudPosX; }
    public void setHudPosX(int hudPosX) { this.hudPosX = hudPosX; }

    public int getHudPosY() { return hudPosY; }
    public void setHudPosY(int hudPosY) { this.hudPosY = hudPosY; }

    public boolean isArcAnimationEnabled() { return arcAnimationEnabled; }
    public void setArcAnimationEnabled(boolean arcAnimationEnabled) { this.arcAnimationEnabled = arcAnimationEnabled; }

    public double getArcIntensity() { return arcIntensity; }
    public void setArcIntensity(double arcIntensity) { this.arcIntensity = Math.clamp(arcIntensity, 0.2, 2.0); }

    public double getArcSpeed() { return arcSpeed; }
    public void setArcSpeed(double arcSpeed) { this.arcSpeed = Math.clamp(arcSpeed, 0.2, 2.0); }

    public boolean isArcMouseReactive() { return arcMouseReactive; }
    public void setArcMouseReactive(boolean arcMouseReactive) { this.arcMouseReactive = arcMouseReactive; }

    public boolean isArcReducedMotion() { return arcReducedMotion; }
    public void setArcReducedMotion(boolean arcReducedMotion) { this.arcReducedMotion = arcReducedMotion; }

    public BehaviorMode getBehaviorMode() {
        return behaviorMode != null ? behaviorMode : BehaviorMode.BALANCED;
    }

    public void setBehaviorMode(BehaviorMode behaviorMode) {
        this.behaviorMode = behaviorMode;
        applyBehaviorPresetDefaults(behaviorMode);
    }

    /**
     * Applies preset defaults for responsiveness, rotation speed, and acceleration
     * based on the selected BehaviorMode while retaining user whitelist/selection rules.
     */
    public void applyBehaviorPresetDefaults(BehaviorMode mode) {
        if (mode == null) mode = BehaviorMode.BALANCED;
        switch (mode) {
            case FAST -> {
                this.rotationSmoothing = true;
                this.rotationResponse = 24.0;
                this.maxAngularVelocity = 480.0;
                this.scanIntervalTicks = 4;
                this.playerControlledMining = false;
            }
            case BALANCED -> {
                this.rotationSmoothing = true;
                this.rotationResponse = 16.0;
                this.maxAngularVelocity = 280.0;
                this.scanIntervalTicks = 6;
                this.playerControlledMining = false;
            }
            case SMOOTH -> {
                this.rotationSmoothing = true;
                this.rotationResponse = 12.0;
                this.maxAngularVelocity = 210.0;
                this.scanIntervalTicks = 10;
                this.playerControlledMining = false;
            }
            case MANUAL_ASSIST -> {
                this.rotationSmoothing = true;
                this.rotationResponse = 14.0;
                this.maxAngularVelocity = 240.0;
                this.scanIntervalTicks = 8;
                this.playerControlledMining = true; // Manual assist: user initiates attack inputs
            }
        }
    }

    public boolean isAutoAdvance() { return autoAdvance; }
    public void setAutoAdvance(boolean autoAdvance) { this.autoAdvance = autoAdvance; }

    public boolean isForwardMovementEnabled() { return autoAdvance; }
    public void setForwardMovementEnabled(boolean forwardMovement) { this.autoAdvance = forwardMovement; }

    public double getDesiredMiningGap() { return desiredMiningGap; }
    public void setDesiredMiningGap(double desiredMiningGap) {
        this.desiredMiningGap = Math.max(1.0, Math.min(2.0, desiredMiningGap));
    }

    public MovementSmoothness getMovementSmoothness() {
        return movementSmoothness != null ? movementSmoothness : MovementSmoothness.NORMAL;
    }
    public void setMovementSmoothness(MovementSmoothness movementSmoothness) {
        this.movementSmoothness = (movementSmoothness != null) ? movementSmoothness : MovementSmoothness.NORMAL;
    }

    public boolean isContinuousForwardMovement() { return autoAdvance; }
    public void setContinuousForwardMovement(boolean val) { this.autoAdvance = val; }

    public int getStuckDetectionThreshold() { return stuckDetectionThreshold; }
    public void setStuckDetectionThreshold(int threshold) { this.stuckDetectionThreshold = Math.max(5, Math.min(100, threshold)); }

    public RecoveryMode getRecoveryMode() { return recoveryMode != null ? recoveryMode : RecoveryMode.RESCAN; }
    public void setRecoveryMode(RecoveryMode recoveryMode) { this.recoveryMode = recoveryMode != null ? recoveryMode : RecoveryMode.RESCAN; }

    public boolean isStuckRecoveryEnabled() { return stuckRecoveryEnabled; }
    public void setStuckRecoveryEnabled(boolean stuckRecoveryEnabled) { this.stuckRecoveryEnabled = stuckRecoveryEnabled; }

    public boolean isContinuousMining() { return continuousMining; }
    public void setContinuousMining(boolean continuousMining) { this.continuousMining = continuousMining; }

    public boolean isForwardScanOnly() { return forwardScanOnly; }
    public void setForwardScanOnly(boolean forwardScanOnly) { this.forwardScanOnly = forwardScanOnly; }

    public double getForwardScanFov() { return forwardScanFov; }
    public void setForwardScanFov(double forwardScanFov) { this.forwardScanFov = forwardScanFov; }

    public int getScanDistance() { return scanDistance; }
    public void setScanDistance(int scanDistance) { this.scanDistance = scanDistance; }

    public int getScanWidth() { return scanWidth; }
    public void setScanWidth(int scanWidth) { this.scanWidth = scanWidth; }

    public int getScanHeight() { return scanHeight; }
    public void setScanHeight(int scanHeight) { this.scanHeight = scanHeight; }

    public com.refillminerpro.client.gui.arc.ArcColorPreset getArcColorPreset() {
        return arcColorPreset != null ? arcColorPreset : com.refillminerpro.client.gui.arc.ArcColorPreset.COSMIC_ARC;
    }
    public void setArcColorPreset(com.refillminerpro.client.gui.arc.ArcColorPreset arcColorPreset) {
        this.arcColorPreset = arcColorPreset;
    }

    public Map<String, SavedSelection> getSavedSelections() { return savedSelections; }
    public void setSavedSelections(Map<String, SavedSelection> savedSelections) { this.savedSelections = savedSelections; }

    public List<SavedAreaProfile> getSavedAreas() {
        if (savedAreas == null) {
            savedAreas = new ArrayList<>();
        }
        return savedAreas;
    }

    public void setSavedAreas(List<SavedAreaProfile> savedAreas) {
        this.savedAreas = savedAreas != null ? savedAreas : new ArrayList<>();
    }

    public String getLastActiveAreaId() {
        return lastActiveAreaId;
    }

    public void setLastActiveAreaId(String lastActiveAreaId) {
        this.lastActiveAreaId = lastActiveAreaId;
    }

    public boolean isRestoreLastAreaOnJoin() {
        return restoreLastAreaOnJoin;
    }

    public void setRestoreLastAreaOnJoin(boolean restoreLastAreaOnJoin) {
        this.restoreLastAreaOnJoin = restoreLastAreaOnJoin;
    }

    public Map<String, ServerProfile> getServerProfiles() { return serverProfiles; }
    public void setServerProfiles(Map<String, ServerProfile> serverProfiles) { this.serverProfiles = serverProfiles; }

    public ServerProfile getProfileForEnvironment(String rawIdentifier) {
        String key = ServerIdentifier.normalize(rawIdentifier);
        if (key.equals("singleplayer")) {
            return ServerProfile.createSingleplayerDefault();
        }
        return serverProfiles.computeIfAbsent(key, ServerProfile::createRestrictedDefault);
    }

    public boolean isEnvironmentAuthorized(String rawIdentifier) {
        String key = ServerIdentifier.normalize(rawIdentifier);
        if (key.equals("singleplayer")) {
            return true; // Singleplayer is always authorized
        }
        ServerProfile profile = serverProfiles.get(key);
        return profile != null && profile.isAutoMiningPermitted();
    }

    public void setEnvironmentAuthorized(String rawIdentifier, boolean authorized) {
        String key = ServerIdentifier.normalize(rawIdentifier);
        if (!key.equals("singleplayer")) {
            ServerProfile profile = getProfileForEnvironment(key);
            profile.setAutoMiningPermitted(authorized);
            profile.setAutoMovementPermitted(authorized);
            profile.setLastReviewedDate("2026-10-21");
            serverProfiles.put(key, profile);
        }
    }

    public com.refillminerpro.storage.AutoStorageConfig getAutoStorage() {
        if (autoStorage == null) {
            autoStorage = new com.refillminerpro.storage.AutoStorageConfig();
        }
        return autoStorage;
    }

    public void setAutoStorage(com.refillminerpro.storage.AutoStorageConfig autoStorage) {
        this.autoStorage = autoStorage;
    }
}

