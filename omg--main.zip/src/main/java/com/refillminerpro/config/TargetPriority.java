package com.refillminerpro.config;

import net.minecraft.text.Text;

/**
 * Priority strategy for selecting the next mining target from eligible candidates.
 */
public enum TargetPriority {
    SMART("Smart Order"),
    NEAREST_FIRST("Nearest First"),
    BOTTOM_TO_TOP("Bottom-Up"),
    TOP_TO_BOTTOM("Top-Down"),
    ROW_SWEEP("Row Sweep"),
    CROSSHAIR_PRIORITY("Crosshair Priority"),
    HOVER_SWEEP("Hover Sweep (Natural)"),
    SELECTION_ORDER("Selection Order"),
    ROW_BY_ROW("Row by Row"),
    LEFT_TO_RIGHT("Left to Right"),
    RIGHT_TO_LEFT("Right to Left"),
    LOWEST_TRAVEL_COST("Lowest Travel Cost"),
    REFILL_PRIORITY("Refill Priority"),
    FURTHEST_FIRST("Furthest First");

    // Aliases for backwards compatibility with any existing saved configs
    public static final TargetPriority NEAREST = NEAREST_FIRST;
    public static final TargetPriority BOTTOM_UP = BOTTOM_TO_TOP;
    public static final TargetPriority TOP_DOWN = TOP_TO_BOTTOM;
    public static final TargetPriority LOWEST_Y_FIRST = BOTTOM_TO_TOP;
    public static final TargetPriority HIGHEST_Y_FIRST = TOP_TO_BOTTOM;
    public static final TargetPriority FIFO = SELECTION_ORDER;

    private final String displayName;

    TargetPriority(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Text getText() {
        return Text.literal(displayName);
    }

    public TargetPriority next() {
        TargetPriority[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}
