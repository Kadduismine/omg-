package com.refillminerpro.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.refillminerpro.region.BlockRegion;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Manages atomic persistence of configuration, server profiles, and named saved areas.
 */
public class ConfigManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/Config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FILE_NAME = "refillminerpro.json";

    private final File configFile;
    private ModConfig config;

    public ConfigManager() {
        this(resolveConfigDir());
    }

    public ConfigManager(File configDir) {
        File dir = configDir != null ? configDir : new File("config");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        this.configFile = new File(dir, CONFIG_FILE_NAME);
        this.config = new ModConfig();
    }

    private static File resolveConfigDir() {
        try {
            if (FabricLoader.getInstance() != null && FabricLoader.getInstance().getConfigDir() != null) {
                return FabricLoader.getInstance().getConfigDir().toFile();
            }
        } catch (Throwable ignored) {}
        return new File("config");
    }

    public void load() {
        if (!configFile.exists()) {
            LOGGER.info("Configuration file not found, creating defaults at {}", configFile.getAbsolutePath());
            this.config = new ModConfig();
            this.config.validate();
            save();
            return;
        }

        try (FileReader reader = new FileReader(configFile)) {
            ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
            if (loaded != null) {
                this.config = loaded;
                this.config.validate();
                // Enforce safe runtime state: automation must strictly be idle on startup
                this.config.setAutoMineEnabled(false);
                this.config.setPaused(false);
                this.config.setPlayerControlledMining(false);
                LOGGER.info("Refill Miner Pro configuration loaded successfully (version {}, {} saved areas).",
                        config.getConfigVersion(), config.getSavedAreas().size());
            } else {
                LOGGER.warn("Loaded configuration was null, using defaults.");
                this.config = new ModConfig();
                this.config.validate();
                save();
            }
        } catch (Exception e) {
            LOGGER.error("Failed to parse configuration file. Backing up corrupted file and writing defaults.", e);
            try {
                File backup = new File(configFile.getParentFile(), CONFIG_FILE_NAME + ".corrupted");
                Files.copy(configFile.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {}
            this.config = new ModConfig();
            this.config.validate();
            save();
        }
    }

    public synchronized void save() {
        if (config == null) return;

        // Enforce that transient runtime automation state is preserved in memory but NEVER written to disk
        boolean runtimeAutoMine = config.isAutoMineEnabled();
        boolean runtimePaused = config.isPaused();

        config.validate();

        config.setAutoMineEnabled(false);
        config.setPaused(false);

        File parentDir = configFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        File tempFile = new File(parentDir, CONFIG_FILE_NAME + ".tmp");

        try {
            try (FileWriter writer = new FileWriter(tempFile)) {
                GSON.toJson(config, writer);
                writer.flush();
            }

            try {
                Files.move(tempFile.toPath(), configFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveEx) {
                try {
                    Files.move(tempFile.toPath(), configFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException standardMoveEx) {
                    Files.copy(tempFile.toPath(), configFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    if (tempFile.exists()) {
                        tempFile.delete();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to save configuration file {}: {}", configFile.getAbsolutePath(), e.getMessage());
        } finally {
            // Restore in-memory runtime session state
            config.setAutoMineEnabled(runtimeAutoMine);
            config.setPaused(runtimePaused);
            if (tempFile.exists()) {
                tempFile.delete();
            }
        }
    }

    public ModConfig getConfig() {
        if (config == null) {
            config = new ModConfig();
            config.validate();
        }
        return config;
    }

    /**
     * Saves the current selection for the specified server/world.
     * Updates legacy map and creates/updates a named SavedAreaProfile.
     */
    public synchronized void saveSelectionForWorld(String worldIdentifier, BlockRegion region) {
        if (worldIdentifier == null || region == null) return;
        String normalizedEndpoint = ServerIdentifier.normalize(worldIdentifier);

        // 1. Update legacy savedSelections map
        config.getSavedSelections().put(normalizedEndpoint, new ModConfig.SavedSelection(
                region.getCorner1().getX(), region.getCorner1().getY(), region.getCorner1().getZ(),
                region.getCorner2().getX(), region.getCorner2().getY(), region.getCorner2().getZ()
        ));

        // 2. Find or create matching SavedAreaProfile
        SavedAreaProfile existing = findLastActiveArea(normalizedEndpoint, "minecraft:overworld");
        if (existing != null) {
            existing.updateFromRegion(region);
            existing.setActive(true);
            config.setLastActiveAreaId(existing.getId());
        } else {
            SavedAreaProfile profile = SavedAreaProfile.fromRegion("Active Selection", normalizedEndpoint, "minecraft:overworld", region);
            profile.setActive(true);
            config.getSavedAreas().add(profile);
            config.setLastActiveAreaId(profile.getId());
        }

        save();
        LOGGER.info("Saved selection for world '{}' [{} to {}]", normalizedEndpoint, region.getCorner1(), region.getCorner2());
    }

    /**
     * Loads the saved selection for the specified server/world.
     */
    public synchronized BlockRegion loadSelectionForWorld(String worldIdentifier) {
        if (worldIdentifier == null) return null;
        String normalizedEndpoint = ServerIdentifier.normalize(worldIdentifier);

        // 1. Look in savedAreas first
        SavedAreaProfile profile = findLastActiveArea(normalizedEndpoint, null);
        if (profile != null) {
            return profile.toBlockRegion();
        }

        // 2. Fallback to legacy savedSelections
        ModConfig.SavedSelection legacy = config.getSavedSelections().get(normalizedEndpoint);
        if (legacy != null) {
            return new BlockRegion(new BlockPos(legacy.x1, legacy.y1, legacy.z1), new BlockPos(legacy.x2, legacy.y2, legacy.z2));
        }

        return null;
    }

    // =========================================================================
    // Multi-Area Management Methods
    // =========================================================================

    public synchronized void saveArea(SavedAreaProfile profile) {
        if (profile == null) return;
        List<SavedAreaProfile> areas = config.getSavedAreas();
        int existingIdx = -1;
        for (int i = 0; i < areas.size(); i++) {
            if (Objects.equals(areas.get(i).getId(), profile.getId())) {
                existingIdx = i;
                break;
            }
        }

        profile.setActive(true);
        // Clear active on other areas for this server & dimension
        for (SavedAreaProfile p : areas) {
            if (p.matches(profile.getServer(), profile.getDimension()) && !Objects.equals(p.getId(), profile.getId())) {
                p.setActive(false);
            }
        }

        if (existingIdx >= 0) {
            areas.set(existingIdx, profile);
        } else {
            areas.add(profile);
        }

        config.setLastActiveAreaId(profile.getId());
        save();
        LOGGER.info("Saved area profile '{}' ({}) for server {}", profile.getName(), profile.getId(), profile.getServer());
    }

    public synchronized boolean deleteArea(String profileId) {
        if (profileId == null) return false;
        List<SavedAreaProfile> areas = config.getSavedAreas();
        boolean removed = areas.removeIf(p -> Objects.equals(p.getId(), profileId));
        if (removed) {
            if (Objects.equals(config.getLastActiveAreaId(), profileId)) {
                config.setLastActiveAreaId(null);
            }
            save();
            LOGGER.info("Deleted area profile {}", profileId);
        }
        return removed;
    }

    public synchronized boolean renameArea(String profileId, String newName) {
        if (profileId == null || newName == null) return false;
        for (SavedAreaProfile profile : config.getSavedAreas()) {
            if (Objects.equals(profile.getId(), profileId)) {
                profile.setName(newName);
                save();
                LOGGER.info("Renamed area profile {} to '{}'", profileId, newName);
                return true;
            }
        }
        return false;
    }

    public synchronized SavedAreaProfile duplicateArea(String profileId) {
        if (profileId == null) return null;
        for (SavedAreaProfile profile : config.getSavedAreas()) {
            if (Objects.equals(profile.getId(), profileId)) {
                SavedAreaProfile clone = profile.duplicate();
                config.getSavedAreas().add(clone);
                save();
                LOGGER.info("Duplicated area profile {} as '{}'", profileId, clone.getName());
                return clone;
            }
        }
        return null;
    }

    public synchronized void updateAreaCoordinates(String profileId, BlockRegion region) {
        if (profileId == null || region == null) return;
        for (SavedAreaProfile profile : config.getSavedAreas()) {
            if (Objects.equals(profile.getId(), profileId)) {
                profile.updateFromRegion(region);
                profile.setActive(true);
                config.setLastActiveAreaId(profile.getId());
                save();
                LOGGER.info("Updated coordinates for area profile {}", profileId);
                return;
            }
        }
    }

    public synchronized List<SavedAreaProfile> getSavedAreasFor(String server, String dimension) {
        List<SavedAreaProfile> result = new ArrayList<>();
        if (server == null) return result;
        String normalizedServer = ServerIdentifier.normalize(server);

        for (SavedAreaProfile profile : config.getSavedAreas()) {
            if (profile != null && Objects.equals(profile.getServer(), normalizedServer)) {
                if (dimension == null || Objects.equals(profile.getDimension(), dimension)) {
                    result.add(profile);
                }
            }
        }
        // Sort active first, then most recently modified
        result.sort(Comparator.comparing(SavedAreaProfile::isActive).reversed()
                .thenComparing(Comparator.comparingLong(SavedAreaProfile::getUpdatedAtMs).reversed()));
        return result;
    }

    public synchronized SavedAreaProfile findLastActiveArea(String server, String dimension) {
        List<SavedAreaProfile> areas = getSavedAreasFor(server, dimension);
        if (areas.isEmpty()) {
            return null;
        }

        // 1. Check if lastActiveAreaId matches
        String lastId = config.getLastActiveAreaId();
        if (lastId != null) {
            for (SavedAreaProfile p : areas) {
                if (Objects.equals(p.getId(), lastId)) {
                    return p;
                }
            }
        }

        // 2. Check for active flag
        for (SavedAreaProfile p : areas) {
            if (p.isActive()) {
                return p;
            }
        }

        // 3. Return most recently modified
        return areas.get(0);
    }

    public synchronized void setActiveArea(String profileId) {
        if (profileId == null) return;
        SavedAreaProfile target = null;
        for (SavedAreaProfile p : config.getSavedAreas()) {
            if (Objects.equals(p.getId(), profileId)) {
                target = p;
                p.setActive(true);
            }
        }

        if (target != null) {
            config.setLastActiveAreaId(profileId);
            // Deactivate others for same server and dimension
            for (SavedAreaProfile p : config.getSavedAreas()) {
                if (!Objects.equals(p.getId(), profileId) && p.matches(target.getServer(), target.getDimension())) {
                    p.setActive(false);
                }
            }
            save();
        }
    }
}
