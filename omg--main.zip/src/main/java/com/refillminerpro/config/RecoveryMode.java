package com.refillminerpro.config;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Defines recovery behaviors when automated mining stalls or encounters an impassable route.
 */
public enum RecoveryMode {
    RESCAN("Rescan", Formatting.AQUA),
    REPLAN("Replan", Formatting.YELLOW),
    PAUSE_SAFELY("Pause Safely", Formatting.RED);

    private final String displayName;
    private final Formatting formatting;

    RecoveryMode(String displayName, Formatting formatting) {
        this.displayName = displayName;
        this.formatting = formatting;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Formatting getFormatting() {
        return formatting;
    }

    public Text getText() {
        return Text.literal(displayName).formatted(formatting);
    }
}

