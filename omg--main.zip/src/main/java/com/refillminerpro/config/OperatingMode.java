package com.refillminerpro.config;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Operating mode governing automation safety and server policy compliance:
 * - SINGLEPLAYER: Full automation (mining, pathfinding, refill monitoring) permitted.
 * - AUTHORIZED_SERVER: Automation permitted on servers explicitly verified by the user or companion plugin.
 * - UTILITY_ONLY: Passive mode on unverified / public multiplayer servers (HUD, wireframe outline, statistics, block inspect only; NO automated mining or automated movement).
 */
public enum OperatingMode {
    SINGLEPLAYER("Singleplayer (Full Auto)", Formatting.GREEN, true, true),
    AUTHORIZED_SERVER("Authorized Server (Permitted)", Formatting.AQUA, true, true),
    UTILITY_ONLY("Utility Only (Passive / Safe)", Formatting.GOLD, false, false);

    private final String displayName;
    private final Formatting color;
    private final boolean allowAutoMine;
    private final boolean allowAutoWalk;

    OperatingMode(String displayName, Formatting color, boolean allowAutoMine, boolean allowAutoWalk) {
        this.displayName = displayName;
        this.color = color;
        this.allowAutoMine = allowAutoMine;
        this.allowAutoWalk = allowAutoWalk;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Formatting getColor() {
        return color;
    }

    public boolean isAutoMineAllowed() {
        return allowAutoMine;
    }

    public boolean isAutoWalkAllowed() {
        return allowAutoWalk;
    }

    public Text getText() {
        return Text.literal(displayName).formatted(color);
    }
}

