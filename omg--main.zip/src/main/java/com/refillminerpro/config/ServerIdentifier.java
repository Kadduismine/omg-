package com.refillminerpro.config;

import java.util.Locale;

/**
 * Normalizes and categorizes Minecraft server connection addresses and endpoints.
 * Reliably distinguishes servers by host AND port, handles IPv4, bracketed/unbracketed IPv6,
 * domain normalization, and singleplayer worlds.
 */
public class ServerIdentifier {

    public static final int DEFAULT_PORT = 25565;

    /**
     * Normalizes a server or world address into a canonical endpoint identifier.
     * Preserves custom ports, normalizes default port 25565, formats IPv6 properly,
     * strips trailing dots, lowercases hostnames, and distinguishes singleplayer worlds.
     */
    public static String normalize(String address) {
        if (address == null || address.trim().isEmpty()) {
            return "unknown";
        }
        String clean = address.trim().toLowerCase(Locale.ROOT);

        // Singleplayer handling
        if (clean.equals("singleplayer")) {
            return "singleplayer:default";
        }
        if (clean.startsWith("singleplayer:")) {
            String world = clean.substring("singleplayer:".length()).trim();
            return world.isEmpty() ? "singleplayer:default" : "singleplayer:" + world;
        }
        if (clean.startsWith("singleplayer_")) {
            String world = clean.substring("singleplayer_".length()).trim();
            return world.isEmpty() ? "singleplayer:default" : "singleplayer:" + world;
        }

        // Bracketed IPv6 handling: [2001:db8::1] or [2001:db8::1]:25566
        if (clean.startsWith("[")) {
            int closeBracket = clean.indexOf(']');
            if (closeBracket > 1) {
                String ip6Host = clean.substring(1, closeBracket).trim();
                int port = DEFAULT_PORT;
                if (clean.length() > closeBracket + 1 && clean.charAt(closeBracket + 1) == ':') {
                    String portStr = clean.substring(closeBracket + 2).trim();
                    try {
                        port = Integer.parseInt(portStr);
                        if (port <= 0 || port > 65535) port = DEFAULT_PORT;
                    } catch (NumberFormatException ignored) {}
                }
                return String.format(Locale.ROOT, "[%s]:%d", ip6Host, port);
            }
        }

        // Unbracketed IPv6 with multiple colons: e.g. 2001:db8::1
        long colonCount = clean.chars().filter(ch -> ch == ':').count();
        if (colonCount >= 2) {
            return String.format(Locale.ROOT, "[%s]:%d", clean, DEFAULT_PORT);
        }

        // Hostname or IPv4 with optional port: e.g. play.example.net:25565 or 192.168.1.1:25566
        String host = clean;
        int port = DEFAULT_PORT;

        if (colonCount == 1) {
            int colonIdx = clean.indexOf(':');
            host = clean.substring(0, colonIdx).trim();
            String portStr = clean.substring(colonIdx + 1).trim();
            try {
                port = Integer.parseInt(portStr);
                if (port <= 0 || port > 65535) port = DEFAULT_PORT;
            } catch (NumberFormatException ignored) {
                host = clean;
                port = DEFAULT_PORT;
            }
        }

        // Strip trailing dots from hostname (e.g. play.example.net. -> play.example.net)
        while (host.endsWith(".")) {
            host = host.substring(0, host.length() - 1);
        }
        host = host.trim();
        if (host.isEmpty()) {
            return "unknown";
        }

        return String.format(Locale.ROOT, "%s:%d", host, port);
    }

    /**
     * Extracts the host portion of a normalized endpoint (without port or brackets).
     */
    public static String getHostOnly(String normalizedEndpoint) {
        if (normalizedEndpoint == null || normalizedEndpoint.isEmpty()) return "unknown";
        if (normalizedEndpoint.startsWith("singleplayer:")) {
            return normalizedEndpoint;
        }
        if (normalizedEndpoint.startsWith("[")) {
            int closeBracket = normalizedEndpoint.indexOf(']');
            if (closeBracket > 1) {
                return normalizedEndpoint.substring(1, closeBracket);
            }
        }
        int colonIdx = normalizedEndpoint.lastIndexOf(':');
        if (colonIdx > 0) {
            return normalizedEndpoint.substring(0, colonIdx);
        }
        return normalizedEndpoint;
    }

    /**
     * Extracts the port from a normalized endpoint.
     */
    public static int getPort(String normalizedEndpoint) {
        if (normalizedEndpoint == null || normalizedEndpoint.startsWith("singleplayer")) {
            return DEFAULT_PORT;
        }
        int colonIdx = normalizedEndpoint.lastIndexOf(':');
        if (colonIdx >= 0 && colonIdx < normalizedEndpoint.length() - 1) {
            try {
                return Integer.parseInt(normalizedEndpoint.substring(colonIdx + 1));
            } catch (NumberFormatException ignored) {}
        }
        return DEFAULT_PORT;
    }

    /**
     * Checks if the normalized host belongs to the Stray network.
     */
    public static boolean isStrayNetwork(String normalizedEndpoint) {
        if (normalizedEndpoint == null) return false;
        String host = getHostOnly(normalizedEndpoint);
        return host.equals("stray.gg") || host.endsWith(".stray.gg");
    }

    /**
     * Checks if the normalized host belongs to SpaceMC.
     */
    public static boolean isSpaceMCNetwork(String normalizedEndpoint) {
        if (normalizedEndpoint == null) return false;
        String host = getHostOnly(normalizedEndpoint);
        return host.equals("spacemc.lol") || host.endsWith(".spacemc.lol");
    }

    /**
     * Provides a human-readable display name for the recognized environment.
     */
    public static String getNetworkDisplayName(String normalizedEndpoint) {
        if (normalizedEndpoint == null || normalizedEndpoint.equals("unknown")) return "Unknown Environment";
        if (normalizedEndpoint.startsWith("singleplayer:")) {
            String world = normalizedEndpoint.substring("singleplayer:".length());
            return "Singleplayer (" + world + ")";
        }
        if (isStrayNetwork(normalizedEndpoint)) return "Stray Network (" + normalizedEndpoint + ")";
        if (isSpaceMCNetwork(normalizedEndpoint)) return "SpaceMC Network (" + normalizedEndpoint + ")";
        return normalizedEndpoint;
    }
}
