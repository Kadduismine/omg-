package com.refillminerpro.config;

/**
 * Movement smoothness presets for forward mining advance.
 * Controls the pacing and step increments when closing the gap to the mining face.
 */
public enum MovementSmoothness {
    SLOW("Slow", 0.5f),
    NORMAL("Normal", 1.0f),
    FAST("Fast", 1.5f);

    private final String displayName;
    private final float speedFactor;

    MovementSmoothness(String displayName, float speedFactor) {
        this.displayName = displayName;
        this.speedFactor = speedFactor;
    }

    public String getDisplayName() {
        return displayName;
    }

    public float getSpeedFactor() {
        return speedFactor;
    }

    public MovementSmoothness next() {
        MovementSmoothness[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}

