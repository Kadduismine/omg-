package com.refillminerpro.config;

import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;

import java.util.Objects;
import java.util.UUID;

/**
 * Represents a persistent named area selection profile tied to a specific server/world and dimension.
 * Stores raw corners and precalculated normalized boundaries, dimensions, and volume.
 */
public class SavedAreaProfile {

    private String id;
    private String name;
    private String server;
    private String dimension;

    // Corner coordinates
    private int x1;
    private int y1;
    private int z1;
    private int x2;
    private int y2;
    private int z2;

    // Normalized bounds
    private int minX;
    private int minY;
    private int minZ;
    private int maxX;
    private int maxY;
    private int maxZ;

    // Size metrics
    private int width;
    private int height;
    private int depth;
    private long volume;

    // Timestamps
    private long createdAtMs;
    private long updatedAtMs;

    // State flag
    private boolean active;

    public SavedAreaProfile() {
        this.id = UUID.randomUUID().toString();
        this.createdAtMs = System.currentTimeMillis();
        this.updatedAtMs = this.createdAtMs;
    }

    public SavedAreaProfile(String name, String server, String dimension, BlockPos c1, BlockPos c2) {
        this(name, server, dimension,
                c1 != null ? c1.getX() : 0, c1 != null ? c1.getY() : 0, c1 != null ? c1.getZ() : 0,
                c2 != null ? c2.getX() : 0, c2 != null ? c2.getY() : 0, c2 != null ? c2.getZ() : 0);
    }

    public SavedAreaProfile(String name, String server, String dimension, int x1, int y1, int z1, int x2, int y2, int z2) {
        this.id = UUID.randomUUID().toString();
        this.name = (name != null && !name.trim().isEmpty()) ? name.trim() : "Saved Area";
        this.server = ServerIdentifier.normalize(server);
        this.dimension = (dimension != null && !dimension.trim().isEmpty()) ? dimension.trim() : "minecraft:overworld";
        this.x1 = x1;
        this.y1 = y1;
        this.z1 = z1;
        this.x2 = x2;
        this.y2 = y2;
        this.z2 = z2;
        this.createdAtMs = System.currentTimeMillis();
        this.updatedAtMs = this.createdAtMs;
        recalculateBounds();
    }

    public static SavedAreaProfile fromRegion(String name, String server, String dimension, BlockRegion region) {
        if (region == null) return null;
        return new SavedAreaProfile(name, server, dimension,
                region.getCorner1().getX(), region.getCorner1().getY(), region.getCorner1().getZ(),
                region.getCorner2().getX(), region.getCorner2().getY(), region.getCorner2().getZ());
    }

    /**
     * Recalculates normalized min/max coordinates, dimensions, and total volume safely.
     */
    public void recalculateBounds() {
        this.minX = Math.min(x1, x2);
        this.minY = Math.min(y1, y2);
        this.minZ = Math.min(z1, z2);

        this.maxX = Math.max(x1, x2);
        this.maxY = Math.max(y1, y2);
        this.maxZ = Math.max(z1, z2);

        this.width = maxX - minX + 1;
        this.height = maxY - minY + 1;
        this.depth = maxZ - minZ + 1;

        this.volume = (long) width * (long) height * (long) depth;
    }

    /**
     * Updates coordinates and recalculates bounds, updating the modification timestamp.
     */
    public void updateCoordinates(int x1, int y1, int z1, int x2, int y2, int z2) {
        this.x1 = x1;
        this.y1 = y1;
        this.z1 = z1;
        this.x2 = x2;
        this.y2 = y2;
        this.z2 = z2;
        this.updatedAtMs = System.currentTimeMillis();
        recalculateBounds();
    }

    public void updateFromRegion(BlockRegion region) {
        if (region == null) return;
        updateCoordinates(
                region.getCorner1().getX(), region.getCorner1().getY(), region.getCorner1().getZ(),
                region.getCorner2().getX(), region.getCorner2().getY(), region.getCorner2().getZ()
        );
    }

    /**
     * Checks if this profile matches the given server and dimension.
     */
    public boolean matches(String targetServer, String targetDimension) {
        if (targetServer == null || targetDimension == null) return false;
        String normalizedTarget = ServerIdentifier.normalize(targetServer);
        return Objects.equals(this.server, normalizedTarget) && Objects.equals(this.dimension, targetDimension);
    }

    /**
     * Converts this saved area profile into an immutable BlockRegion.
     */
    public BlockRegion toBlockRegion() {
        return new BlockRegion(new BlockPos(x1, y1, z1), new BlockPos(x2, y2, z2));
    }

    /**
     * Creates a deep duplicate of this profile with a new ID and duplicate name.
     */
    public SavedAreaProfile duplicate() {
        SavedAreaProfile copy = new SavedAreaProfile(
                this.name + " (Copy)",
                this.server,
                this.dimension,
                this.x1, this.y1, this.z1,
                this.x2, this.y2, this.z2
        );
        copy.active = false;
        return copy;
    }

    // Getters and Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name != null ? name.trim() : "Saved Area";
        this.updatedAtMs = System.currentTimeMillis();
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = ServerIdentifier.normalize(server);
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public int getX1() {
        return x1;
    }

    public int getY1() {
        return y1;
    }

    public int getZ1() {
        return z1;
    }

    public int getX2() {
        return x2;
    }

    public int getY2() {
        return y2;
    }

    public int getZ2() {
        return z2;
    }

    public int getMinX() {
        return minX;
    }

    public int getMinY() {
        return minY;
    }

    public int getMinZ() {
        return minZ;
    }

    public int getMaxX() {
        return maxX;
    }

    public int getMaxY() {
        return maxY;
    }

    public int getMaxZ() {
        return maxZ;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getDepth() {
        return depth;
    }

    public long getVolume() {
        return volume;
    }

    public long getCreatedAtMs() {
        return createdAtMs;
    }

    public long getUpdatedAtMs() {
        return updatedAtMs;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public BlockPos getCorner1Pos() {
        return new BlockPos(x1, y1, z1);
    }

    public BlockPos getCorner2Pos() {
        return new BlockPos(x2, y2, z2);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SavedAreaProfile that = (SavedAreaProfile) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

