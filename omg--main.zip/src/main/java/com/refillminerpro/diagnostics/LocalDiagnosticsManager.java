package com.refillminerpro.diagnostics;

import com.refillminerpro.client.RefillMinerClient;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.OperatingMode;
import com.refillminerpro.config.ServerIdentifier;
import com.refillminerpro.config.ServerProfile;
import com.refillminerpro.engine.MiningDebugInfo;
import com.refillminerpro.engine.MiningEngine;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Generates structured, sanitized local diagnostic reports for analyzing kicks, disconnects, and errors.
 * Strictly avoids logging passwords, session tokens, or private chat contents.
 */
public class LocalDiagnosticsManager {

    public static File generateDiagnosticReport() {
        MinecraftClient mc = MinecraftClient.getInstance();
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance == null) return null;

        ModConfig config = clientInstance.getConfig();
        MiningEngine engine = clientInstance.getMiningEngine();

        String serverId = clientInstance.getServerIdentifier(mc);
        ServerProfile profile = config.getProfileForEnvironment(serverId);
        OperatingMode opMode = clientInstance.getCurrentOperatingMode();

        File runDir = FabricLoader.getInstance().getGameDir().toFile();
        File logDir = new File(runDir, "logs");
        if (!logDir.exists()) logDir.mkdirs();

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
        File reportFile = new File(logDir, "refillminer_diagnostics_" + timestamp + ".txt");

        try (PrintWriter pw = new PrintWriter(new FileWriter(reportFile))) {
            pw.println("================================================================================");
            pw.println("             REFILL MINER PRO — LOCAL DIAGNOSTIC REPORT");
            pw.println("================================================================================");
            pw.println("Generated: " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            pw.println();

            pw.println("[1] ENVIRONMENT & RUNTIME METADATA");
            pw.println("--------------------------------------------------------------------------------");
            pw.println("Minecraft Version : 1.21.11");
            pw.println("Fabric Loader     : " + FabricLoader.getInstance().getModContainer("fabricloader").map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("Unknown"));

            Optional<ModContainer> modOpt = FabricLoader.getInstance().getModContainer("refillminerpro");
            pw.println("Refill Miner Pro  : " + modOpt.map(m -> m.getMetadata().getVersion().getFriendlyString()).orElse("1.0.0"));
            pw.println("Java Version      : " + System.getProperty("java.version") + " (" + System.getProperty("java.vendor") + ")");
            pw.println("Operating System  : " + System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ")");
            pw.println();

            pw.println("[2] SERVER POLICY & OPERATING MODE");
            pw.println("--------------------------------------------------------------------------------");
            pw.println("Target Server / World : " + serverId);
            pw.println("Network Classification: " + ServerIdentifier.getNetworkDisplayName(serverId));
            pw.println("Current Operating Mode: " + opMode.name() + " (" + opMode.getDisplayName() + ")");
            pw.println("Automation Allowed    : " + opMode.isAutoMineAllowed());
            pw.println("Auto-Movement Allowed : " + opMode.isAutoWalkAllowed());
            pw.println("Policy Notes          : " + profile.getPolicyNotes());
            pw.println("Policy Rule Reference : " + profile.getPolicyRuleReference());
            pw.println("Last Policy Review    : " + profile.getLastReviewedDate());
            pw.println();

            pw.println("[3] MINING CONTROLLER & AUTOMATION STATE");
            pw.println("--------------------------------------------------------------------------------");
            pw.println("Auto Mine Enabled     : " + config.isAutoMineEnabled());
            pw.println("Engine Status         : " + engine.getStatus().name());
            pw.println("Navigation State      : " + engine.getNavigationState().name());
            pw.println("Status Detail         : " + engine.getStatusDetail().getString());
            pw.println("Current Target Block  : " + (engine.getCurrentTarget() != null ? engine.getCurrentTarget().toShortString() : "None"));
            pw.println("Current Target Face   : " + MiningDebugInfo.currentTargetFace);
            pw.println("Rotation Aim Ready    : " + MiningDebugInfo.rotationReady);
            pw.println("Line of Sight Valid   : " + MiningDebugInfo.lineOfSightValid);
            pw.println("First Obstructing Pos : " + (MiningDebugInfo.firstObstructingBlock != null ? MiningDebugInfo.firstObstructingBlock.toShortString() : "None"));
            pw.println("Target Distance (m)   : " + String.format(java.util.Locale.ROOT, "%.2f", MiningDebugInfo.distanceToTarget));
            pw.println("Within Legal Reach    : " + MiningDebugInfo.withinReach);
            pw.println("Vanilla Break Progress: " + MiningDebugInfo.vanillaBreakingProgress + "/10 (" + MiningDebugInfo.miningProgressPercent + "%)");
            pw.println("Block Confirmed Broken: " + MiningDebugInfo.blockConfirmedRemoved);
            pw.println("Last Skip/Fail Reason : " + MiningDebugInfo.whySkippedReason);
            pw.println("Queued Targets Count  : " + engine.getQueuedTargetsCount());
            pw.println("Mined Session Blocks  : " + engine.getSessionMinedBlocks());
            pw.println("Tool Switch Dynamic   : " + config.isAutoSwitchTool());
            pw.println("Area Mining Footprint : " + config.getAreaMiningWidth() + "x" + config.getAreaMiningHeight() + " (Enabled: " + config.isAreaMiningEnabled() + ")");
            pw.println();

            pw.println("[4] DIAGNOSTIC LOG & ERROR REASONS");
            pw.println("--------------------------------------------------------------------------------");
            if (opMode == OperatingMode.UTILITY_ONLY && config.isAutoMineEnabled()) {
                pw.println("COMPLIANCE NOTE: Automation was requested while connected to an unverified multiplayer server.");
                pw.println("Action: Mining engine automatically inhibited to prevent rule / unfair-advantage violations.");
            } else if (engine.getStatus().name().equals("TEMPORARILY_BLOCKED")) {
                pw.println("REJECTION NOTE: Target is temporarily blocked or line of sight was obstructed.");
                pw.println("First-wall obstruction pos: " + (MiningDebugInfo.firstObstructingBlock != null ? MiningDebugInfo.firstObstructingBlock.toShortString() : "N/A"));
            } else {
                pw.println("No local controller faults detected. System operating within compliance parameters.");
            }
            pw.println();
            pw.println("================================================================================");
            pw.println("Notice: This diagnostic report was generated locally and contains no credentials.");
            pw.println("================================================================================");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return reportFile;
    }
}

