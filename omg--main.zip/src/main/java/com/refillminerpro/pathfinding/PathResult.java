package com.refillminerpro.pathfinding;

import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.List;

/**
 * Result of an A* path search containing the computed waypoint sequence.
 */
public class PathResult {
    public enum Status {
        FOUND,
        NOT_FOUND,
        ALREADY_AT_TARGET,
        TIMED_OUT
    }

    private final Status status;
    private final List<PathNode> nodes;
    private final double totalCost;

    public PathResult(Status status, List<PathNode> nodes, double totalCost) {
        this.status = status;
        this.nodes = nodes != null ? Collections.unmodifiableList(nodes) : Collections.emptyList();
        this.totalCost = totalCost;
    }

    public static PathResult notFound() {
        return new PathResult(Status.NOT_FOUND, Collections.emptyList(), Double.MAX_VALUE);
    }

    public static PathResult alreadyAtTarget() {
        return new PathResult(Status.ALREADY_AT_TARGET, Collections.emptyList(), 0.0);
    }

    public Status getStatus() {
        return status;
    }

    public boolean isSuccess() {
        return status == Status.FOUND || status == Status.ALREADY_AT_TARGET;
    }

    public List<PathNode> getNodes() {
        return nodes;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public int getLength() {
        return nodes.size();
    }
}

