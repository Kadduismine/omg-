package com.refillminerpro.pathfinding;

import net.minecraft.util.math.BlockPos;

/**
 * Node in the 3D A* search graph.
 */
public class PathNode implements Comparable<PathNode> {
    public final BlockPos pos;
    public double gCost; // Cost from start to this node
    public double hCost; // Estimated cost from this node to goal
    public double fCost; // Total cost (g + h)
    public PathNode parent;
    public PathAction action;

    public PathNode(BlockPos pos, double gCost, double hCost, PathNode parent, PathAction action) {
        this.pos = pos;
        this.gCost = gCost;
        this.hCost = hCost;
        this.fCost = gCost + hCost;
        this.parent = parent;
        this.action = action;
    }

    @Override
    public int compareTo(PathNode other) {
        int cmp = Double.compare(this.fCost, other.fCost);
        if (cmp == 0) {
            // Stable tie-breaking: prefer lower heuristic (closer to target)
            return Double.compare(this.hCost, other.hCost);
        }
        return cmp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PathNode other)) return false;
        return pos.equals(other.pos);
    }

    @Override
    public int hashCode() {
        return pos.hashCode();
    }
}

