package com.refillminerpro.pathfinding;

/**
 * Action required to traverse from one path node to another.
 */
public enum PathAction {
    WALK,
    JUMP_UP,
    STEP_DOWN,
    FALL_DOWN
}

