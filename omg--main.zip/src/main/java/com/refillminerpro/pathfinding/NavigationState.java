package com.refillminerpro.pathfinding;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * High-level navigation and automation states for Refill Miner Pro.
 */
public enum NavigationState {
    IDLE("Idle", Formatting.GRAY),
    PLANNING_ROUTE("Planning Route", Formatting.AQUA),
    FOLLOWING_ROUTE("Following Route", Formatting.BLUE),
    APPROACHING_TARGET("Approaching Target", Formatting.YELLOW),
    MINING("Mining", Formatting.GREEN),
    RECALCULATING_ROUTE("Recalculating Route", Formatting.GOLD),
    TEMPORARILY_BLOCKED("Temporarily Blocked", Formatting.LIGHT_PURPLE),
    NO_VALID_PATH("No Valid Path", Formatting.RED),
    PAUSED("Paused", Formatting.WHITE);

    private final String displayName;
    private final Formatting formatting;

    NavigationState(String displayName, Formatting formatting) {
        this.displayName = displayName;
        this.formatting = formatting;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Formatting getFormatting() {
        return formatting;
    }

    public Text getText() {
        return Text.literal(displayName).formatted(formatting);
    }
}

