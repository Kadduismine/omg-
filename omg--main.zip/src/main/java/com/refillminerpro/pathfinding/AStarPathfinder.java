package com.refillminerpro.pathfinding;

import com.refillminerpro.config.ModConfig;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * High-performance, low-latency 3D A* pathfinder tailored for Minecraft 1.21.11 client navigation.
 * Features:
 * - Direct Line-of-Sight Raycast shortcut (skips graph search when a direct route is open)
 * - Goal standability caching and reachability testing
 * - Fast open/closed set indexing with primitive coordinate hashing
 * - Safe diagonal transitions and intelligent jump/drop traversal
 * - Fallback to closest partial path on search limits
 */
public class AStarPathfinder {
    private static final Logger LOGGER = LoggerFactory.getLogger("RefillMinerPro/Pathfinder");

    private static final int DEFAULT_MAX_NODES = 1200;
    private final ModConfig config;

    public AStarPathfinder(ModConfig config) {
        this.config = config;
    }

    /**
     * Finds a rapid path from the player's current standing position to a valid standing position
     * from which targetBlock can be mined.
     */
    public PathResult findPath(ClientWorld world, BlockPos startPos, BlockPos targetBlock, double maxMiningReach) {
        if (world == null || startPos == null || targetBlock == null) {
            return PathResult.notFound();
        }

        // 1. Check if already within comfortable mining reach
        Vec3d startEye = new Vec3d(startPos.getX() + 0.5, startPos.getY() + 1.62, startPos.getZ() + 0.5);
        Vec3d targetCenter = Vec3d.ofCenter(targetBlock);
        if (startEye.distanceTo(targetCenter) <= maxMiningReach - 0.3) {
            return PathResult.alreadyAtTarget();
        }

        // 2. Direct Walk Shortcut: If target is within ~8 blocks on roughly the same level and direct path is walk-safe
        if (isDirectWalkSafe(world, startPos, targetBlock, maxMiningReach)) {
            List<PathNode> directNodes = buildDirectPath(world, startPos, targetBlock, maxMiningReach);
            if (directNodes != null && !directNodes.isEmpty()) {
                return new PathResult(PathResult.Status.FOUND, directNodes, directNodes.size());
            }
        }

        // 3. Fast Bounded 3D A* Search
        int maxSearchNodes = config != null ? config.getPathfindingSearchLimit() : DEFAULT_MAX_NODES;

        PriorityQueue<PathNode> openQueue = new PriorityQueue<>(128);
        Map<BlockPos, PathNode> openMap = new HashMap<>(256);
        Set<BlockPos> closedSet = new HashSet<>(256);

        double initialH = heuristic(startPos, targetBlock);
        PathNode startNode = new PathNode(startPos.toImmutable(), 0.0, initialH, null, PathAction.WALK);
        openQueue.add(startNode);
        openMap.put(startNode.pos, startNode);

        PathNode closestNodeSoFar = startNode;
        double minHSoFar = initialH;

        int nodesSearched = 0;

        while (!openQueue.isEmpty() && nodesSearched < maxSearchNodes) {
            PathNode current = openQueue.poll();
            openMap.remove(current.pos);
            closedSet.add(current.pos);
            nodesSearched++;

            // Goal test: Can the player mine targetBlock from this standing node position?
            Vec3d currentEye = new Vec3d(current.pos.getX() + 0.5, current.pos.getY() + 1.62, current.pos.getZ() + 0.5);
            double distToTarget = currentEye.distanceTo(targetCenter);

            if (distToTarget <= maxMiningReach - 0.4) {
                if (hasLineOfSight(world, currentEye, targetBlock)) {
                    return buildResult(current, PathResult.Status.FOUND);
                }
            }

            // Track closest node for fallback partial paths
            if (current.hCost < minHSoFar) {
                minHSoFar = current.hCost;
                closestNodeSoFar = current;
            }

            // Explore 4 Cardinal Directions
            for (Direction dir : Direction.Type.HORIZONTAL) {
                exploreCardinalNeighbor(world, current, dir, targetBlock, openQueue, openMap, closedSet);
            }
        }

        // Fallback: If full path couldn't be completed, return partial path to the closest explored node
        if (closestNodeSoFar != startNode && minHSoFar < initialH - 0.8) {
            return buildResult(closestNodeSoFar, PathResult.Status.FOUND);
        }

        return PathResult.notFound();
    }

    /**
     * Checks if a direct horizontal corridor from startPos towards targetBlock is open and walkable.
     */
    private boolean isDirectWalkSafe(ClientWorld world, BlockPos startPos, BlockPos targetBlock, double maxMiningReach) {
        int dx = targetBlock.getX() - startPos.getX();
        int dy = targetBlock.getY() - startPos.getY();
        int dz = targetBlock.getZ() - startPos.getZ();
        double horizontalDistSq = dx * dx + dz * dz;

        if (horizontalDistSq > 100.0 || Math.abs(dy) > 3) {
            return false;
        }

        int steps = (int) Math.ceil(Math.sqrt(horizontalDistSq));
        if (steps <= 0) return false;

        double stepX = (double) dx / steps;
        double stepZ = (double) dz / steps;

        int lastX = startPos.getX();
        int lastZ = startPos.getZ();
        int currY = startPos.getY();

        for (int i = 1; i <= steps; i++) {
            int cx = (int) Math.round(startPos.getX() + stepX * i);
            int cz = (int) Math.round(startPos.getZ() + stepZ * i);

            if (cx == lastX && cz == lastZ) continue;
            lastX = cx;
            lastZ = cz;

            BlockPos candidate = new BlockPos(cx, currY, cz);
            if (isValidStandingPos(world, candidate)) {
                // Same level is solid
            } else if (isValidStandingPos(world, candidate.up())) {
                currY = currY + 1;
            } else if (isValidStandingPos(world, candidate.down())) {
                currY = currY - 1;
            } else {
                return false; // Obstacle or gap
            }

            // Reached mining range
            Vec3d eye = new Vec3d(cx + 0.5, currY + 1.62, cz + 0.5);
            if (eye.distanceTo(Vec3d.ofCenter(targetBlock)) <= maxMiningReach - 0.4) {
                return true;
            }
        }
        return false;
    }

    private List<PathNode> buildDirectPath(ClientWorld world, BlockPos startPos, BlockPos targetBlock, double maxMiningReach) {
        List<PathNode> nodes = new ArrayList<>();
        int dx = targetBlock.getX() - startPos.getX();
        int dz = targetBlock.getZ() - startPos.getZ();
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        int steps = (int) Math.ceil(horizontalDist);

        double stepX = (double) dx / steps;
        double stepZ = (double) dz / steps;

        int lastX = startPos.getX();
        int lastZ = startPos.getZ();
        int currY = startPos.getY();
        PathNode prev = null;

        for (int i = 1; i <= steps; i++) {
            int cx = (int) Math.round(startPos.getX() + stepX * i);
            int cz = (int) Math.round(startPos.getZ() + stepZ * i);

            if (cx == lastX && cz == lastZ) continue;
            lastX = cx;
            lastZ = cz;

            BlockPos candidate = new BlockPos(cx, currY, cz);
            PathAction action = PathAction.WALK;

            if (isValidStandingPos(world, candidate)) {
                // Flat walk
            } else if (isValidStandingPos(world, candidate.down())) {
                currY = currY - 1;
                candidate = candidate.down();
                action = PathAction.STEP_DOWN;
            } else {
                return null; // Route blocked by elevation; automated jumping is completely disabled
            }

            PathNode node = new PathNode(candidate, i, heuristic(candidate, targetBlock), prev, action);
            nodes.add(node);
            prev = node;

            Vec3d eye = new Vec3d(cx + 0.5, currY + 1.62, cz + 0.5);
            if (eye.distanceTo(Vec3d.ofCenter(targetBlock)) <= maxMiningReach - 0.4) {
                break;
            }
        }
        return nodes;
    }

    private void exploreCardinalNeighbor(ClientWorld world, PathNode current, Direction dir, BlockPos targetBlock,
                                         PriorityQueue<PathNode> openQueue, Map<BlockPos, PathNode> openMap, Set<BlockPos> closedSet) {
        int nx = current.pos.getX() + dir.getOffsetX();
        int nz = current.pos.getZ() + dir.getOffsetZ();
        int cy = current.pos.getY();

        // 1. Flat walk (y)
        checkAndAddNode(world, current, new BlockPos(nx, cy, nz), 1.0, PathAction.WALK, targetBlock, openQueue, openMap, closedSet);

        // 2. Small elevation step up 1 block (y + 1) with safe overhead clearance
        BlockPos jumpFoot = new BlockPos(nx, cy + 1, nz);
        if (isPassable(world, current.pos.up(2)) && isPassable(world, new BlockPos(nx, cy + 2, nz))) {
            checkAndAddNode(world, current, jumpFoot, 1.3, PathAction.JUMP_UP, targetBlock, openQueue, openMap, closedSet);
        }

        // 3. Step down 1, 2, or 3 blocks
        for (int drop = 1; drop <= 3; drop++) {
            BlockPos dropFoot = new BlockPos(nx, cy - drop, nz);
            BlockPos dropHead = dropFoot.up();
            if (!isPassable(world, new BlockPos(nx, cy, nz)) || !isPassable(world, dropHead)) {
                break;
            }
            double cost = drop == 1 ? 1.05 : (drop == 2 ? 1.4 : 2.0);
            PathAction action = drop == 1 ? PathAction.STEP_DOWN : PathAction.FALL_DOWN;
            if (checkAndAddNode(world, current, dropFoot, cost, action, targetBlock, openQueue, openMap, closedSet)) {
                break;
            }
        }

        // 4. Safe diagonal turns around corners (prevents corner-cutting through solid blocks)
        Direction rightDir = dir.rotateYClockwise();
        int diagX = nx + rightDir.getOffsetX();
        int diagZ = nz + rightDir.getOffsetZ();
        BlockPos diagPos = new BlockPos(diagX, cy, diagZ);
        BlockPos card1 = new BlockPos(nx, cy, nz);
        BlockPos card2 = new BlockPos(current.pos.getX() + rightDir.getOffsetX(), cy, current.pos.getZ() + rightDir.getOffsetZ());
        if (isPassable(world, card1) && isPassable(world, card1.up()) && isPassable(world, card2) && isPassable(world, card2.up())) {
            checkAndAddNode(world, current, diagPos, 1.414, PathAction.WALK, targetBlock, openQueue, openMap, closedSet);
        }
    }

    private boolean checkAndAddNode(ClientWorld world, PathNode current, BlockPos candidatePos, double moveCost, PathAction action,
                                    BlockPos targetBlock, PriorityQueue<PathNode> openQueue, Map<BlockPos, PathNode> openMap, Set<BlockPos> closedSet) {
        if (closedSet.contains(candidatePos)) {
            return false;
        }

        if (!isValidStandingPos(world, candidatePos)) {
            return false;
        }

        double tentativeG = current.gCost + moveCost;
        PathNode existing = openMap.get(candidatePos);

        if (existing == null) {
            double h = heuristic(candidatePos, targetBlock);
            PathNode neighbor = new PathNode(candidatePos.toImmutable(), tentativeG, h, current, action);
            openQueue.add(neighbor);
            openMap.put(candidatePos, neighbor);
            return true;
        } else if (tentativeG < existing.gCost) {
            openQueue.remove(existing);
            existing.gCost = tentativeG;
            existing.fCost = tentativeG + existing.hCost;
            existing.parent = current;
            existing.action = action;
            openQueue.add(existing);
            return true;
        }

        return true;
    }

    public boolean isValidStandingPos(ClientWorld world, BlockPos pos) {
        int cx = ChunkSectionPos.getSectionCoord(pos.getX());
        int cz = ChunkSectionPos.getSectionCoord(pos.getZ());
        if (!world.isChunkLoaded(cx, cz)) {
            return false;
        }

        // Ground check: pos.down() must be solid and non-hazardous
        BlockPos ground = pos.down();
        BlockState groundState = world.getBlockState(ground);
        if (!isSolidGround(world, ground, groundState)) {
            return false;
        }

        if (isHazardous(groundState)) {
            return false;
        }

        // Player clearance: feet (pos) and head (pos.up()) must be passable
        BlockState feetState = world.getBlockState(pos);
        if (!isPassable(world, pos, feetState)) {
            return false;
        }

        if (isHazardous(feetState)) {
            return false;
        }

        BlockPos headPos = pos.up();
        BlockState headState = world.getBlockState(headPos);
        if (!isPassable(world, headPos, headState)) {
            return false;
        }

        return !isHazardous(headState);
    }

    private boolean isSolidGround(ClientWorld world, BlockPos pos, BlockState state) {
        if (state.isAir()) return false;
        if (!state.getFluidState().isEmpty()) return false;
        return state.isOpaque() || state.isFullCube(world, pos) || state.isSolidBlock(world, pos);
    }

    private boolean isPassable(ClientWorld world, BlockPos pos) {
        return isPassable(world, pos, world.getBlockState(pos));
    }

    private boolean isPassable(ClientWorld world, BlockPos pos, BlockState state) {
        if (state.isAir()) return true;
        return state.getCollisionShape(world, pos).isEmpty();
    }

    private boolean isHazardous(BlockState state) {
        if (state.isOf(Blocks.LAVA) || state.isOf(Blocks.FIRE) || state.isOf(Blocks.SOUL_FIRE) ||
            state.isOf(Blocks.MAGMA_BLOCK) || state.isOf(Blocks.CACTUS) || state.isOf(Blocks.SWEET_BERRY_BUSH) ||
            state.isOf(Blocks.WITHER_ROSE) || state.isOf(Blocks.POWDER_SNOW)) {
            return true;
        }
        return false;
    }

    private double heuristic(BlockPos from, BlockPos goal) {
        double dx = goal.getX() - from.getX();
        double dy = goal.getY() - from.getY();
        double dz = goal.getZ() - from.getZ();
        // Euclidean distance with vertical weighting
        return Math.sqrt(dx * dx + dz * dz + dy * dy * 1.3);
    }

    public boolean hasLineOfSight(ClientWorld world, Vec3d eyePos, BlockPos targetPos) {
        if (world == null || eyePos == null || targetPos == null) return true;
        Vec3d targetCenter = Vec3d.ofCenter(targetPos);
        net.minecraft.util.hit.HitResult hit = world.raycast(new net.minecraft.world.RaycastContext(
                eyePos, targetCenter,
                net.minecraft.world.RaycastContext.ShapeType.OUTLINE,
                net.minecraft.world.RaycastContext.FluidHandling.NONE,
                net.minecraft.client.MinecraftClient.getInstance() != null ? net.minecraft.client.MinecraftClient.getInstance().player : null
        ));
        if (hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) {
            return ((net.minecraft.util.hit.BlockHitResult) hit).getBlockPos().equals(targetPos);
        }
        for (Direction dir : Direction.values()) {
            Vec3d faceCenter = targetCenter.add(Vec3d.of(dir.getVector()).multiply(0.48));
            net.minecraft.util.hit.HitResult faceHit = world.raycast(new net.minecraft.world.RaycastContext(
                    eyePos, faceCenter,
                    net.minecraft.world.RaycastContext.ShapeType.OUTLINE,
                    net.minecraft.world.RaycastContext.FluidHandling.NONE,
                    net.minecraft.client.MinecraftClient.getInstance() != null ? net.minecraft.client.MinecraftClient.getInstance().player : null
            ));
            if (faceHit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK && ((net.minecraft.util.hit.BlockHitResult) faceHit).getBlockPos().equals(targetPos)) {
                return true;
            }
        }
        return false;
    }

    private PathResult buildResult(PathNode endNode, PathResult.Status status) {
        List<PathNode> path = new ArrayList<>();
        PathNode curr = endNode;
        while (curr != null) {
            path.add(curr);
            curr = curr.parent;
        }
        Collections.reverse(path);
        // Remove start node so path contains the sequence of steps to take
        if (!path.isEmpty()) {
            path.remove(0);
        }
        return new PathResult(status, path, endNode.gCost);
    }
}
