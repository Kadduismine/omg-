package com.refillminerpro.mixin;

import com.refillminerpro.client.RefillMinerClient;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientWorld.class)
public class MixinClientWorld {
    @Inject(method = "handleBlockUpdate", at = @At("TAIL"))
    private void refillminerpro$onHandleBlockUpdate(BlockPos pos, BlockState state, int flags, CallbackInfo ci) {
        RefillMinerClient clientInstance = RefillMinerClient.getInstance();
        if (clientInstance != null) {
            clientInstance.onBlockUpdate(pos, state);
        }
    }
}

