package com.refillminerpro;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.TargetPriority;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ModConfigTest {

    @Test
    @DisplayName("Test Configuration Validation, Versioning, and Safe Initialization Defaults")
    public void testConfigSanitization() {
        ModConfig config = new ModConfig();

        // Feed invalid out-of-bound values and enable auto-mine
        config.setAutoMineEnabled(true);
        config.setPaused(true);
        config.setScanIntervalTicks(-5);
        config.setMaxRegionVolume(-100);
        config.setMaxQueuedTargets(50000);
        config.setRetryCooldownTicks(0);
        config.setAreaMiningWidth(50);
        config.setAreaMiningHeight(-2);
        config.setVisualUpdateTarget(1000);
        config.setTargetPriority(null);

        config.validate();

        // Schema version
        assertEquals(2, config.getConfigVersion());

        // Safe Initialization: automation must strictly be idle and unpaused on validation
        assertFalse(config.isAutoMineEnabled());
        assertFalse(config.isPaused());

        // Boundaries sanitized
        assertEquals(1, config.getScanIntervalTicks());
        assertEquals(1, config.getMaxRegionVolume());
        assertEquals(4096, config.getMaxQueuedTargets());
        assertEquals(1, config.getRetryCooldownTicks());
        assertEquals(16, config.getAreaMiningWidth());
        assertEquals(1, config.getAreaMiningHeight());
        assertEquals(500, config.getVisualUpdateTarget());
        assertEquals(TargetPriority.NEAREST_FIRST, config.getTargetPriority());
    }

    @Test
    @DisplayName("Test Configuration JSON Serialization Roundtrip with Runtime-Only Selection Enforcement")
    public void testSerializationRoundtrip() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        ModConfig original = new ModConfig();
        original.setAreaMiningEnabled(true);
        original.setAreaMiningWidth(6);
        original.setAreaMiningHeight(3);
        original.setAutoNavigate(true);
        original.setVisualUpdateTarget(200);
        original.setTargetPriority(TargetPriority.REFILL_PRIORITY);
        original.setWhitelist(List.of("minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"));
        original.setBlacklist(List.of("minecraft:bedrock"));

        // User settings for auto storage
        original.getAutoStorage().setEnabled(true);
        original.getAutoStorage().setCapacityThresholdPercent(85);

        String json = gson.toJson(original);
        assertNotNull(json);

        ModConfig deserialized = gson.fromJson(json, ModConfig.class);
        assertNotNull(deserialized);
        deserialized.validate();

        // Safe state: mining controller strictly idle
        assertFalse(deserialized.isAutoMineEnabled());
        assertFalse(deserialized.isPaused());

        // Persistent options preserved
        assertEquals(2, deserialized.getConfigVersion());
        assertTrue(deserialized.isAreaMiningEnabled());
        assertEquals(6, deserialized.getAreaMiningWidth());
        assertEquals(3, deserialized.getAreaMiningHeight());
        assertTrue(deserialized.isAutoNavigate());
        assertEquals(200, deserialized.getVisualUpdateTarget());
        assertEquals(TargetPriority.REFILL_PRIORITY, deserialized.getTargetPriority());
        assertEquals(2, deserialized.getWhitelist().size());
        assertTrue(deserialized.getWhitelist().contains("minecraft:diamond_ore"));
        assertEquals(1, deserialized.getBlacklist().size());

        // Auto Storage persisted
        assertTrue(deserialized.getAutoStorage().isEnabled());
        assertEquals(85, deserialized.getAutoStorage().getCapacityThresholdPercent());

        // Runtime-Only Selection constraint: savedSelections must be empty
        assertTrue(deserialized.getSavedSelections().isEmpty());
    }

    @Test
    @DisplayName("Test Persistent Area Selection: Selections and saved areas are preserved across validation")
    public void testPersistentSelectionPreservation() {
        ModConfig config = new ModConfig();
        config.getSavedSelections().put("play.spacemc.lol:25565", new ModConfig.SavedSelection(0, 60, 0, 10, 70, 10));
        assertEquals(1, config.getSavedSelections().size());

        // Validation preserves saved selections and migrates to savedAreas
        config.validate();
        assertFalse(config.getSavedSelections().isEmpty());
        assertFalse(config.getSavedAreas().isEmpty());
    }
}
