package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.TargetPriority;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningDebugInfo;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.MiningStatus;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PlayerControlledMiningEngineTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setAutoMineEnabled(true);
        config.setPlayerControlledMining(true);
        config.setEnforceAreaBoundary(true);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
    }

    @Test
    @DisplayName("Verify Boundary Guard: Region containment checks")
    public void testBoundaryContainment() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(10, 10, 10));
        engine.setActiveRegion(region);

        BlockPos insidePos = new BlockPos(5, 5, 5);
        BlockPos outsidePos = new BlockPos(15, 5, 5);

        assertTrue(region.contains(insidePos), "Inside block should be contained in region");
        assertFalse(region.contains(outsidePos), "Outside block should not be contained in region");
    }

    @Test
    @DisplayName("Verify Backward-Compatible TargetPriority Persistence")
    public void testTargetPriorityBackwardCompatibility() {
        // TargetPriority is retained for JSON config migration
        config.setTargetPriority(TargetPriority.NEAREST_FIRST);
        assertEquals(TargetPriority.NEAREST_FIRST, config.getTargetPriority());

        // Boundary enforcement getter & setter
        assertTrue(config.isEnforceAreaBoundary());
        config.setEnforceAreaBoundary(false);
        assertFalse(config.isEnforceAreaBoundary());
    }

    @Test
    @DisplayName("Verify Null Target Safety in MiningEngine")
    public void testNullTargetSafety() {
        // Calling onTargetBroken or onBlockStateChanged with null target must never throw NPE
        assertDoesNotThrow(() -> engine.onTargetBroken(null));
        assertDoesNotThrow(() -> engine.onBlockStateChanged(null, null));
        assertDoesNotThrow(() -> engine.handleServerRestrictionDetected(null, "Protected"));
        assertDoesNotThrow(() -> engine.cancelCurrentMining(null));
        assertDoesNotThrow(() -> engine.stopAttacking(null));
        assertDoesNotThrow(() -> engine.stopWalking(null));
    }

    @Test
    @DisplayName("Verify Mining Debug Info Tracking")
    public void testMiningDebugInfoTracking() {
        BlockPos testPos = new BlockPos(100, 64, -200);
        MiningDebugInfo.crosshairPos = testPos;
        MiningDebugInfo.crosshairBlockName = "minecraft:deepslate";
        MiningDebugInfo.crosshairInsideBoundary = true;
        MiningDebugInfo.crosshairFilterEligible = true;
        MiningDebugInfo.isHoldingAttack = true;

        assertEquals(testPos, MiningDebugInfo.crosshairPos);
        assertEquals("minecraft:deepslate", MiningDebugInfo.crosshairBlockName);
        assertTrue(MiningDebugInfo.crosshairInsideBoundary);
        assertTrue(MiningDebugInfo.crosshairFilterEligible);
        assertTrue(MiningDebugInfo.isHoldingAttack);
    }
}

