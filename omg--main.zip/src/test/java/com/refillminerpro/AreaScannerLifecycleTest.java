package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.engine.AreaScanner;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.MiningStatus;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AreaScannerLifecycleTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setAutoMineEnabled(true);
        config.setScanBatchSize(100);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
    }

    @Test
    @DisplayName("Verify AreaScanner multi-step scanning and boundary completion")
    public void testAreaScannerMultiStepProgress() {
        // 10 x 10 x 10 region = 1,000 blocks
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(9, 9, 9));
        assertEquals(1000, region.getVolume());

        AreaScanner scanner = new AreaScanner(filter);
        // Start scan with null world (simulating standalone test)
        scanner.startScan(region, null);
        assertTrue(scanner.isComplete());
        assertFalse(scanner.isScanning());

        // Test state lifecycle getters
        assertEquals(0, scanner.getDetectedTargets().size());
        assertNotNull(scanner.getLastReasonForZeroTargets());
    }

    @Test
    @DisplayName("Verify MiningEngine status summary strings for all operational phases")
    public void testMiningEngineStatusSummaries() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(4, 64, 4));
        engine.setActiveRegion(region);

        // 1. Initial Standby
        assertEquals("Standby — Ready", engine.getStatusSummary());

        // 2. Start scan phase
        engine.startAreaScan(null);
        // World was null, should transition cleanly to ERROR with diagnostic explanation
        assertEquals(MiningStatus.ERROR, engine.getStatus());
        assertTrue(engine.getStatusSummary().startsWith("Error — "));

        // 3. Queue targets manually and test MINING status summary
        engine.reset(false);
        engine.setActiveRegion(region);
        for (int i = 0; i < 5; i++) {
            engine.enqueueTarget(new BlockPos(i, 60, 0), false);
        }
        assertEquals(5, engine.getQueuedTargetsCount());
        assertEquals("Ready — 5 targets found", engine.getStatusSummary());

        // 4. Test target index calculation
        assertEquals(0, engine.getInitialBatchTargetCount());
    }

    @Test
    @DisplayName("Verify BlockFilter whitelist and blacklist caching and ID normalization")
    public void testBlockFilterCachingAndNormalization() {
        config.getWhitelist().clear();
        config.getWhitelist().add("iron_ore");
        config.getWhitelist().add("minecraft:diamond_ore");

        filter.updateCache();
        assertTrue(filter.getNormalizedWhitelist().contains("minecraft:iron_ore"));
        assertTrue(filter.getNormalizedWhitelist().contains("minecraft:diamond_ore"));

        config.getBlacklist().clear();
        config.getBlacklist().add("bedrock");
        filter.updateCache();
        assertTrue(filter.getNormalizedBlacklist().contains("minecraft:bedrock"));
    }

    @Test
    @DisplayName("Verify AreaScanner reset clears all tracking flags and diagnostics cleanly")
    public void testAreaScannerReset() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        AreaScanner scanner = new AreaScanner(filter);
        scanner.startScan(region, null);

        scanner.reset();
        assertFalse(scanner.isScanning());
        assertFalse(scanner.isComplete());
        assertFalse(scanner.hasError());
        assertEquals(0, scanner.getScannedBlocks());
        assertEquals(0, scanner.getTotalBlocks());
        assertEquals(0, scanner.getDetectedTargets().size());
        assertEquals("", scanner.getLastErrorMessage());
        assertEquals("", scanner.getLastReasonForZeroTargets());
    }
}

