package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.OperatingMode;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningDebugInfo;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.MiningState;
import com.refillminerpro.engine.MiningStatus;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NaturalMiningLifecycleTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setAutoMineEnabled(true);
        config.setPaused(false);
        config.setPlayerControlledMining(false);
        config.setMaxRetriesPerTarget(3);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
    }

    @Test
    @DisplayName("Verify operating modes permission matrix")
    public void testOperatingModes() {
        assertTrue(OperatingMode.SINGLEPLAYER.isAutoMineAllowed());
        assertTrue(OperatingMode.SINGLEPLAYER.isAutoWalkAllowed());

        assertTrue(OperatingMode.AUTHORIZED_SERVER.isAutoMineAllowed());
        assertTrue(OperatingMode.AUTHORIZED_SERVER.isAutoWalkAllowed());

        assertFalse(OperatingMode.UTILITY_ONLY.isAutoMineAllowed());
        assertFalse(OperatingMode.UTILITY_ONLY.isAutoWalkAllowed());
    }

    @Test
    @DisplayName("Verify clean lifecycle states enum sequence")
    public void testStateEnumIntegrity() {
        assertEquals("Idle", MiningState.IDLE.getLabel());
        assertEquals("Selecting Target", MiningState.SELECTING_NEXT_TARGET.getLabel());
        assertEquals("Validating Target", MiningState.VALIDATING_TARGET.getLabel());
        assertEquals("Aligning Aim", MiningState.ALIGNING_WITH_TARGET.getLabel());
        assertEquals("Starting Mining", MiningState.STARTING_MINING.getLabel());
        assertEquals("Mining in Progress", MiningState.MINING_IN_PROGRESS.getLabel());
        assertEquals("Waiting for Block Update", MiningState.WAITING_FOR_BLOCK_UPDATE.getLabel());
        assertEquals("Confirming Completion", MiningState.CONFIRMING_COMPLETION.getLabel());
        assertEquals("Recovering from Failure", MiningState.RECOVERING_FROM_FAILURE.getLabel());
        assertEquals("Paused", MiningState.PAUSED.getLabel());
    }

    @Test
    @DisplayName("Verify target lifecycle tracking and clean cleanup")
    public void testTargetLifecycleAndCleanup() {
        BlockPos min = new BlockPos(0, 60, 0);
        BlockPos max = new BlockPos(10, 65, 10);
        BlockRegion region = new BlockRegion(min, max);
        engine.setActiveRegion(region);

        BlockPos target = new BlockPos(5, 62, 5);
        assertTrue(engine.enqueueTarget(target, true));
        assertTrue(engine.isTargetQueuedOrActive(target));

        // When target is broken, onTargetBroken cleanly updates stats and queues
        engine.onTargetBroken(target);
        assertFalse(engine.isTargetQueuedOrActive(target));
        assertEquals(1, engine.getSessionMinedBlocks());

        // Test cancel mining resets rotation and attack safely
        engine.cancelCurrentMining(null);
        assertNull(engine.getCurrentTarget());
        assertEquals(MiningStatus.IDLE, engine.getStatus());
    }

    @Test
    @DisplayName("Verify diagnostic tracking captures all required metrics")
    public void testDiagnosticsTracking() {
        MiningDebugInfo.currentTarget = new BlockPos(100, 64, 100);
        MiningDebugInfo.currentTargetFace = "UP";
        MiningDebugInfo.miningState = MiningState.MINING_IN_PROGRESS;
        MiningDebugInfo.vanillaBreakingProgress = 5;
        MiningDebugInfo.miningProgressPercent = 50;
        MiningDebugInfo.distanceToTarget = 2.4;
        MiningDebugInfo.withinReach = true;
        MiningDebugInfo.rotationReady = true;
        MiningDebugInfo.lineOfSightValid = true;

        assertEquals(new BlockPos(100, 64, 100), MiningDebugInfo.currentTarget);
        assertEquals("UP", MiningDebugInfo.currentTargetFace);
        assertEquals(MiningState.MINING_IN_PROGRESS, MiningDebugInfo.miningState);
        assertEquals(5, MiningDebugInfo.vanillaBreakingProgress);
        assertEquals(50, MiningDebugInfo.miningProgressPercent);
        assertTrue(MiningDebugInfo.withinReach);
        assertTrue(MiningDebugInfo.rotationReady);
        assertTrue(MiningDebugInfo.lineOfSightValid);
    }
}

