package com.refillminerpro;

import com.refillminerpro.client.gui.picker.ItemCatalogue;
import com.refillminerpro.client.gui.picker.ItemCatalogueEntry;
import com.refillminerpro.client.gui.picker.ItemCategory;
import net.minecraft.util.Identifier;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class ItemCatalogueTest {

    @Test
    @DisplayName("Verify ItemCategory display names and classification")
    public void testItemCategories() {
        assertEquals("All", ItemCategory.ALL.getDisplayName());
        assertEquals("Building", ItemCategory.BUILDING.getDisplayName());
        assertEquals("Natural", ItemCategory.NATURAL.getDisplayName());
        assertEquals("Functional", ItemCategory.FUNCTIONAL.getDisplayName());
        assertEquals("Redstone", ItemCategory.REDSTONE.getDisplayName());
        assertEquals("Tools", ItemCategory.TOOLS.getDisplayName());
        assertEquals("Combat", ItemCategory.COMBAT.getDisplayName());
        assertEquals("Food", ItemCategory.FOOD.getDisplayName());
        assertEquals("Ingredients", ItemCategory.INGREDIENTS.getDisplayName());
        assertEquals("Modded", ItemCategory.MODDED.getDisplayName());
        assertEquals("Selected", ItemCategory.SELECTED.getDisplayName());
    }

    @Test
    @DisplayName("Verify ItemCatalogueEntry case-insensitive search and partial matching")
    public void testCatalogueEntrySearch() {
        Identifier id = Identifier.of("minecraft", "diamond_pickaxe");
        ItemCatalogueEntry entry = new ItemCatalogueEntry(id, null, "Diamond Pickaxe", "Minecraft", "minecraft", ItemCategory.TOOLS);

        assertEquals("minecraft:diamond_pickaxe", entry.getIdString());
        assertEquals("Diamond Pickaxe", entry.getDisplayName());
        assertEquals("Minecraft", entry.getModName());
        assertEquals(ItemCategory.TOOLS, entry.getCategory());
        assertFalse(entry.isModded());

        // Partial and case-insensitive matching
        assertTrue(entry.matchesSearch("diamond"));
        assertTrue(entry.matchesSearch("DIAMOND"));
        assertTrue(entry.matchesSearch("pick"));
        assertTrue(entry.matchesSearch("axe"));
        assertTrue(entry.matchesSearch("minecraft"));
        assertTrue(entry.matchesSearch("")); // Empty query matches all

        // Non-matching query
        assertFalse(entry.matchesSearch("netherite"));
        assertFalse(entry.matchesSearch("emerald"));
    }

    @Test
    @DisplayName("Verify Modded item detection and source searching")
    public void testModdedCatalogueEntry() {
        Identifier id = Identifier.of("techmod", "refined_uranium");
        ItemCatalogueEntry entry = new ItemCatalogueEntry(id, null, "Refined Uranium", "Tech Mod", "techmod", ItemCategory.INGREDIENTS);

        assertEquals("techmod:refined_uranium", entry.getIdString());
        assertEquals("Refined Uranium", entry.getDisplayName());
        assertEquals("Tech Mod", entry.getModName());
        assertTrue(entry.isModded());

        // Mod name & ID matching
        assertTrue(entry.matchesSearch("techmod"));
        assertTrue(entry.matchesSearch("Tech"));
        assertTrue(entry.matchesSearch("uranium"));

        // Modded category filtering
        assertTrue(entry.matchesCategory(ItemCategory.MODDED, false));
        assertTrue(entry.matchesCategory(ItemCategory.ALL, false));
        assertTrue(entry.matchesCategory(ItemCategory.INGREDIENTS, false));
        assertFalse(entry.matchesCategory(ItemCategory.FOOD, false));
    }

    @Test
    @DisplayName("Verify Category and Selection state preservation during filtering")
    public void testCategoryAndSelectionMatching() {
        Identifier id = Identifier.of("minecraft", "golden_apple");
        ItemCatalogueEntry entry = new ItemCatalogueEntry(id, null, "Golden Apple", "Minecraft", "minecraft", ItemCategory.FOOD);

        Set<String> selected = new HashSet<>();
        selected.add("minecraft:golden_apple");

        // Selected category check
        assertTrue(entry.matchesCategory(ItemCategory.SELECTED, selected.contains(entry.getIdString())));
        assertTrue(entry.matchesCategory(ItemCategory.FOOD, selected.contains(entry.getIdString())));
        assertTrue(entry.matchesCategory(ItemCategory.ALL, selected.contains(entry.getIdString())));
        assertFalse(entry.matchesCategory(ItemCategory.COMBAT, selected.contains(entry.getIdString())));

        // Deselected check
        selected.remove("minecraft:golden_apple");
        assertFalse(entry.matchesCategory(ItemCategory.SELECTED, selected.contains(entry.getIdString())));
    }

    @Test
    @DisplayName("Verify Category heuristic classification for vanilla and modded item IDs")
    public void testClassificationHeuristics() {
        assertEquals(ItemCategory.FOOD, ItemCatalogue.classify(Identifier.of("minecraft", "cooked_beef"), null, null));
        assertEquals(ItemCategory.COMBAT, ItemCatalogue.classify(Identifier.of("minecraft", "netherite_sword"), null, null));
        assertEquals(ItemCategory.TOOLS, ItemCatalogue.classify(Identifier.of("minecraft", "diamond_pickaxe"), null, null));
        assertEquals(ItemCategory.REDSTONE, ItemCatalogue.classify(Identifier.of("minecraft", "repeater"), null, null));
        assertEquals(ItemCategory.FUNCTIONAL, ItemCatalogue.classify(Identifier.of("minecraft", "chest"), null, null));
        assertEquals(ItemCategory.NATURAL, ItemCatalogue.classify(Identifier.of("minecraft", "deepslate_diamond_ore"), null, null));
        assertEquals(ItemCategory.INGREDIENTS, ItemCatalogue.classify(Identifier.of("minecraft", "raw_iron"), null, null));
        assertEquals(ItemCategory.BUILDING, ItemCatalogue.classify(Identifier.of("minecraft", "oak_planks"), null, null));
    }
}
