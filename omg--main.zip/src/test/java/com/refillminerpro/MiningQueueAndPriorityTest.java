package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.TargetPriority;
import com.refillminerpro.engine.AreaMiningCalculator;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MiningQueueAndPriorityTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setMaxQueuedTargets(5);
        config.setAutoMineEnabled(true);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
    }

    @Test
    @DisplayName("Test H1: Target deduplication and bounded queue limit")
    public void testBoundedQueueAndDeduplication() {
        BlockPos p1 = new BlockPos(1, 1, 1);
        BlockPos p2 = new BlockPos(2, 2, 2);
        BlockPos p3 = new BlockPos(3, 3, 3);
        BlockPos p4 = new BlockPos(4, 4, 4);
        BlockPos p5 = new BlockPos(5, 5, 5);
        BlockPos p6 = new BlockPos(6, 6, 6);

        // Deduplication test
        assertTrue(engine.enqueueTarget(p1, false));
        assertFalse(engine.enqueueTarget(p1, false)); // Duplicate rejected!
        assertEquals(1, engine.getQueuedTargetsCount());

        assertTrue(engine.enqueueTarget(p2, false));
        assertTrue(engine.enqueueTarget(p3, false));
        assertTrue(engine.enqueueTarget(p4, false));
        assertTrue(engine.enqueueTarget(p5, false));
        assertEquals(5, engine.getQueuedTargetsCount());

        // Queue bound limit (max 5)
        assertFalse(engine.enqueueTarget(p6, false));
        assertEquals(5, engine.getQueuedTargetsCount());
    }

    @Test
    @DisplayName("Test Priority Sorting Algorithms")
    public void testPrioritySortingAlgorithms() {
        BlockPos playerPos = new BlockPos(0, 64, 0);

        List<BlockPos> targets = new ArrayList<>(List.of(
                new BlockPos(0, 60, 5),   // dist = 6.4, Y = 60
                new BlockPos(0, 64, 2),   // dist = 2.0, Y = 64
                new BlockPos(0, 70, 1),   // dist = 6.08, Y = 70
                new BlockPos(0, 64, 10)   // dist = 10.0, Y = 64
        ));

        // 1. NEAREST_FIRST
        targets.sort(Comparator.comparingDouble(p -> playerPos.getSquaredDistance(p)));
        assertEquals(new BlockPos(0, 64, 2), targets.get(0)); // closest
        assertEquals(new BlockPos(0, 64, 10), targets.get(3)); // furthest

        // 2. FURTHEST_FIRST
        targets.sort((p1, p2) -> Double.compare(playerPos.getSquaredDistance(p2), playerPos.getSquaredDistance(p1)));
        assertEquals(new BlockPos(0, 64, 10), targets.get(0)); // furthest

        // 3. LOWEST_Y_FIRST / BOTTOM_TO_TOP
        targets.sort(Comparator.comparingInt(BlockPos::getY));
        assertEquals(60, targets.get(0).getY());

        // 4. HIGHEST_Y_FIRST / TOP_TO_BOTTOM
        targets.sort((p1, p2) -> Integer.compare(p2.getY(), p1.getY()));
        assertEquals(70, targets.get(0).getY());

        // 5. ROW_BY_ROW (Y descending, Z ascending, X ascending)
        targets.sort((p1, p2) -> {
            int cmpY = Integer.compare(p2.getY(), p1.getY());
            if (cmpY != 0) return cmpY;
            int cmpZ = Integer.compare(p1.getZ(), p2.getZ());
            if (cmpZ != 0) return cmpZ;
            return Integer.compare(p1.getX(), p2.getX());
        });
        assertEquals(70, targets.get(0).getY());
    }

    @Test
    @DisplayName("Test 6x3 Area Mining Footprint Calculation")
    public void testAreaMiningFootprint() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(10, 70, 10));
        BlockPos anchor = new BlockPos(5, 65, 5);

        ModConfig areaConfig = new ModConfig();
        areaConfig.setAreaMiningWidth(6);
        areaConfig.setAreaMiningHeight(3);

        List<BlockPos> footprint = AreaMiningCalculator.calculateFootprint(anchor, Direction.NORTH, region, areaConfig);

        // 6 x 3 = 18 potential blocks, all within region
        assertEquals(18, footprint.size());
        for (BlockPos p : footprint) {
            assertTrue(region.contains(p), "Footprint must not exceed region bounds: " + p);
        }

        // Verify top-to-bottom: first row has Y = 66, second has Y = 65, third has Y = 64
        assertEquals(66, footprint.get(0).getY());
        assertEquals(64, footprint.get(17).getY());
    }

    @Test
    @DisplayName("Test G: Reset on world transition clears all queued targets")
    public void testResetOnWorldTransition() {
        engine.enqueueTarget(new BlockPos(1, 2, 3), false);
        engine.enqueueTarget(new BlockPos(4, 5, 6), false);
        assertEquals(2, engine.getQueuedTargetsCount());

        engine.reset(true);
        assertEquals(0, engine.getQueuedTargetsCount());
        assertNull(engine.getCurrentTarget());
        assertEquals(0, engine.getSessionMinedBlocks());
    }
}

