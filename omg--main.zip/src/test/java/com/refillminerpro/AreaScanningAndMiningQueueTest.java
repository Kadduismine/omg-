package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.TargetPriority;
import com.refillminerpro.engine.*;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive unit test suite verifying:
 * 1. Selected area containing multiple eligible blocks
 * 2. Selected area containing no eligible blocks
 * 3. First and last positions on all three coordinate axes
 * 4. Target block removed by another player or process
 * 5. Target that is unreachable or in an unloaded chunk
 * 6. Selection changed while scanning or mining
 * 7. All targets completed, with no residual rotation or scheduled actions
 * 8. Mining stopped and restarted without duplicate listeners or duplicate targets
 */
public class AreaScanningAndMiningQueueTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setAutoMineEnabled(true);
        config.setMaxQueuedTargets(500);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
    }

    @Test
    @DisplayName("Test 1: Selected area containing multiple eligible blocks")
    public void testMultipleEligibleBlocksQueued() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(2, 62, 2)); // 3x3x3 = 27 blocks
        engine.setActiveRegion(region);

        // Enqueue multiple distinct valid blocks inside the region
        List<BlockPos> validBlocks = new ArrayList<>();
        for (int x = 0; x <= 2; x++) {
            for (int y = 60; y <= 62; y++) {
                for (int z = 0; z <= 2; z++) {
                    validBlocks.add(new BlockPos(x, y, z));
                }
            }
        }

        for (BlockPos pos : validBlocks) {
            assertTrue(engine.enqueueTarget(pos, false), "Block at " + pos + " should be queued");
        }

        assertEquals(27, engine.getQueuedTargetsCount());
        assertTrue(engine.isTargetQueuedOrActive(new BlockPos(1, 61, 1)));
        assertFalse(engine.enqueueTarget(new BlockPos(1, 61, 1), false), "Duplicate should be rejected");
    }

    @Test
    @DisplayName("Test 2: Selected area containing no eligible blocks cleanly transitions to COMPLETE")
    public void testEmptyAreaCleanCompletion() {
        BlockRegion region = new BlockRegion(new BlockPos(100, 100, 100), new BlockPos(105, 105, 105));
        engine.setActiveRegion(region);

        // When queue is empty, engine should remain or transition to COMPLETE without spinning
        assertEquals(0, engine.getQueuedTargetsCount());
        assertNull(engine.getCurrentTarget());
        assertFalse(engine.getRotationController().hasTarget(), "Rotation controller must not have target when empty");

        // Engine tick should maintain zero camera rotation
        engine.tick(null);
        assertFalse(engine.getRotationController().hasTarget());
    }

    @Test
    @DisplayName("Test 3: First and last positions on all three coordinate axes (normalization & bounds)")
    public void testCoordinateAxisExtremesAndNormalization() {
        // Test inverted corner order (Corner 1 max, Corner 2 min)
        BlockPos corner1 = new BlockPos(10, 80, -5);
        BlockPos corner2 = new BlockPos(-15, 60, 25);
        BlockRegion region = new BlockRegion(corner1, corner2);

        // Normalized minimums and maximums
        assertEquals(-15, region.getMinX());
        assertEquals(10, region.getMaxX());
        assertEquals(60, region.getMinY());
        assertEquals(80, region.getMaxY());
        assertEquals(-5, region.getMinZ());
        assertEquals(25, region.getMaxZ());

        // First and last positions on all 3 axes are contained
        assertTrue(region.contains(new BlockPos(-15, 60, -5)), "Min corner (first position)");
        assertTrue(region.contains(new BlockPos(10, 80, 25)), "Max corner (last position)");
        assertTrue(region.contains(new BlockPos(10, 60, -5)), "Axis extreme: X max, Y min, Z min");
        assertTrue(region.contains(new BlockPos(-15, 80, -5)), "Axis extreme: X min, Y max, Z min");
        assertTrue(region.contains(new BlockPos(-15, 60, 25)), "Axis extreme: X min, Y min, Z max");
        assertTrue(region.contains(new BlockPos(10, 80, -5)), "Axis extreme: X max, Y max, Z min");
        assertTrue(region.contains(new BlockPos(10, 60, 25)), "Axis extreme: X max, Y min, Z max");
        assertTrue(region.contains(new BlockPos(-15, 80, 25)), "Axis extreme: X min, Y max, Z max");

        // Outer boundaries outside the region
        assertFalse(region.contains(new BlockPos(-16, 60, -5)));
        assertFalse(region.contains(new BlockPos(11, 80, 25)));
        assertFalse(region.contains(new BlockPos(-15, 59, -5)));
        assertFalse(region.contains(new BlockPos(10, 81, 25)));
        assertFalse(region.contains(new BlockPos(-15, 60, -6)));
        assertFalse(region.contains(new BlockPos(10, 80, 26)));
    }

    @Test
    @DisplayName("Test 4: Target block removed by another player or process")
    public void testTargetRemovedExternally() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(10, 10, 10));
        engine.setActiveRegion(region);

        BlockPos targetPos = new BlockPos(5, 5, 5);
        assertTrue(engine.enqueueTarget(targetPos, false));
        assertEquals(1, engine.getQueuedTargetsCount());

        // External removal (e.g. mined by other player, explosion, falling sand)
        engine.onTargetBroken(targetPos);

        assertEquals(0, engine.getQueuedTargetsCount(), "Stale target must be removed from queue");
        assertEquals(1, engine.getSessionMinedBlocks(), "Mined counter updated");
        assertFalse(engine.isTargetQueuedOrActive(targetPos));
        assertNull(engine.getCurrentTarget());
    }

    @Test
    @DisplayName("Test 5: Target out of reach or block outside region rejected")
    public void testTargetOutsideRegionRejected() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(10, 70, 10));
        engine.setActiveRegion(region);

        BlockPos inside = new BlockPos(5, 65, 5);
        BlockPos outside = new BlockPos(20, 65, 20);

        assertTrue(engine.enqueueTarget(inside, false));
        assertFalse(engine.enqueueTarget(outside, false), "Block outside active region must be rejected");
        assertEquals(1, engine.getQueuedTargetsCount());
    }

    @Test
    @DisplayName("Test 6: Selection changed while active resets and updates cleanly")
    public void testSelectionChangedWhileActive() {
        BlockRegion region1 = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        engine.setActiveRegion(region1);
        engine.enqueueTarget(new BlockPos(2, 2, 2), false);
        assertEquals(1, engine.getQueuedTargetsCount());

        // Selection changed to a new region
        BlockRegion region2 = new BlockRegion(new BlockPos(50, 50, 50), new BlockPos(60, 60, 60));
        engine.setActiveRegion(region2);

        // Previous target from region1 should not be valid for region2
        assertFalse(region2.contains(new BlockPos(2, 2, 2)));
        assertFalse(engine.enqueueTarget(new BlockPos(2, 2, 2), false));

        // Targets within new region are accepted
        assertTrue(engine.enqueueTarget(new BlockPos(55, 55, 55), false));
    }

    @Test
    @DisplayName("Test 7: All targets completed, with no residual rotation or actions")
    public void testAllTargetsCompletedNoResidualRotation() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        engine.setActiveRegion(region);

        BlockPos target = new BlockPos(1, 1, 1);
        engine.enqueueTarget(target, false);
        assertEquals(1, engine.getQueuedTargetsCount());

        // Target mined
        engine.onTargetBroken(target);
        assertEquals(0, engine.getQueuedTargetsCount());

        // Verify zero residual rotation
        assertFalse(engine.getRotationController().hasTarget(), "Rotation controller target must be clear");
        assertNull(engine.getCurrentTarget(), "Current target must be null");
    }

    @Test
    @DisplayName("Test 8: Mining stopped and restarted without duplicate listeners or duplicate targets")
    public void testStopAndRestartNoDuplicates() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        engine.setActiveRegion(region);

        BlockPos p1 = new BlockPos(1, 1, 1);
        BlockPos p2 = new BlockPos(2, 2, 2);

        engine.enqueueTarget(p1, false);
        engine.enqueueTarget(p2, false);
        assertEquals(2, engine.getQueuedTargetsCount());

        // Stop mining
        engine.reset(false);
        assertEquals(0, engine.getQueuedTargetsCount());
        assertFalse(engine.getRotationController().hasTarget());

        // Restart mining
        engine.enqueueTarget(p1, false);
        engine.enqueueTarget(p2, false);
        assertEquals(2, engine.getQueuedTargetsCount());

        // Deduplication remains intact
        assertFalse(engine.enqueueTarget(p1, false));
        assertEquals(2, engine.getQueuedTargetsCount());
    }

    @Test
    @DisplayName("Test Hover Sweep and Strategy Stability with Tie-Breakers")
    public void testHoverSweepStability() {
        Vec3d eyePos = new Vec3d(0, 64, 0);
        BlockPos foot = new BlockPos(0, 63, 0);

        List<BlockPos> candidates = new ArrayList<>();
        for (int y = 60; y <= 66; y++) {
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    candidates.add(new BlockPos(x, y, z));
                }
            }
        }

        // Must sort without any TimSort contract violations
        assertDoesNotThrow(() -> {
            engine.sortCandidates(candidates, TargetPriority.HOVER_SWEEP, eyePos, foot);
        });

        assertDoesNotThrow(() -> {
            engine.sortCandidates(candidates, TargetPriority.NEAREST_FIRST, eyePos, foot);
        });

        assertDoesNotThrow(() -> {
            engine.sortCandidates(candidates, TargetPriority.TOP_TO_BOTTOM, eyePos, foot);
        });
    }

    @Test
    @DisplayName("Test Hold-to-Mine Target Complete Lifecycle")
    public void testTargetCompleteLifecycle() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(2, 2, 2));
        engine.setActiveRegion(region);

        BlockPos target1 = new BlockPos(1, 1, 1);
        BlockPos target2 = new BlockPos(1, 1, 2);
        engine.enqueueTarget(target1, false);
        engine.enqueueTarget(target2, false);

        assertEquals(2, engine.getQueuedTargetsCount());

        // Target 1 complete
        engine.handleTargetComplete(null, target1);
        assertEquals(1, engine.getQueuedTargetsCount());
        assertEquals(1, engine.getSessionMinedBlocks());
        assertEquals(MiningStatus.MINING, engine.getStatus());

        // Target 2 complete - all targets done!
        engine.handleTargetComplete(null, target2);
        assertEquals(0, engine.getQueuedTargetsCount());
        assertEquals(2, engine.getSessionMinedBlocks());
        assertEquals(MiningStatus.COMPLETE, engine.getStatus());
        assertFalse(engine.getRotationController().hasTarget());
    }

    @Test
    @DisplayName("Test Server Restriction Detection Is Recoverable And Does Not Permanently Suspend")
    public void testServerRestrictionDetection() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(2, 2, 2));
        engine.setActiveRegion(region);
        BlockPos target = new BlockPos(1, 1, 1);
        engine.enqueueTarget(target, false);
        engine.setCurrentTarget(target);

        assertTrue(config.isAutoMineEnabled());

        // Simulate SpaceMC server protection response for individual target
        engine.handleServerRestrictionDetected(null, "Hey! Sorry, but you can't break that block here.");

        // Target should be marked as server-restricted and removed from active target
        assertNull(engine.getCurrentTarget());
        assertTrue(engine.getServerRestrictedTargets().contains(target));
        assertTrue(engine.isServerRestricted(target));
        assertFalse(engine.getTargetQueue().contains(target));
        assertFalse(config.isPaused()); // Never fatal/permanently paused

        // When area restrictions occur, it excludes local cluster on cooldown and recovers safely without fatal pause
        BlockPos t2 = new BlockPos(1, 1, 2);
        engine.setCurrentTarget(t2);
        engine.handleServerRestrictionDetected(null, "Multiple Blocks In This Area are server protected");

        assertNull(engine.getCurrentTarget());
        assertTrue(engine.isServerRestricted(t2));
        assertFalse(config.isPaused()); // Auto Mine stays active and searches for valid targets
        assertEquals(MiningState.SELECTING_NEXT_TARGET, engine.getMiningState());
    }

    @Test
    @DisplayName("Test Consecutive Mining Failures Triggers Anti-Kick Pause")
    public void testConsecutiveFailureProtection() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(2, 2, 2));
        engine.setActiveRegion(region);
        engine.enqueueTarget(new BlockPos(1, 1, 1), false);
        engine.enqueueTarget(new BlockPos(1, 1, 2), false);

        assertEquals(0, engine.getConsecutiveTargetFailures());

        // Simulating 3 consecutive failures
        engine.setConsecutiveTargetFailures(MiningEngine.MAX_CONSECUTIVE_FAILURES);
        assertEquals(3, engine.getConsecutiveTargetFailures());

        // Successful break resets consecutive failures to 0
        engine.onTargetBroken(new BlockPos(1, 1, 1));
        assertEquals(0, engine.getConsecutiveTargetFailures());
    }

    @Test
    @DisplayName("Test A: Sequential Row Mining without skipping (Queue decreases monotonically)")
    public void testSequentialRowMiningNoSkipping() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 64, 0), new BlockPos(9, 64, 0));
        engine.setActiveRegion(region);

        List<BlockPos> rowBlocks = new ArrayList<>();
        for (int x = 0; x < 10; x++) {
            BlockPos pos = new BlockPos(x, 64, 0);
            rowBlocks.add(pos);
            assertTrue(engine.enqueueTarget(pos, false), "Block " + pos + " should be queued");
        }

        assertEquals(10, engine.getQueuedTargetsCount());

        int remaining = 10;
        for (int i = 0; i < 10; i++) {
            BlockPos target = rowBlocks.get(i);
            assertTrue(engine.isTargetQueuedOrActive(target), "Target " + target + " must be active/queued before completion");

            engine.handleTargetComplete(null, target);
            remaining--;
            assertEquals(remaining, engine.getQueuedTargetsCount(), "Queue count must decrease monotonically");
            assertEquals(i + 1, engine.getSessionMinedBlocks(), "Mined counter must increment exactly by 1");
            assertFalse(engine.isTargetQueuedOrActive(target), "Target " + target + " must be removed authoritatively after completion");
        }

        assertEquals(0, engine.getQueuedTargetsCount(), "Queue must be empty at the end");
        assertEquals(10, engine.getSessionMinedBlocks(), "All 10 blocks must be confirmed mined");
        assertEquals(MiningStatus.COMPLETE, engine.getStatus());
    }

    @Test
    @DisplayName("Test B: 6x3 Area-Mining Target Order and Footprint Stability")
    public void testAreaMiningFootprintStability() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(5, 62, 5));
        engine.setActiveRegion(region);

        Vec3d eyePos = new Vec3d(0, 64, 0);
        BlockPos footPos = new BlockPos(0, 63, 0);

        List<BlockPos> candidates = new ArrayList<>();
        for (int y = 60; y <= 62; y++) {
            for (int x = 0; x <= 5; x++) {
                for (int z = 0; z <= 2; z++) {
                    candidates.add(new BlockPos(x, y, z));
                }
            }
        }

        // Sorting row by row should maintain deterministic ordering without gaps
        engine.sortCandidates(candidates, TargetPriority.ROW_BY_ROW, eyePos, footPos);
        assertFalse(candidates.isEmpty());
        // Verify snake pattern ordering or monotonic Y-levels
        int prevY = candidates.get(0).getY();
        for (BlockPos pos : candidates) {
            assertTrue(pos.getY() <= prevY, "ROW_BY_ROW should process top-down layers");
            prevY = pos.getY();
        }
    }

    @Test
    @DisplayName("Test C: Tool Change / Hardness Recalculation Continuity")
    public void testToolChangeRecalculationContinuity() {
        BlockPos target = new BlockPos(5, 64, 5);
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(10, 70, 10));
        engine.setActiveRegion(region);
        engine.enqueueTarget(target, false);
        engine.setCurrentTarget(target);
        engine.setMiningState(MiningState.MINING_IN_PROGRESS);

        assertEquals(target, engine.getCurrentTarget());
        assertEquals(MiningState.MINING_IN_PROGRESS, engine.getMiningState());

        // Target remains in queue during mining so it is not dropped if tool changes or delta recalculates
        assertTrue(engine.isTargetQueuedOrActive(target));
        assertEquals(1, engine.getQueuedTargetsCount());

        // Upon break, target is authoritatively removed
        engine.onTargetBroken(target);
        assertNull(engine.getCurrentTarget());
        assertEquals(0, engine.getQueuedTargetsCount());
        assertEquals(1, engine.getSessionMinedBlocks());
    }

    @Test
    @DisplayName("Test D: Obstruction Handling & Retry Budget (No Premature Skip)")
    public void testObstructionRetryBudget() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        engine.setActiveRegion(region);

        BlockPos target = new BlockPos(2, 2, 2);
        engine.enqueueTarget(target, false);
        engine.setCurrentTarget(target);

        // When skip reason is recorded, it's logged to debug info
        engine.recordSkipReason("Line-of-sight obstructed by solid block");
        assertEquals("Line-of-sight obstructed by solid block", MiningDebugInfo.whySkippedReason);

        // Target is still queued/tracked until explicit recovery or completion
        assertTrue(engine.isTargetQueuedOrActive(target));
    }

    @Test
    @DisplayName("Test E: Pause and Resume Preserves State and Target Queue")
    public void testPauseResumePreservesState() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        engine.setActiveRegion(region);

        BlockPos target1 = new BlockPos(1, 1, 1);
        BlockPos target2 = new BlockPos(2, 2, 2);
        engine.enqueueTarget(target1, false);
        engine.enqueueTarget(target2, false);
        engine.setCurrentTarget(target1);
        engine.setMiningState(MiningState.MINING_IN_PROGRESS);

        // Pause
        config.setPaused(true);
        engine.setMiningState(MiningState.PAUSED);

        assertEquals(MiningState.PAUSED, engine.getMiningState());
        assertEquals(2, engine.getQueuedTargetsCount(), "Targets must remain queued while paused");
        assertEquals(target1, engine.getCurrentTarget(), "Current target must not be lost while paused");

        // Resume
        config.setPaused(false);
        engine.setMiningState(MiningState.SELECTING_NEXT_TARGET);
        assertEquals(2, engine.getQueuedTargetsCount());
    }

    @Test
    @DisplayName("Test F: Waiting for Block Update & Authoritative Confirmation")
    public void testWaitingForBlockUpdateAuthoritativeConfirmation() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(3, 3, 3));
        engine.setActiveRegion(region);

        BlockPos target = new BlockPos(1, 1, 1);
        engine.enqueueTarget(target, false);
        engine.setCurrentTarget(target);

        // Progressing to WAITING_FOR_BLOCK_UPDATE
        engine.setMiningState(MiningState.WAITING_FOR_BLOCK_UPDATE);
        MiningDebugInfo.blockConfirmedRemoved = false;

        // Target MUST remain active in queue while waiting for server block update
        assertTrue(engine.isTargetQueuedOrActive(target), "Target must not be removed before confirmation");
        assertEquals(1, engine.getQueuedTargetsCount());

        // When authoritative packet / confirmation arrives:
        MiningDebugInfo.blockConfirmedRemoved = true;
        engine.setMiningState(MiningState.CONFIRMING_COMPLETION);
        engine.onTargetBroken(target);

        // Now it is cleanly removed
        assertFalse(engine.isTargetQueuedOrActive(target));
        assertEquals(0, engine.getQueuedTargetsCount());
        assertEquals(1, engine.getSessionMinedBlocks());
    }

    @Test
    @DisplayName("Test G: World Disconnect Cleanup")
    public void testWorldDisconnectCleanup() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(5, 5, 5));
        engine.setActiveRegion(region);

        engine.enqueueTarget(new BlockPos(1, 1, 1), false);
        engine.enqueueTarget(new BlockPos(2, 2, 2), false);
        engine.setCurrentTarget(new BlockPos(1, 1, 1));
        engine.getRotationController().setTarget(new Vec3d(1.5, 1.5, 1.5), new BlockPos(1, 1, 1));

        assertTrue(engine.getRotationController().hasTarget());
        assertEquals(2, engine.getQueuedTargetsCount());

        // Disconnect or Reset
        engine.reset(false);

        assertEquals(0, engine.getQueuedTargetsCount(), "Queue cleared on disconnect");
        assertNull(engine.getCurrentTarget(), "Current target cleared on disconnect");
        assertFalse(engine.getRotationController().hasTarget(), "Rotation cleared on disconnect");
        assertEquals(MiningState.IDLE, engine.getMiningState(), "State reset to IDLE");
        assertEquals(MiningStatus.IDLE, engine.getStatus());
    }
}

