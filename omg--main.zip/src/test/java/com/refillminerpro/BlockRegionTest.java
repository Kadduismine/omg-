package com.refillminerpro;

import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BlockRegionTest {

    @Test
    @DisplayName("Test A1: Coordinate normalization with normal and inverted corners")
    public void testCoordinateNormalization() {
        // Corner 1 < Corner 2
        BlockPos c1 = new BlockPos(10, 20, 30);
        BlockPos c2 = new BlockPos(15, 25, 35);
        BlockRegion region1 = new BlockRegion(c1, c2);

        assertEquals(10, region1.getMinX());
        assertEquals(20, region1.getMinY());
        assertEquals(30, region1.getMinZ());
        assertEquals(15, region1.getMaxX());
        assertEquals(25, region1.getMaxY());
        assertEquals(35, region1.getMaxZ());
        assertEquals(6, region1.getWidthX());
        assertEquals(6, region1.getHeightY());
        assertEquals(6, region1.getLengthZ());
        assertEquals(216, region1.getVolume());

        // Inverted corners: Corner 1 > Corner 2
        BlockRegion region2 = new BlockRegion(c2, c1);
        assertEquals(region1.getMinX(), region2.getMinX());
        assertEquals(region1.getMinY(), region2.getMinY());
        assertEquals(region1.getMinZ(), region2.getMinZ());
        assertEquals(region1.getMaxX(), region2.getMaxX());
        assertEquals(region1.getMaxY(), region2.getMaxY());
        assertEquals(region1.getMaxZ(), region2.getMaxZ());
        assertEquals(region1.getVolume(), region2.getVolume());
        assertEquals(region1, region2);
    }

    @Test
    @DisplayName("Test A2: Negative coordinates and single block volume")
    public void testNegativeCoordinatesAndSingleBlock() {
        BlockPos p = new BlockPos(-50, -60, -70);
        BlockRegion singleBlock = new BlockRegion(p, p);

        assertEquals(1, singleBlock.getWidthX());
        assertEquals(1, singleBlock.getHeightY());
        assertEquals(1, singleBlock.getLengthZ());
        assertEquals(1, singleBlock.getVolume());
        assertTrue(singleBlock.contains(-50, -60, -70));
        assertFalse(singleBlock.contains(-50, -61, -70));

        // Mixed signs
        BlockRegion mixed = new BlockRegion(new BlockPos(-10, -5, -2), new BlockPos(10, 5, 2));
        assertEquals(21, mixed.getWidthX()); // -10..10 inclusive = 21
        assertEquals(11, mixed.getHeightY()); // -5..5 inclusive = 11
        assertEquals(5, mixed.getLengthZ());  // -2..2 inclusive = 5
        assertEquals(21 * 11 * 5, mixed.getVolume());
    }

    @Test
    @DisplayName("Test A3: Point containment and boundary checks")
    public void testContains() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(10, 10, 10));

        // Inside
        assertTrue(region.contains(new BlockPos(5, 5, 5)));
        // Boundaries (inclusive)
        assertTrue(region.contains(new BlockPos(0, 0, 0)));
        assertTrue(region.contains(new BlockPos(10, 10, 10)));
        assertTrue(region.contains(new BlockPos(0, 10, 5)));
        // Outside
        assertFalse(region.contains(new BlockPos(-1, 5, 5)));
        assertFalse(region.contains(new BlockPos(11, 5, 5)));
        assertFalse(region.contains(new BlockPos(5, -1, 5)));
        assertFalse(region.contains(new BlockPos(5, 11, 5)));
        assertFalse(region.contains(new BlockPos(5, 5, -1)));
        assertFalse(region.contains(new BlockPos(5, 5, 11)));
        assertFalse(region.contains((BlockPos) null));
    }

    @Test
    @DisplayName("Test A4: 3D Box generation for visual rendering")
    public void testToBox() {
        BlockRegion region = new BlockRegion(new BlockPos(2, 4, 6), new BlockPos(5, 8, 10));
        Box box = region.toBox();

        assertEquals(2.0, box.minX, 1e-6);
        assertEquals(4.0, box.minY, 1e-6);
        assertEquals(6.0, box.minZ, 1e-6);
        assertEquals(6.0, box.maxX, 1e-6); // 5 + 1.0 for inclusive block extent
        assertEquals(9.0, box.maxY, 1e-6);
        assertEquals(11.0, box.maxZ, 1e-6);
    }
}

