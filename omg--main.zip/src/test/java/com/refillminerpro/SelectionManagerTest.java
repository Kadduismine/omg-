package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.region.BlockRegion;
import com.refillminerpro.region.SelectionManager;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SelectionManagerTest {
    private SelectionManager selectionManager;
    private ModConfig config;

    @BeforeEach
    public void setup() {
        selectionManager = new SelectionManager();
        config = new ModConfig();
        config.setMaxRegionVolume(1000);
    }

    @Test
    @DisplayName("Test A5: Selection Mode activation and reset")
    public void testSelectionModeAndReset() {
        assertFalse(selectionManager.isSelectionModeActive());
        selectionManager.setSelectionModeActive(true);
        assertTrue(selectionManager.isSelectionModeActive());

        selectionManager.setCorner1(new BlockPos(1, 2, 3));
        assertFalse(selectionManager.isComplete());
        assertNull(selectionManager.getCurrentRegion());

        selectionManager.setCorner2(new BlockPos(4, 5, 6));
        assertTrue(selectionManager.isComplete());
        assertNotNull(selectionManager.getCurrentRegion());

        selectionManager.reset();
        assertFalse(selectionManager.isComplete());
        assertNull(selectionManager.getCorner1());
        assertNull(selectionManager.getCorner2());
        assertNull(selectionManager.getCurrentRegion());
    }

    @Test
    @DisplayName("Test A6: Selection validation within limits")
    public void testValidationWithinLimits() {
        selectionManager.setCorner1(new BlockPos(0, 0, 0));
        selectionManager.setCorner2(new BlockPos(9, 9, 9)); // 10x10x10 = 1000 blocks

        SelectionManager.ValidationResult result = selectionManager.validate(config);
        assertTrue(result.isValid());
        assertTrue(result.message().getString().contains("Region valid"));
    }

    @Test
    @DisplayName("Test A7: Selection validation exceeding configured safety limits")
    public void testValidationExceedingLimits() {
        selectionManager.setCorner1(new BlockPos(0, 0, 0));
        selectionManager.setCorner2(new BlockPos(10, 10, 10)); // 11x11x11 = 1331 > 1000

        SelectionManager.ValidationResult result = selectionManager.validate(config);
        assertFalse(result.isValid());
        assertTrue(result.message().getString().contains("exceeds configured safety limit"));
    }

    @Test
    @DisplayName("Test A8: Incomplete selection validation")
    public void testIncompleteValidation() {
        SelectionManager.ValidationResult r1 = selectionManager.validate(config);
        assertFalse(r1.isValid());

        selectionManager.setCorner1(new BlockPos(0, 0, 0));
        SelectionManager.ValidationResult r2 = selectionManager.validate(config);
        assertFalse(r2.isValid());
        assertTrue(r2.message().getString().contains("Corner 2 not set"));
    }
}

