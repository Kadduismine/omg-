package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.TargetPriority;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.engine.MiningState;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ContinuousMiningTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setAutoMineEnabled(true);
        config.setContinuousMining(true);
        config.setAutoAdvance(true);
        config.setPaused(false);
        config.setScanDistance(6);
        config.setScanWidth(5);
        config.setScanHeight(4);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
    }

    @Test
    @DisplayName("Verify continuous mining and auto-advance defaults and getters")
    public void testContinuousMiningConfig() {
        assertTrue(config.isContinuousMining(), "Continuous mining should be enabled by default");
        assertTrue(config.isAutoAdvance(), "Auto advance should be enabled by default");

        config.setContinuousMining(false);
        assertFalse(config.isContinuousMining());

        config.setAutoAdvance(false);
        assertFalse(config.isAutoAdvance());
    }

    @Test
    @DisplayName("Verify forward target candidate sorting strategies across vertical and horizontal fields")
    public void testForwardCandidateSorting() {
        Vec3d eyePos = new Vec3d(0.5, 65.62, 0.5);
        BlockPos playerFoot = new BlockPos(0, 64, 0);

        List<BlockPos> candidates = new ArrayList<>();
        BlockPos upperLeft = new BlockPos(-1, 67, 3);
        BlockPos middleCenter = new BlockPos(0, 65, 3);
        BlockPos lowerRight = new BlockPos(1, 63, 3);

        candidates.add(upperLeft);
        candidates.add(middleCenter);
        candidates.add(lowerRight);

        // 1. Bottom-to-Top should place lower row first
        engine.sortCandidates(candidates, TargetPriority.BOTTOM_TO_TOP, eyePos, playerFoot);
        assertEquals(lowerRight, candidates.get(0));
        assertEquals(middleCenter, candidates.get(1));
        assertEquals(upperLeft, candidates.get(2));

        // 2. Top-to-Bottom should place upper row first
        engine.sortCandidates(candidates, TargetPriority.TOP_TO_BOTTOM, eyePos, playerFoot);
        assertEquals(upperLeft, candidates.get(0));
        assertEquals(middleCenter, candidates.get(1));
        assertEquals(lowerRight, candidates.get(2));

        // 3. Nearest first
        BlockPos closePos = new BlockPos(0, 65, 1);
        candidates.add(closePos);
        engine.sortCandidates(candidates, TargetPriority.NEAREST_FIRST, eyePos, playerFoot);
        assertEquals(closePos, candidates.get(0));
    }

    @Test
    @DisplayName("Verify continuous multi-block sequence progression")
    public void testMultiBlockProgression() {
        BlockRegion region = new BlockRegion(new BlockPos(-5, 60, -5), new BlockPos(5, 70, 5));
        engine.setActiveRegion(region);

        BlockPos b1 = new BlockPos(0, 65, 2);
        BlockPos b2 = new BlockPos(1, 65, 2);
        BlockPos b3 = new BlockPos(2, 65, 2);

        assertTrue(engine.enqueueTarget(b1, false));
        assertTrue(engine.enqueueTarget(b2, false));
        assertTrue(engine.enqueueTarget(b3, false));
        assertEquals(3, engine.getQueuedTargetsCount());

        // Simulate mining completion of target 1
        engine.setCurrentTarget(b1);
        engine.onTargetBroken(b1);
        assertEquals(1, engine.getSessionMinedBlocks());
        assertFalse(engine.isTargetQueuedOrActive(b1));
        assertTrue(engine.isTargetQueuedOrActive(b2));
        assertTrue(engine.isTargetQueuedOrActive(b3));

        // Simulate mining completion of target 2
        engine.setCurrentTarget(b2);
        engine.onTargetBroken(b2);
        assertEquals(2, engine.getSessionMinedBlocks());
        assertFalse(engine.isTargetQueuedOrActive(b2));
        assertTrue(engine.isTargetQueuedOrActive(b3));

        // Simulate mining completion of target 3
        engine.setCurrentTarget(b3);
        engine.onTargetBroken(b3);
        assertEquals(3, engine.getSessionMinedBlocks());
        assertEquals(0, engine.getQueuedTargetsCount());
    }

    @Test
    @DisplayName("Verify forward movement settings, desired gap bounds, and movement smoothness presets")
    public void testForwardMovementAndGapSettings() {
        // Forward movement alias and defaults
        assertTrue(config.isForwardMovementEnabled());
        config.setForwardMovementEnabled(false);
        assertFalse(config.isAutoAdvance());
        assertFalse(config.isForwardMovementEnabled());
        config.setAutoAdvance(true);
        assertTrue(config.isForwardMovementEnabled());

        // Desired gap defaults to 1.5 blocks and enforces [1.0, 2.0]
        assertEquals(1.5, config.getDesiredMiningGap(), 0.001);

        config.setDesiredMiningGap(1.2);
        assertEquals(1.2, config.getDesiredMiningGap(), 0.001);

        config.setDesiredMiningGap(0.5); // below min
        assertEquals(1.0, config.getDesiredMiningGap(), 0.001);

        config.setDesiredMiningGap(3.5); // above max
        assertEquals(2.0, config.getDesiredMiningGap(), 0.001);

        // Movement Smoothness
        assertEquals(com.refillminerpro.config.MovementSmoothness.NORMAL, config.getMovementSmoothness());
        config.setMovementSmoothness(com.refillminerpro.config.MovementSmoothness.SLOW);
        assertEquals(com.refillminerpro.config.MovementSmoothness.SLOW, config.getMovementSmoothness());
        assertEquals(com.refillminerpro.config.MovementSmoothness.NORMAL, config.getMovementSmoothness().next());

        // Stuck Recovery
        assertTrue(config.isStuckRecoveryEnabled());
        config.setStuckRecoveryEnabled(false);
        assertFalse(config.isStuckRecoveryEnabled());

        // Protection Cooldown Configuration
        assertEquals(30, config.getProtectionCooldownSeconds());
        config.setProtectionCooldownSeconds(20);
        assertEquals(20, config.getProtectionCooldownSeconds());
        config.setProtectionCooldownSeconds(2); // below min
        assertEquals(5, config.getProtectionCooldownSeconds());
        config.setProtectionCooldownSeconds(500); // above max
        assertEquals(300, config.getProtectionCooldownSeconds());
    }

    @Test
    @DisplayName("Verify server protection denials are recoverable, exclude on cooldown, and do not suspend auto mine")
    public void testServerProtectionRecoverableWorkflow() {
        BlockRegion region = new BlockRegion(new BlockPos(0, 0, 0), new BlockPos(10, 10, 10));
        engine.setActiveRegion(region);

        BlockPos protectedBlock = new BlockPos(2, 2, 2);
        BlockPos permittedBlock1 = new BlockPos(3, 2, 2);
        BlockPos permittedBlock2 = new BlockPos(6, 2, 2);

        engine.enqueueTarget(protectedBlock, false);
        engine.enqueueTarget(permittedBlock1, false);
        engine.enqueueTarget(permittedBlock2, false);

        assertEquals(3, engine.getQueuedTargetsCount());
        engine.setCurrentTarget(protectedBlock);

        // Encounter server protection denial message on Box PvP
        engine.handleServerRestrictionDetected(null, "Auto Mine: Suspended - Multiple Blocks In This Area are server protected");

        // Engine must NOT set config.isPaused(true)
        assertFalse(config.isPaused(), "Auto mine config must NOT be paused by server protection denial");

        // Protected block must be excluded and on cooldown
        assertNull(engine.getCurrentTarget());
        assertTrue(engine.isServerRestricted(protectedBlock));
        assertFalse(engine.getTargetQueue().contains(protectedBlock));

        // Permitted blocks further away should still be available in the queue
        assertTrue(engine.getTargetQueue().contains(permittedBlock2));
        assertFalse(engine.isServerRestricted(permittedBlock2));

        // State machine should be ready to select next target
        assertEquals(com.refillminerpro.engine.MiningState.SELECTING_NEXT_TARGET, engine.getMiningState());
    }

    @Test
    @DisplayName("Verify Continuous Forward Movement, Gap bounds, Stuck Threshold, and Recovery Mode settings")
    public void testContinuousForwardMovementAndRecoverySettings() {
        // Continuous Forward Movement
        assertTrue(config.isContinuousForwardMovement());
        config.setContinuousForwardMovement(false);
        assertFalse(config.isContinuousForwardMovement());
        assertFalse(config.isAutoAdvance());
        config.setContinuousForwardMovement(true);
        assertTrue(config.isContinuousForwardMovement());
        assertTrue(config.isAutoAdvance());

        // Mining Gap: 1.0 - 2.0 (default 1.5)
        assertEquals(1.5, config.getDesiredMiningGap(), 0.001);
        config.setDesiredMiningGap(1.8);
        assertEquals(1.8, config.getDesiredMiningGap(), 0.001);

        // Stuck Detection Threshold
        assertEquals(20, config.getStuckDetectionThreshold());
        config.setStuckDetectionThreshold(30);
        assertEquals(30, config.getStuckDetectionThreshold());
        config.setStuckDetectionThreshold(2); // below min 5
        assertEquals(5, config.getStuckDetectionThreshold());
        config.setStuckDetectionThreshold(200); // above max 100
        assertEquals(100, config.getStuckDetectionThreshold());

        // Recovery Mode
        assertEquals(com.refillminerpro.config.RecoveryMode.RESCAN, config.getRecoveryMode());
        config.setRecoveryMode(com.refillminerpro.config.RecoveryMode.REPLAN);
        assertEquals(com.refillminerpro.config.RecoveryMode.REPLAN, config.getRecoveryMode());
        config.setRecoveryMode(com.refillminerpro.config.RecoveryMode.PAUSE_SAFELY);
        assertEquals(com.refillminerpro.config.RecoveryMode.PAUSE_SAFELY, config.getRecoveryMode());

        // Target Search Radius (scanDistance)
        config.setScanDistance(8);
        assertEquals(8, config.getScanDistance());

        // Pathfinding On/Off & Search Limit
        assertTrue(config.isAutoNavigate());
        config.setAutoNavigate(false);
        assertFalse(config.isAutoNavigate());
        config.setAutoNavigate(true);
        config.setPathfindingSearchLimit(2500);
        assertEquals(2500, config.getPathfindingSearchLimit());
    }
}

