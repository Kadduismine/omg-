package com.refillminerpro;

import com.refillminerpro.config.ModConfig;
import com.refillminerpro.engine.BlockFilter;
import com.refillminerpro.engine.MiningEngine;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class RefillSimulationTest {
    private ModConfig config;
    private BlockFilter filter;
    private MiningEngine engine;
    private BlockRegion testRegion;

    @BeforeEach
    public void setup() {
        config = new ModConfig();
        config.setAutoMineEnabled(true);
        config.setMaxQueuedTargets(100);
        filter = new BlockFilter(config);
        engine = new MiningEngine(config, filter);
        testRegion = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(10, 65, 10));
    }

    @Test
    @DisplayName("Test C & D: Continuous refill detection and repeated refills on same position")
    public void testContinuousRefillCycle() {
        BlockPos generatorPos = new BlockPos(5, 62, 5);
        assertTrue(testRegion.contains(generatorPos));

        Set<BlockPos> monitoredEmpty = new HashSet<>();

        // Cycle 1: Block appears
        assertTrue(engine.enqueueTarget(generatorPos, false));
        assertEquals(1, engine.getQueuedTargetsCount());

        // Block is broken
        engine.onTargetBroken(generatorPos);
        assertEquals(1, engine.getSessionMinedBlocks());
        monitoredEmpty.add(generatorPos); // Marked empty

        // Cycle 2: Same block regenerates at generatorPos
        assertTrue(monitoredEmpty.contains(generatorPos));
        monitoredEmpty.remove(generatorPos);
        assertTrue(engine.enqueueTarget(generatorPos, false));
        assertEquals(1, engine.getQueuedTargetsCount());

        // Block is broken again
        engine.onTargetBroken(generatorPos);
        assertEquals(2, engine.getSessionMinedBlocks());
        monitoredEmpty.add(generatorPos);

        // Cycle 3: Third refill
        assertTrue(monitoredEmpty.contains(generatorPos));
        monitoredEmpty.remove(generatorPos);
        assertTrue(engine.enqueueTarget(generatorPos, false));
        engine.onTargetBroken(generatorPos);
        assertEquals(3, engine.getSessionMinedBlocks());

        // Cycle 4: Fourth refill
        assertTrue(engine.enqueueTarget(generatorPos, false));
        engine.onTargetBroken(generatorPos);
        assertEquals(4, engine.getSessionMinedBlocks());
    }

    @Test
    @DisplayName("Test E: Pause and disable state management")
    public void testPauseAndDisableState() {
        assertTrue(config.isAutoMineEnabled());
        assertFalse(config.isPaused());

        // Pause
        config.setPaused(true);
        assertTrue(config.isPaused());

        // Resume
        config.setPaused(false);
        assertFalse(config.isPaused());

        // Disable
        config.setAutoMineEnabled(false);
        assertFalse(config.isAutoMineEnabled());
    }

    @Test
    @DisplayName("Test F: Whitelist and Blacklist filtering normalization")
    public void testFilterWhitelistAndBlacklist() {
        config.getWhitelist().add("minecraft:cobblestone");
        config.getWhitelist().add("stone"); // Should normalize to minecraft:stone
        filter.updateCache();

        // Check normalization behavior
        assertTrue(config.getWhitelist().contains("minecraft:cobblestone"));
        assertTrue(config.getWhitelist().contains("stone"));

        config.getBlacklist().add("minecraft:obsidian");
        filter.updateCache();
        assertTrue(config.getBlacklist().contains("minecraft:obsidian"));
    }
}

