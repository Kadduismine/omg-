package com.refillminerpro;

import com.refillminerpro.config.ConfigManager;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.TargetPriority;
import com.refillminerpro.region.BlockRegion;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

public class ConfigManagerTest {

    @Test
    @DisplayName("Verify ConfigManager saves and loads persistent settings with Safe Initialization")
    public void testConfigManagerSaveAndLoad(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        ModConfig cfg = manager.getConfig();

        cfg.setTargetPriority(TargetPriority.BOTTOM_TO_TOP);
        cfg.setAreaMiningEnabled(true);
        cfg.setAreaMiningWidth(6);
        cfg.setAreaMiningHeight(3);
        cfg.getAutoStorage().setEnabled(true);

        // Even if runtime enabled autoMine, saving and loading must enforce idle
        cfg.setAutoMineEnabled(true);
        cfg.setPaused(true);

        manager.save();
        assertTrue(cfg.isAutoMineEnabled(), "Runtime state in memory must remain enabled after saving");
        assertTrue(cfg.isPaused(), "Runtime paused state in memory must remain active after saving");

        // Create new manager instance loading from disk
        ConfigManager loadedManager = new ConfigManager(tempDir.toFile());
        loadedManager.load();
        ModConfig loadedCfg = loadedManager.getConfig();

        // Safe Initialization: strictly idle on disk/load
        assertFalse(loadedCfg.isAutoMineEnabled());
        assertFalse(loadedCfg.isPaused());
        assertEquals(2, loadedCfg.getConfigVersion());

        // Persistent settings preserved
        assertEquals(TargetPriority.BOTTOM_TO_TOP, loadedCfg.getTargetPriority());
        assertTrue(loadedCfg.isAreaMiningEnabled());
        assertEquals(6, loadedCfg.getAreaMiningWidth());
        assertEquals(3, loadedCfg.getAreaMiningHeight());
        assertTrue(loadedCfg.getAutoStorage().isEnabled());
        assertNotNull(loadedCfg.getSavedAreas());
    }

    @Test
    @DisplayName("Verify Area Selection is Persisted and Restored Correctly")
    public void testPersistentAreaSelection(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        BlockRegion region = new BlockRegion(new BlockPos(0, 60, 0), new BlockPos(10, 70, 10));

        // Save selection for world
        manager.saveSelectionForWorld("play.spacemc.lol:25565", region);

        // Must restore correctly from saved areas
        BlockRegion loaded = manager.loadSelectionForWorld("play.spacemc.lol:25565");
        assertNotNull(loaded, "Area selection must be restored from saved areas");
        assertEquals(0, loaded.getMinX());
        assertEquals(10, loaded.getMaxX());
        assertEquals(60, loaded.getMinY());
        assertEquals(70, loaded.getMaxY());
    }
}
