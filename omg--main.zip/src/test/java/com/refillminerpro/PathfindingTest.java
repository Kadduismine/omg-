package com.refillminerpro;

import com.refillminerpro.pathfinding.PathAction;
import com.refillminerpro.pathfinding.PathNode;
import com.refillminerpro.pathfinding.PathResult;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PathfindingTest {

    @Test
    @DisplayName("Test PathNode Cost Calculation and Priority Sorting")
    public void testPathNodeOrdering() {
        BlockPos p1 = new BlockPos(0, 64, 0);
        BlockPos p2 = new BlockPos(1, 64, 0);
        BlockPos p3 = new BlockPos(2, 64, 0);

        // n1: g=2, h=5, f=7
        PathNode n1 = new PathNode(p1, 2.0, 5.0, null, PathAction.WALK);
        // n2: g=1, h=4, f=5 (lowest f)
        PathNode n2 = new PathNode(p2, 1.0, 4.0, null, PathAction.WALK);
        // n3: g=3, h=4, f=7 (tie on f with n1, but lower h: 4.0 vs 5.0)
        PathNode n3 = new PathNode(p3, 3.0, 4.0, null, PathAction.JUMP_UP);

        List<PathNode> list = new ArrayList<>(List.of(n1, n2, n3));
        Collections.sort(list);

        assertEquals(n2, list.get(0)); // lowest fCost (5.0)
        assertEquals(n3, list.get(1)); // fCost=7.0, tie-breaker lower hCost (4.0)
        assertEquals(n1, list.get(2)); // fCost=7.0, hCost=5.0
    }

    @Test
    @DisplayName("Test PathResult State Invariants")
    public void testPathResultStates() {
        PathResult notFound = PathResult.notFound();
        assertEquals(PathResult.Status.NOT_FOUND, notFound.getStatus());
        assertFalse(notFound.isSuccess());
        assertEquals(0, notFound.getLength());

        PathResult atTarget = PathResult.alreadyAtTarget();
        assertEquals(PathResult.Status.ALREADY_AT_TARGET, atTarget.getStatus());
        assertTrue(atTarget.isSuccess());

        List<PathNode> nodes = List.of(
                new PathNode(new BlockPos(1, 64, 0), 1.0, 2.0, null, PathAction.WALK),
                new PathNode(new BlockPos(2, 65, 0), 2.4, 1.0, null, PathAction.JUMP_UP),
                new PathNode(new BlockPos(3, 65, 0), 3.4, 0.0, null, PathAction.WALK)
        );
        PathResult found = new PathResult(PathResult.Status.FOUND, nodes, 3.4);
        assertTrue(found.isSuccess());
        assertEquals(3, found.getLength());
        assertEquals(3.4, found.getTotalCost());
        assertEquals(PathAction.JUMP_UP, found.getNodes().get(1).action);
    }
}

