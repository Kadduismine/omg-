package com.refillminerpro;

import com.refillminerpro.config.ConfigManager;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.config.SavedAreaProfile;
import com.refillminerpro.config.ServerIdentifier;
import com.refillminerpro.region.BlockRegion;
import com.refillminerpro.region.SelectionManager;
import net.minecraft.util.math.BlockPos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SavedAreaManagementTest {

    @Test
    @DisplayName("Test A — Save and restore: Selection saved, serialized, and restored on rejoin")
    public void testSaveAndRestoreWorkflow(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        BlockPos c1 = new BlockPos(10, 64, -20);
        BlockPos c2 = new BlockPos(35, 80, 15);
        BlockRegion region = new BlockRegion(c1, c2);

        String server = "play.spacemc.lol:25565";
        String dim = "minecraft:overworld";

        // Save as "Diamond Mine"
        SavedAreaProfile profile = SavedAreaProfile.fromRegion("Diamond Mine", server, dim, region);
        manager.saveArea(profile);

        // Verify written to disk and discoverable
        SavedAreaProfile found = manager.findLastActiveArea(server, dim);
        assertNotNull(found);
        assertEquals("Diamond Mine", found.getName());
        assertEquals(10, found.getMinX());
        assertEquals(35, found.getMaxX());
        assertEquals(64, found.getMinY());
        assertEquals(80, found.getMaxY());
        assertEquals(-20, found.getMinZ());
        assertEquals(15, found.getMaxZ());
        assertTrue(found.isActive());

        // Simulate reconnect: restore into SelectionManager
        SelectionManager selManager = new SelectionManager();
        assertFalse(selManager.isComplete());

        SavedAreaProfile restoredProfile = manager.findLastActiveArea(server, dim);
        assertNotNull(restoredProfile);
        selManager.setRegion(restoredProfile.toBlockRegion());

        assertTrue(selManager.isComplete());
        assertEquals(c1, selManager.getCorner1());
        assertEquals(c2, selManager.getCorner2());
        assertEquals(region.getVolume(), selManager.getCurrentRegion().getVolume());
    }

    @Test
    @DisplayName("Test B — Movement: Player walking far away does not erase saved profile or selection")
    public void testPlayerMovementDoesNotEraseSelection(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        SelectionManager selManager = new SelectionManager();

        BlockRegion region = new BlockRegion(new BlockPos(100, 60, 100), new BlockPos(120, 70, 120));
        selManager.setRegion(region);
        SavedAreaProfile profile = SavedAreaProfile.fromRegion("Spawn Quarry", "play.stray.gg:25565", "minecraft:overworld", region);
        manager.saveArea(profile);

        // Player walks far away (e.g. 50,000 blocks)
        BlockPos farPlayerPos = new BlockPos(50000, 100, 50000);
        assertFalse(region.contains(farPlayerPos));

        // Selection and saved profile must remain active and unchanged
        assertTrue(selManager.isComplete());
        assertEquals(region, selManager.getCurrentRegion());

        List<SavedAreaProfile> list = manager.getSavedAreasFor("play.stray.gg:25565", "minecraft:overworld");
        assertEquals(1, list.size());
        assertEquals("Spawn Quarry", list.get(0).getName());
    }

    @Test
    @DisplayName("Test C — Restart: Completely new ConfigManager instance loads saved area across Minecraft restarts")
    public void testMinecraftRestartPersistence(@TempDir Path tempDir) {
        File dir = tempDir.toFile();

        // Session 1: Create and save
        ConfigManager session1 = new ConfigManager(dir);
        SavedAreaProfile area = new SavedAreaProfile("Deep Quarry", "play.hypixel.net:25565", "minecraft:overworld",
                -50, 12, -50, 50, 64, 50);
        session1.saveArea(area);

        // Session 2: Fresh launch / new JVM instance
        ConfigManager session2 = new ConfigManager(dir);
        session2.load();

        List<SavedAreaProfile> loaded = session2.getSavedAreasFor("play.hypixel.net:25565", "minecraft:overworld");
        assertEquals(1, loaded.size());
        SavedAreaProfile restored = loaded.get(0);
        assertEquals("Deep Quarry", restored.getName());
        assertEquals(-50, restored.getMinX());
        assertEquals(50, restored.getMaxX());
        assertEquals(101, restored.getWidth());
        assertEquals(53, restored.getHeight());
        assertEquals(101, restored.getDepth());
        assertEquals(101L * 53L * 101L, restored.getVolume());
    }

    @Test
    @DisplayName("Test D — Server separation: Server A selection never leaks to Server B")
    public void testServerSeparation(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());

        SavedAreaProfile areaA = new SavedAreaProfile("Server A Base", "play.servera.net:25565", "minecraft:overworld",
                0, 60, 0, 10, 70, 10);
        manager.saveArea(areaA);

        // Check Server B
        List<SavedAreaProfile> serverBAreas = manager.getSavedAreasFor("play.serverb.net:25565", "minecraft:overworld");
        assertTrue(serverBAreas.isEmpty(), "Server B must NOT see Server A's saved areas");

        SavedAreaProfile lastB = manager.findLastActiveArea("play.serverb.net:25565", "minecraft:overworld");
        assertNull(lastB, "No area should be restored for Server B");

        // Return to Server A
        SavedAreaProfile lastA = manager.findLastActiveArea("play.servera.net:25565", "minecraft:overworld");
        assertNotNull(lastA);
        assertEquals("Server A Base", lastA.getName());
    }

    @Test
    @DisplayName("Test E — Ports and addresses: Port distinction, IPv4, IPv6 bracketed/unbracketed, and normalization")
    public void testServerAddressAndPortNormalization() {
        // Distinct ports on same host do NOT collide
        String ep1 = ServerIdentifier.normalize("play.example.net:25565");
        String ep2 = ServerIdentifier.normalize("play.example.net:25566");
        assertNotEquals(ep1, ep2, "Different ports on the same host must be distinct endpoints");

        // Default port normalization
        String epDefaultMissing = ServerIdentifier.normalize("play.example.net");
        assertEquals(ep1, epDefaultMissing, "Missing port must normalize to default port 25565");

        // Case insensitivity & trailing dot removal
        String epUpperDots = ServerIdentifier.normalize("  PLAY.EXAMPLE.NET.:25565  ");
        assertEquals(ep1, epUpperDots);

        // IPv4 normalization
        String ip4 = ServerIdentifier.normalize("192.168.1.50:25566");
        assertEquals("192.168.1.50:25566", ip4);

        // Bracketed IPv6 with custom port
        String ip6BracketedCustom = ServerIdentifier.normalize("[2001:db8::1]:25566");
        assertEquals("[2001:db8::1]:25566", ip6BracketedCustom);

        // Bracketed IPv6 with default port
        String ip6Bracketed = ServerIdentifier.normalize("[2001:db8::1]");
        assertEquals("[2001:db8::1]:25565", ip6Bracketed);

        // Unbracketed IPv6 with multiple colons
        String ip6Unbracketed = ServerIdentifier.normalize("2001:db8::1");
        assertEquals("[2001:db8::1]:25565", ip6Unbracketed);

        // Host only extraction
        assertEquals("play.example.net", ServerIdentifier.getHostOnly(ep1));
        assertEquals("2001:db8::1", ServerIdentifier.getHostOnly(ip6Bracketed));
        assertEquals(25566, ServerIdentifier.getPort(ep2));
    }

    @Test
    @DisplayName("Test F — Dimensions: Overworld and Nether have separate saved profiles on same server")
    public void testDimensionSeparation(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        String server = "play.spacemc.lol:25565";

        SavedAreaProfile overworldArea = new SavedAreaProfile("Overworld Farm", server, "minecraft:overworld",
                100, 60, 100, 150, 80, 150);
        SavedAreaProfile netherArea = new SavedAreaProfile("Nether Highway", server, "minecraft:the_nether",
                10, 50, 10, 20, 55, 200);

        manager.saveArea(overworldArea);
        manager.saveArea(netherArea);

        // Lookup Overworld
        SavedAreaProfile activeOverworld = manager.findLastActiveArea(server, "minecraft:overworld");
        assertNotNull(activeOverworld);
        assertEquals("Overworld Farm", activeOverworld.getName());

        // Lookup Nether
        SavedAreaProfile activeNether = manager.findLastActiveArea(server, "minecraft:the_nether");
        assertNotNull(activeNether);
        assertEquals("Nether Highway", activeNether.getName());

        // Overworld selection does not leak into Nether
        assertNotEquals(activeOverworld.getName(), activeNether.getName());
    }

    @Test
    @DisplayName("Test G — Singleplayer: Separate singleplayer worlds maintain isolated profiles")
    public void testSingleplayerWorldSeparation(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());

        String world1 = ServerIdentifier.normalize("singleplayer:survival_2026");
        String world2 = ServerIdentifier.normalize("singleplayer:hardcore_run");

        assertNotEquals(world1, world2);

        SavedAreaProfile areaW1 = new SavedAreaProfile("Home Base", world1, "minecraft:overworld", 0, 64, 0, 20, 80, 20);
        SavedAreaProfile areaW2 = new SavedAreaProfile("Quarry Alpha", world2, "minecraft:overworld", 100, 12, 100, 150, 64, 150);

        manager.saveArea(areaW1);
        manager.saveArea(areaW2);

        List<SavedAreaProfile> w1List = manager.getSavedAreasFor(world1, "minecraft:overworld");
        List<SavedAreaProfile> w2List = manager.getSavedAreasFor(world2, "minecraft:overworld");

        assertEquals(1, w1List.size());
        assertEquals("Home Base", w1List.get(0).getName());

        assertEquals(1, w2List.size());
        assertEquals("Quarry Alpha", w2List.get(0).getName());
    }

    @Test
    @DisplayName("Test H — Multiple areas: Save, Rename, Duplicate, Delete multiple profiles on one server")
    public void testMultipleAreasManagement(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        String server = "play.spacemc.lol:25565";
        String dim = "minecraft:overworld";

        SavedAreaProfile a1 = new SavedAreaProfile("Diamond Mine", server, dim, 0, 10, 0, 10, 20, 10);
        SavedAreaProfile a2 = new SavedAreaProfile("Iron Farm", server, dim, 50, 60, 50, 70, 80, 70);
        SavedAreaProfile a3 = new SavedAreaProfile("Quarry", server, dim, 100, 60, 100, 150, 80, 150);

        manager.saveArea(a1);
        manager.saveArea(a2);
        manager.saveArea(a3);

        assertEquals(3, manager.getSavedAreasFor(server, dim).size());

        // 1. Rename
        assertTrue(manager.renameArea(a2.getId(), "Gold Farm"));
        SavedAreaProfile renamed = manager.getSavedAreasFor(server, dim).stream()
                .filter(p -> p.getId().equals(a2.getId())).findFirst().orElse(null);
        assertNotNull(renamed);
        assertEquals("Gold Farm", renamed.getName());

        // 2. Duplicate
        SavedAreaProfile dup = manager.duplicateArea(a3.getId());
        assertNotNull(dup);
        assertEquals("Quarry (Copy)", dup.getName());
        assertEquals(4, manager.getSavedAreasFor(server, dim).size());

        // 3. Delete
        assertTrue(manager.deleteArea(a1.getId()));
        assertEquals(3, manager.getSavedAreasFor(server, dim).size());
        assertNull(manager.getSavedAreasFor(server, dim).stream()
                .filter(p -> p.getId().equals(a1.getId())).findFirst().orElse(null));
    }

    @Test
    @DisplayName("Test I — Authorization & Safe State: Restoring region never starts auto-mining")
    public void testRestorationDoesNotStartAutomation(@TempDir Path tempDir) {
        ConfigManager manager = new ConfigManager(tempDir.toFile());
        ModConfig config = manager.getConfig();

        // Even if config had autoMineEnabled set in memory, save/load strictly forces false
        config.setAutoMineEnabled(true);
        config.setPaused(true);
        manager.save();

        ConfigManager reloaded = new ConfigManager(tempDir.toFile());
        reloaded.load();
        assertFalse(reloaded.getConfig().isAutoMineEnabled(), "Auto Mine must strictly be idle on restart");
        assertFalse(reloaded.getConfig().isPaused(), "Paused flag must strictly be false on restart");
    }

    @Test
    @DisplayName("Test J — Existing configuration: Migration from legacy savedSelections and corruption backup")
    public void testLegacyMigrationAndCorruptionResilience(@TempDir Path tempDir) throws IOException {
        File configFile = new File(tempDir.toFile(), "refillminerpro.json");

        // 1. Write legacy JSON format with savedSelections
        String legacyJson = """
        {
          "configVersion": 1,
          "savedSelections": {
            "play.spacemc.lol:25565": {
              "x1": 5, "y1": 60, "z1": 5,
              "x2": 15, "y2": 70, "z2": 15
            }
          }
        }
        """;
        try (FileWriter w = new FileWriter(configFile)) {
            w.write(legacyJson);
        }

        ConfigManager manager = new ConfigManager(tempDir.toFile());
        manager.load();

        // Should automatically migrate into savedAreas
        List<SavedAreaProfile> migrated = manager.getSavedAreasFor("play.spacemc.lol:25565", "minecraft:overworld");
        assertFalse(migrated.isEmpty(), "Legacy selection must migrate to savedAreas");
        assertEquals(5, migrated.get(0).getMinX());
        assertEquals(15, migrated.get(0).getMaxX());

        // 2. Test Corruption Backup
        try (FileWriter w = new FileWriter(configFile)) {
            w.write("NOT VALID JSON {{{");
        }

        ConfigManager corruptManager = new ConfigManager(tempDir.toFile());
        corruptManager.load(); // Should not throw, should back up and create defaults

        assertNotNull(corruptManager.getConfig());
        File backup = new File(tempDir.toFile(), "refillminerpro.json.corrupted");
        assertTrue(backup.exists(), "Corrupted config must be backed up");
    }

    @Test
    @DisplayName("Test K — Volume & coordinate calculations overflow safety")
    public void testVolumeOverflowSafety() {
        SavedAreaProfile profile = new SavedAreaProfile("Giant Region", "play.test.net:25565", "minecraft:overworld",
                -2000, 0, -2000, 2000, 256, 2000);

        assertEquals(4001, profile.getWidth());
        assertEquals(257, profile.getHeight());
        assertEquals(4001, profile.getDepth());

        long expectedVolume = 4001L * 257L * 4001L; // 4,114,057,257 > Integer.MAX_VALUE (2,147,483,647)
        assertTrue(expectedVolume > Integer.MAX_VALUE, "Volume should exceed 32-bit integer range");
        assertEquals(expectedVolume, profile.getVolume(), "Volume calculation must not overflow");
    }
}

