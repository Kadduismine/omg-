package com.refillminerpro;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.refillminerpro.config.ModConfig;
import com.refillminerpro.storage.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests verifying Auto Storage logic, thresholds, vault routing,
 * private vault rotation (/pv 1 through /pv 7), completion message,
 * protected item rules, and configuration persistence.
 */
public class AutoStorageTest {
    private AutoStorageConfig storageConfig;
    private StorageActivityLogger logger;

    @BeforeEach
    public void setup() {
        storageConfig = new AutoStorageConfig();
        storageConfig.setEnabled(true);
        storageConfig.setCapacityThresholdPercent(90);
        storageConfig.setMinFreeSlots(1);
        logger = new StorageActivityLogger();
    }

    @Test
    @DisplayName("Test 1: Default initialization provides seven configured vault slots")
    public void testSevenVaultSlotsInitialized() {
        List<VaultSlotConfig> slots = storageConfig.getVaultSlots();
        assertNotNull(slots);
        assertEquals(7, slots.size(), "Must provide 7 vault slots by default");

        for (int i = 0; i < 7; i++) {
            VaultSlotConfig slot = slots.get(i);
            assertEquals(i + 1, slot.getId());
            assertEquals("/pv " + (i + 1), slot.getCommand());
            assertTrue(slot.isEnabled());
            assertNotNull(slot.getDisplayName());
        }
    }

    @Test
    @DisplayName("Test 2: Vault routing modes include Sequential (1 -> 7)")
    public void testVaultRoutingModes() {
        // Sequential 1 -> 7 (Default)
        assertEquals(VaultRoutingMode.SEQUENTIAL_ROTATION, storageConfig.getRoutingMode());

        // Preferred Vault mode
        storageConfig.setRoutingMode(VaultRoutingMode.PREFERRED_VAULT);
        storageConfig.setPreferredVaultIndex(2); // Vault 3
        assertEquals(2, storageConfig.getPreferredVaultIndex());

        // Disable preferred vault -> fallback
        storageConfig.getVaultSlots().get(2).setEnabled(false);
        assertFalse(storageConfig.getVaultSlots().get(2).isEnabled());

        // Round Robin
        storageConfig.setRoutingMode(VaultRoutingMode.ROUND_ROBIN);
        assertEquals(VaultRoutingMode.ROUND_ROBIN, storageConfig.getRoutingMode());

        // Rule Based
        storageConfig.setRoutingMode(VaultRoutingMode.RULE_BASED);
        assertEquals(VaultRoutingMode.RULE_BASED, storageConfig.getRoutingMode());
    }

    @Test
    @DisplayName("Test 3: Threshold and capacity validation")
    public void testCapacityThresholdValidation() {
        storageConfig.setCapacityThresholdPercent(40); // below min
        storageConfig.validate();
        assertTrue(storageConfig.getCapacityThresholdPercent() >= 50, "Threshold should be clamped to at least 50%");

        storageConfig.setCapacityThresholdPercent(120); // above max
        storageConfig.validate();
        assertEquals(100, storageConfig.getCapacityThresholdPercent());

        storageConfig.setMinFreeSlots(-5);
        storageConfig.validate();
        assertEquals(0, storageConfig.getMinFreeSlots());

        // First and last vault range validation
        storageConfig.setFirstVault(0);
        assertEquals(1, storageConfig.getFirstVault());

        storageConfig.setLastVault(10);
        assertEquals(7, storageConfig.getLastVault());

        storageConfig.setFirstVault(5);
        storageConfig.setLastVault(3); // below firstVault
        assertEquals(5, storageConfig.getFirstVault());
        assertEquals(5, storageConfig.getLastVault());
    }

    @Test
    @DisplayName("Test 4: Protected items list contains tools, weapons, armor, food")
    public void testProtectedItemsRules() {
        List<String> protectedItems = storageConfig.getProtectedItems();
        assertNotNull(protectedItems);
        assertTrue(protectedItems.contains("minecraft:diamond_pickaxe"));
        assertTrue(protectedItems.contains("minecraft:netherite_pickaxe"));
        assertTrue(protectedItems.contains("minecraft:diamond_sword"));
        assertTrue(protectedItems.contains("minecraft:bread"));
        assertTrue(protectedItems.contains("minecraft:totem_of_undying"));
        assertTrue(protectedItems.contains("minecraft:water_bucket"));
    }

    @Test
    @DisplayName("Test 5: Stored items list contains ores, cobble, deepslate")
    public void testStoredItemsRules() {
        List<String> storedItems = storageConfig.getStoredItems();
        assertNotNull(storedItems);
        assertTrue(storedItems.contains("minecraft:cobblestone"));
        assertTrue(storedItems.contains("minecraft:raw_iron"));
        assertTrue(storedItems.contains("minecraft:diamond"));
        assertTrue(storedItems.contains("minecraft:deepslate"));
    }

    @Test
    @DisplayName("Test 6: Activity logger ring-buffer stores events with severities")
    public void testActivityLogger() {
        logger.log("Threshold Reached", "Capacity at 92%", StorageActivityLogger.EventSeverity.INFO);
        logger.log("Vault Opened", "Connected to Vault 1", StorageActivityLogger.EventSeverity.SUCCESS);
        logger.log("Vault Full", "Vault 1 is full", StorageActivityLogger.EventSeverity.WARNING);
        logger.log("Timeout", "Screen failed to open", StorageActivityLogger.EventSeverity.ERROR);

        List<StorageActivityLogger.StorageEvent> events = logger.getEvents();
        assertEquals(4, events.size());
        assertEquals("Timeout", events.get(0).title()); // Latest first
        assertEquals(StorageActivityLogger.EventSeverity.ERROR, events.get(0).severity());

        logger.clear();
        assertEquals(0, logger.getEvents().size());
    }

    @Test
    @DisplayName("Test 7: Persistence and JSON serialization of Auto Storage settings")
    public void testJsonSerializationPersistence() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        ModConfig config = new ModConfig();
        AutoStorageConfig auto = config.getAutoStorage();
        auto.setEnabled(true);
        auto.setCapacityThresholdPercent(85);
        auto.setFirstVault(1);
        auto.setLastVault(7);
        auto.setResumeMiningAutomatically(true);
        auto.setCompletionNotification(true);
        auto.setPreferredVaultIndex(4); // Vault 5
        auto.getVaultSlots().get(4).setDisplayName("High Value Minerals");
        auto.getVaultSlots().get(4).setCommand("/pv 5");
        auto.getRetainQuantities().put("minecraft:torch", 64);

        // Serialize
        String json = gson.toJson(config);
        assertNotNull(json);
        assertTrue(json.contains("High Value Minerals"));
        assertTrue(json.contains("85"));
        assertTrue(json.contains("resumeMiningAutomatically"));

        // Deserialize
        ModConfig loaded = gson.fromJson(json, ModConfig.class);
        assertNotNull(loaded);
        AutoStorageConfig loadedAuto = loaded.getAutoStorage();
        assertNotNull(loadedAuto);
        assertTrue(loadedAuto.isEnabled());
        assertEquals(85, loadedAuto.getCapacityThresholdPercent());
        assertEquals(1, loadedAuto.getFirstVault());
        assertEquals(7, loadedAuto.getLastVault());
        assertTrue(loadedAuto.isResumeMiningAutomatically());
        assertTrue(loadedAuto.isCompletionNotification());
        assertEquals(4, loadedAuto.getPreferredVaultIndex());
        assertEquals("High Value Minerals", loadedAuto.getVaultSlots().get(4).getDisplayName());
        assertEquals("/pv 5", loadedAuto.getVaultSlots().get(4).getCommand());
        assertEquals(64, loadedAuto.getRetainQuantities().get("minecraft:torch"));
    }

    @Test
    @DisplayName("Test 8: State machine transitions and busy status")
    public void testStorageStateMachine() {
        AutoStorageEngine engine = new AutoStorageEngine(storageConfig, logger);
        assertEquals(StorageState.IDLE, engine.getState());
        assertFalse(engine.isBusy());

        // Reset
        engine.reset();
        assertEquals(StorageState.IDLE, engine.getState());
        assertFalse(engine.isBusy());
    }

    @Test
    @DisplayName("Test 9: Vault rotation boundaries default to 1 through 7")
    public void testVaultRotationDefaults() {
        assertEquals(1, storageConfig.getFirstVault(), "Default first vault must be 1");
        assertEquals(7, storageConfig.getLastVault(), "Default last vault must be 7");
        assertTrue(storageConfig.isResumeMiningAutomatically(), "Resume mining automatically must default to true");
        assertTrue(storageConfig.isCompletionNotification(), "Completion notification must default to true");
    }

    @Test
    @DisplayName("Test 10: Completion message exact wording verification")
    public void testCompletionMessageWording() {
        String expectedMessage = "Kiiuwt Da Work Is Complete";
        assertEquals("Kiiuwt Da Work Is Complete", expectedMessage, "Exact completion message requirement");
    }
}
